# tester_sr_n_ss.py
### not ready yet ###

# SR 모델로 복원한 이미지로 SS 모델로 라벨 생성해봄

# [기본 라이브러리]----------------------
import os
import numpy as np
import random
import sys

import torch
import torch.nn.functional as F
import torch.optim as optim

import torchvision
import torchvision.transforms as transforms
from torchvision.transforms.functional import to_pil_image

import argparse
import matplotlib.pyplot as plt
from PIL import Image
import cv2

import time


# [py 파일]--------------------------
from utils.calc_func import *
from utils.data_load_n_save import *
from utils.data_tool import *


# https://github.com/KyungBong-Ryu/Codes_implementation/blob/main/BasicSR_NIQE.py
# from DLCs.BasicSR_NIQE import calc_niqe_with_pil
from DLCs.BasicSR_NIQE import calc_niqe as _calc_niqe


class tester_sr_n_ss():
    def __init__(self, **kargs):
        #self.aaa = kargs['aaa']
        
        ##== 공용 데이터
        dict_log_init = kargs['dict_log_init']                     # main___.py 파일의 log dict 불러오기
        
        self.dataset_name = kargs['dataset_name']                       # 데이터셋 이름 -> "CamVid"
        
        self.PATH_BASE_IN = kargs['PATH_BASE_IN']                       # 데이터 입력 경로
        self.NAME_FOLDER_TEST = kargs['NAME_FOLDER_TEST']               # 테스트 데이터 폴더 이름
        self.NAME_FOLDER_IMAGES = kargs['NAME_FOLDER_IMAGES']           # 데이터 하위폴더 이름 (이미지)
        self.NAME_FOLDER_LABELS = kargs['NAME_FOLDER_LABELS']           # 데이터 하위폴더 이름 (라벨)
        
        self.PATH_BASE_IN_SUB = kargs['PATH_BASE_IN_SUB']               # DG 데이터 폴더 경로
        
        
        self.PATH_OUT_IMAGE = kargs['PATH_OUT_IMAGE']                   # 결과 이미지 저장 경로
        self.PATH_OUT_LOG = kargs['PATH_OUT_LOG']                       # 결과 로그 저장 경로
        
        self.HP_ORIGIN_IMG_W = kargs['HP_ORIGIN_IMG_W']                 # 원본 이미지 크기 (Width)
        self.HP_ORIGIN_IMG_H = kargs['HP_ORIGIN_IMG_H']                 # 원본 이미지 크기 (Height)
        
        self.HP_DG_CSV_NAME = kargs['HP_DG_CSV_NAME']                   # DG 정보 csv 파일 이름
        self.HP_DG_SCALE_FACTOR = kargs['HP_DG_SCALE_FACTOR']           # DG 배율
        self.HP_DG_RESIZE_OPTION = kargs['HP_DG_RESIZE_OPTION']         # DG resize 옵션
        
        ##== SR 모델 관련
        self.model_sr_name = kargs['model_sr_name']                     # SR 모델 이름 -> "MPRNet", "ESRT"
        self.model_sr = kargs['model_sr']                               # SR 모델
        self.path_msd_sr = kargs['path_msd_sr']                         # SR 모델 msd 경로+이름+확장자
        
        self.is_norm_to_tensor_sr = kargs['is_norm_to_tensor_sr']       # SR 모델 입력 데이터 정규화 여부
        self.HP_TS_NORM_MEAN_SR = kargs['HP_TS_NORM_MEAN_SR']           # SR 모델 입력 데이터 정규화 (평균)
        self.HP_TS_NORM_STD_SR = kargs['HP_TS_NORM_STD_SR']             # SR 모델 입력 데이터 정규호 (표준편차)
        
        
        ##== SS 모델 관련
        self.model_ss_name = kargs['model_ss_name']                     # SS 모델 이름 -> "D3P"
        self.model_ss = kargs['model_ss']                               # SS 모델
        self.path_msd_ss = kargs['path_msd_ss']                         # SS 모델 msd 경로+이름+확장자
        
        self.HP_MODEL_SS_IMG_W = kargs['HP_MODEL_SS_IMG_W']             # SS 모델 입력 크기 (Width)
        self.HP_MODEL_SS_IMG_H = kargs['HP_MODEL_SS_IMG_H']             # SS 모델 입력 크기 (Height)
        
        self.HP_LABEL_TOTAL = kargs['HP_LABEL_TOTAL']                   # 라벨 전체 종류
        self.HP_LABEL_VOID = kargs['HP_LABEL_VOID']                     # 라벨 Void 번호
        self.HP_COLOR_MAP = kargs['HP_COLOR_MAP']                       # 라벨 컬러맵
        
        self.is_norm_to_tensor_ss = kargs['is_norm_to_tensor_ss']       # SS 모델 입력 데이터 정규화 여부
        self.HP_TS_NORM_MEAN_SS = kargs['HP_TS_NORM_MEAN_SS']           # SS 모델 입력 데이터 정규화 (평균)
        self.HP_TS_NORM_STD_SS = kargs['HP_TS_NORM_STD_SS']             # SS 모델 입력 데이터 정규호 (표준편차)
        
        
        
        
        ###############################################################
        
        if self.PATH_BASE_IN_SUB[-1] == "/":
            self.dict_dg_csv = csv_2_dict(self.PATH_BASE_IN_SUB + self.HP_DG_CSV_NAME)
        else:
            self.dict_dg_csv = csv_2_dict(self.PATH_BASE_IN_SUB + "/" + self.HP_DG_CSV_NAME)
        
        dataset_test  = Custom_Dataset_V3
        
        ###
        dataset_test  = Custom_Dataset_V3(# Return: dict key order -> 'file_name'
                                          #                         , 'pil_img_hr', 'ts_img_hr'
                                          #                         , 'pil_lab_hr', 'ts_lab_hr'
                                          #                         , 'pil_img_lr', 'ts_img_lr', 'info_deg'
                                          name_memo                     = 'test '
                                         ,in_path_dataset               = self.PATH_BASE_IN
                                         ,in_category                   = self.NAME_FOLDER_TEST
                                         ,in_name_folder_image          = self.NAME_FOLDER_IMAGES
                                         
                                          #--- options for train 
                                         ,is_train                      = False
                                         
                                          #--- options for HR label
                                         ,is_return_label               = True
                                          # below options can be skipped when above option is False
                                         ,in_name_folder_label          = self.NAME_FOLDER_LABELS
                                         ,label_number_total            = self.HP_LABEL_TOTAL
                                         ,label_number_void             = self.HP_LABEL_VOID
                                         ,is_label_dilated              = False
                                         
                                          #--- options for LR image
                                         ,is_return_image_lr            = True
                                          # below options can be skipped when above option is False
                                         ,scalefactor                   = self.HP_DG_SCALE_FACTOR
                                          # sub-option a : don't use with sub-option b
                                         ,in_path_dlc                   = self.PATH_BASE_IN_SUB
                                         ,in_name_dlc_csv               = self.HP_DG_CSV_NAME
                                         
                                          #--- options for generate patch
                                         ,is_patch                      = False
                                         
                                          #--- optionas for generate tensor
                                         ,model_input_size              = (HP_MODEL_IMG_W, HP_MODEL_IMG_H)              #@@@ check required
                                         ,transform_img                 = transform_to_ts_img                           #@@@ check required
                                         )
        
        ###
        
        
        
        ##############################################################
        
        dict_2_txt_v2(in_file_path = self.PATH_OUT_LOG
                     ,in_file_name = "log_init.csv"
                     ,in_dict = dict_log_init
                     )
















































print("EoF: tester_sr_n_ss.py")