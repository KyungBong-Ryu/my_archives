# main_sr_train.py

if __name__ == '__main__':
    from DLCs.model_mprnet      import *
    from DLCs.model_esrt        import *
    
    from trainers.trainer_sr    import *
    from _options               import *

    #[init]----------------------------
    #Prevent overwriting results
    if os.path.isdir(PATH_BASE_OUT):
        print("실험결과 덮어쓰기 방지기능 작동됨 (Prevent overwriting results function activated)")
        sys.exit("Prevent overwriting results function activated")


    #log dicts reset
    dict_log_init = {}
    # set computation device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


    update_dict_v2("", "---< init >---"
                  ,"", "실험 날짜: " + HP_INIT_DATE_TIME
                  ,"", "--- Dataset Parameter info ---"
                  ,"", "Dataset from... " + PATH_BASE_IN
                  ,"", ""
                  ,"", "--- Hyper Parameter info ---"
                  ,"", "Device:" + str(device)
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )


    #[model_sr & Loss]------------------------
    #모델 입력 시 정규화 여부
    #MPRNet: False
    
    #model_sr_name = "MPRNet"
    model_sr_name = "ESRT"
    
    if model_sr_name == "MPRNet":
        #MPRNet + 사전 Upsample layer (Bilinear)
        model_sr = MPRNet(pre_upsample=4)
        update_dict_v2("", ""
                      ,"", "모델 정보: " + model_sr_name
                      ,"", "(github) MPRNet (denoise) + 모델 입력 전 이미지 Bilinear upsample 기능 추가"
                      ,"", "pretrained = False"
                      ,"", "pre_upsample = 4"
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
        
        criterion_sr = CharbonnierLoss_custom()
        update_dict_v2("", "loss 정보"
                      ,"", "loss: CharbonnierLoss_custom (MPRNet 자체 loss -> 편의상 사용방식 수정함)"
                      ,"", "사용 예시"
                      ,"", "loss = criterion_sr(tensor_sr_hypo and tensor_y)"
                      ,"", "*tensor_sr_hypo = [3] 크기 list 형 데이터. loss 연산시 자동으로 분할되어 입력됨"
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
        
        is_norm_in_transform_to_tensor = False
    
    if model_sr_name == "ESRT":
        #ESRT
        model_sr = ESRT(upscale=4)
        update_dict_v2("", ""
                      ,"", "모델 정보: " + model_sr_name
                      ,"", "(github) ESRT"
                      ,"", "pretrained = False"
                      ,"", "upsample = 4"
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
        
        criterion_sr = torch.nn.L1Loss()
        update_dict_v2("", "loss 정보"
                      ,"", "loss: L1 Loss"
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
        
        is_norm_in_transform_to_tensor = False
    
    model_sr.to(device)
    
    #[optimizer]------------------------
    #Adam: torch.optim.Adam(params, lr=0.001, betas=(0.9, 0.999), eps=1e-08, weight_decay=0, amsgrad=False, *, maximize=False)
    #https://arxiv.org/abs/1412.6980
    #https://pytorch.org/docs/stable/generated/torch.optim.Adam.html#torch.optim.Adam

    if is_weight_decay: #weight decay를 사용한 경우
        
        optimizer = torch.optim.Adam(model_sr.parameters()
                                    ,lr=HP_LR_SR
                                    ,weight_decay = HP_WD_SR
                                    )
        update_dict_v2("", ""
                      ,"", "옵티마이저 정보"
                      ,"", "optimizer: " + "torch.optim.Adam"
                      ,"", "learning_rate: " + str(HP_LR_SR)
                      ,"", "weight decay 적용됨: " + str(HP_WD_SR)
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
        
    else: #weight decay를 사용하지 않는 경우
        optimizer = torch.optim.Adam(model_sr.parameters()
                                    ,lr=HP_LR_SR
                                    )
        update_dict_v2("", ""
                      ,"", "옵티마이저 정보"
                      ,"", "optimizer: " + "torch.optim.Adam"
                      ,"", "learning_rate: " + str(HP_LR_SR)
                      ,"", "weight decay 적용 안됨"
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )

    #[scheduler]----------------------------------------------
    #https://gaussian37.github.io/dl-pytorch-lr_scheduler/

    if HP_SCHEDULER_OPTION_SR == "CosineAnnealingLR":
        scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer
                                                        ,T_max = HP_SCHEDULER_T_MAX
                                                        ,eta_min = HP_SCHEDULER_ETA_MIN
                                                        )

        update_dict_v2("", ""
                      ,"", "스케쥴러 정보"
                      ,"", "업데이트 간격: " + HP_SCHEDULER_UPDATE_INTERVAL_SR
                      ,"", "scheduler: " + "optim.lr_scheduler.CosineAnnealingLR"
                      ,"", "LR 최대값 도달 epoch 수 (lr 반복주기의 절반)"
                      ,"", "T_max: " + str(HP_SCHEDULER_T_MAX)
                      ,"", "lr 최소값 (default = 0)"
                      ,"", "eta_min: " + str(HP_SCHEDULER_ETA_MIN)
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )

    #[loss]--------------------------------------------------

    # from MPRNet
    



    #=========================================================================================

    trainer_sr  (# <patch를 통해 학습 & RGB 이미지를 생성하는 모델>#
                 # 초기화 기록 dict 이어받기
                dict_log_init = dict_log_init
                 # 랜덤 시드 고정
                ,HP_SEED = HP_SEED
                
                
                 # 학습 관련 기본 정보(epoch 수, batch 크기(train은 생성할 patch 수), 학습 시 dataset 루프 횟수)
                ,HP_EPOCH = HP_EPOCH
                ,HP_BATCH_TRAIN = HP_BATCH_TRAIN_SR
                ,HP_DATASET_LOOP = HP_DATASET_LOOP_SR
                ,HP_BATCH_VAL = HP_BATCH_VAL
                ,HP_BATCH_TEST = HP_BATCH_TEST
                
                
                 # 데이터 입출력 경로, 폴더명
                ,PATH_BASE_IN = PATH_BASE_IN
                ,NAME_FOLDER_TRAIN = NAME_FOLDER_TRAIN
                ,NAME_FOLDER_VAL = NAME_FOLDER_VAL
                ,NAME_FOLDER_TEST = NAME_FOLDER_TEST
                ,NAME_FOLDER_IMAGES = NAME_FOLDER_IMAGES
                ,NAME_FOLDER_LABELS = NAME_FOLDER_LABELS
                
                 # (선택) degraded image 불러올 경로
                ,PATH_BASE_IN_SUB = PATH_BASE_IN_SUB
                
                ,PATH_OUT_IMAGE = PATH_OUT_IMAGE
                ,PATH_OUT_MODEL = PATH_OUT_MODEL
                ,PATH_OUT_LOG = PATH_OUT_LOG
                
                
                 # 데이터(이미지) 입출력 크기 (원본 이미지, 모델 입력 이미지), 이미지 채널 수(이미지, 라벨, 모델출력물)
                ,HP_ORIGIN_IMG_W = HP_ORIGIN_IMG_W
                ,HP_ORIGIN_IMG_H = HP_ORIGIN_IMG_H
                ,HP_MODEL_IMG_W = HP_MODEL_SR_IMG_W
                ,HP_MODEL_IMG_H = HP_MODEL_SR_IMG_H
                ,HP_CHANNEL_RGB = HP_CHANNEL_RGB
                
                 #Patch 생성 관련
                ,is_use_patch = True
                ,HP_PATCH_STRIDES = HP_PATCH_STRIDES_SR
                ,HP_PATCH_CROP_INIT_COOR_RANGE = HP_PATCH_CROP_INIT_COOR_RANGE_SR
                
                 # 모델 이름 -> 모델에 따라 예측결과 형태가 다르기에 모델입출력물을 조정하는 역할
                 # 지원 리스트 = "MPRNet"
                ,model_name = model_sr_name
                
                 # model, optimizer, scheduler, loss
                ,model = model_sr
                ,optimizer = optimizer
                ,scheduler = scheduler
                ,criterion = criterion_sr
                 # 스케쥴러 업데이트 간격("epoch" 또는 "batch")
                ,HP_SCHEDULER_UPDATE_INTERVAL = HP_SCHEDULER_UPDATE_INTERVAL_SR
                
                
                 # DataAugm- 관련 (colorJitter 포함)
                ,HP_AUGM_RANGE_CROP_INIT = HP_AUGM_RANGE_CROP_INIT
                ,HP_AUGM_ROTATION_MAX = HP_AUGM_ROTATION_MAX
                ,HP_AUGM_PROB_FLIP = HP_AUGM_PROB_FLIP
                ,HP_AUGM_PROB_CROP = HP_AUGM_PROB_CROP
                ,HP_AUGM_PROB_ROTATE = HP_AUGM_PROB_ROTATE
                ,HP_CJ_BRIGHTNESS = HP_CJ_BRIGHTNESS
                ,HP_CJ_CONTRAST = HP_CJ_CONTRAST
                ,HP_CJ_SATURATION = HP_CJ_SATURATION
                ,HP_CJ_HUE = HP_CJ_HUE
                
                
                 # 이미지 -> 텐서 시 norm 관련 (정규화 시행여부, 평균, 표준편차)
                ,is_norm_in_transform_to_tensor = is_norm_in_transform_to_tensor
                ,HP_TS_NORM_MEAN = HP_TS_NORM_MEAN_SR
                ,HP_TS_NORM_STD = HP_TS_NORM_STD_SR
                
                
                 # Degradation 관련 설정값
                ,HP_DG_CSV_NAME = HP_DG_CSV_NAME
                ,HP_DG_SCALE_FACTOR = HP_DG_SCALE_FACTOR
                ,HP_DG_RESIZE_OPTION = HP_DG_RESIZE_OPTION
                ,HP_DG_RANGE_NOISE_SIGMA = HP_DG_RANGE_NOISE_SIGMA
                ,HP_DG_NOISE_GRAY_PROB = HP_DG_NOISE_GRAY_PROB
                )
    
    
    print("End of workspace_dsrl.py")
