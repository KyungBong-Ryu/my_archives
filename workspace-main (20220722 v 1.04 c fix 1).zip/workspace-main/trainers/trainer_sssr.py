# trainer_dsrl.py -> trainer_sssr.py
# Dual Super-Resolution Learning
# 단일 Encoder & 개별 Decoder로 SS & SR 동시에 시행하는 구조
# [memo] --------------
# https://pytorch.org/tutorials/recipes/recipes/amp_recipe.html
# AMP(Automatic Mixed Precision) 사용됨
# 2 Fold 데이터 분할 (Train 45% Val 5% Test 50%): CamVid_12_2Fold_v4

# now data-loader supprt multi workers

# [기본 라이브러리]----------------------
import os
import numpy as np
import random
import sys

import torch
import torch.nn.functional as F
import torch.optim as optim

import torchvision
import torchvision.transforms as transforms
from torchvision.transforms.functional import to_pil_image

import argparse
import matplotlib.pyplot as plt
from PIL import Image
import cv2

import time

# [py 파일]--------------------------
from utils.calc_func import *
from utils.data_load_n_save import *
from utils.data_tool import *

from mps.mp_sssr_plt_saver import plts_saver

# https://github.com/KyungBong-Ryu/Codes_implementation/blob/main/BasicSR_NIQE.py
# from DLCs.BasicSR_NIQE import calc_niqe_with_pil
from DLCs.BasicSR_NIQE import calc_niqe as _calc_niqe

#<<< @@@ trainer_dsrl


def trainer_dsrl(**kargs):
    '''#========================================#
    trainer_dsrl(# <patch를 통해 학습 & RGB 이미지를 생성하는 모델>#
                #코드 실행 장소 (colab 여부 확인용, colab == -1)
                RUN_WHERE = 
                
                # 초기화 기록 dict 이어받기
                ,dict_log_init = 
                 # 랜덤 시드 고정
                ,HP_SEED = HP_SEED
                
                
                 # 학습 관련 기본 정보(epoch 수, batch 크기(train은 생성할 patch 수), 학습 시 dataset 루프 횟수)
                ,HP_EPOCH = HP_EPOCH
                ,HP_BATCH_TRAIN = HP_BATCH_TRAIN_DSRL
                ,HP_DATASET_LOOP = HP_DATASET_LOOP_DSRL
                ,HP_BATCH_VAL = HP_BATCH_VAL
                ,HP_BATCH_TEST = HP_BATCH_TEST
                
                
                 # 데이터 입출력 경로, 폴더명
                ,PATH_BASE_IN = PATH_BASE_IN
                ,NAME_FOLDER_TRAIN = NAME_FOLDER_TRAIN
                ,NAME_FOLDER_VAL = NAME_FOLDER_VAL
                ,NAME_FOLDER_TEST = NAME_FOLDER_TEST
                ,NAME_FOLDER_IMAGES = NAME_FOLDER_IMAGES
                ,NAME_FOLDER_LABELS = NAME_FOLDER_LABELS
                
                 # (선택) degraded image 불러올 경로
                ,PATH_BASE_IN_SUB = PATH_BASE_IN_SUB
                
                ,PATH_OUT_IMAGE = PATH_OUT_IMAGE
                ,PATH_OUT_MODEL = PATH_OUT_MODEL
                ,PATH_OUT_LOG = PATH_OUT_LOG
                
                
                 # 데이터(이미지) 입출력 크기 (원본 이미지, 모델 입력 이미지), 이미지 채널 수(이미지, 라벨, 모델출력물)
                ,HP_ORIGIN_IMG_W = HP_ORIGIN_IMG_W
                ,HP_ORIGIN_IMG_H = HP_ORIGIN_IMG_H
                ,HP_MODEL_IMG_W = HP_MODEL_DSRL_IMG_W
                ,HP_MODEL_IMG_H = HP_MODEL_DSRL_IMG_H
                ,HP_CHANNEL_RGB = HP_CHANNEL_RGB
                ,HP_CHANNEL_GRAY = HP_CHANNEL_GRAY
                ,HP_CHANNEL_HYPO = HP_CHANNEL_HYPO
                
                 # 라벨 정보(원본 데이터 라벨 수(void 포함), void 라벨 번호, 컬러매핑)
                ,HP_LABEL_TOTAL = HP_LABEL_TOTAL
                ,HP_LABEL_VOID = HP_LABEL_VOID
                ,HP_COLOR_MAP = HP_COLOR_MAP
                
                 # 모델 이름 -> 모델에 따라 예측결과 형태가 다르기에 모델입출력물을 조정하는 역할
                 # 지원 리스트 = "DeepLab v3 plus", "model_a", "model_proposed", "model_d"
                ,model_name = model_dsrl_name
                
                 # model, optimizer, scheduler, loss
                ,model = model_dsrl
                ,optimizer = optimizer
                ,scheduler = scheduler
                ,criterion = criterion_dsrl
                 # 스케쥴러 업데이트 간격("epoch" 또는 "batch")
                ,HP_SCHEDULER_UPDATE_INTERVAL = HP_SCHEDULER_UPDATE_INTERVAL_DSRL
                
                
                 # DataAugm- 관련 (colorJitter 포함)
                ,HP_AUGM_RANGE_CROP_INIT = HP_AUGM_RANGE_CROP_INIT
                ,HP_AUGM_ROTATION_MAX = HP_AUGM_ROTATION_MAX
                ,HP_AUGM_PROB_FLIP = HP_AUGM_PROB_FLIP
                ,HP_AUGM_PROB_CROP = HP_AUGM_PROB_CROP
                ,HP_AUGM_PROB_ROTATE = HP_AUGM_PROB_ROTATE
                ,HP_CJ_BRIGHTNESS = HP_CJ_BRIGHTNESS
                ,HP_CJ_CONTRAST = HP_CJ_CONTRAST
                ,HP_CJ_SATURATION = HP_CJ_SATURATION
                ,HP_CJ_HUE = HP_CJ_HUE
                
                
                 # 이미지 -> 텐서 시 norm 관련 (정규화 시행여부, 평균, 표준편차)
                ,is_norm_in_transform_to_tensor = 
                ,HP_TS_NORM_MEAN = HP_TS_NORM_MEAN_DSRL
                ,HP_TS_NORM_STD = HP_TS_NORM_STD_DSRL
                
                
                 # Degradation 관련 설정값
                ,HP_DG_CSV_NAME = HP_DG_CSV_NAME
                ,HP_DG_SCALE_FACTOR = HP_DG_SCALE_FACTOR
                ,HP_DG_RESIZE_OPTION = HP_DG_RESIZE_OPTION
                ,HP_DG_RANGE_NOISE_SIGMA = HP_DG_RANGE_NOISE_SIGMA
                ,HP_DG_NOISE_GRAY_PROB = HP_DG_NOISE_GRAY_PROB
                
                )
    
    '''#========================================#
    # calc_miou_gray 함수의 dict_ious 결과물을 하나의 dict에 누적시키는 함수
    # 범용성이 떨어져서 trainer 함수 내부에서 선언함
    # 누적할 dict, miou 값(float), iou dict
    def accumulate_dict_ious(dict_accumulate, miou, dict_ious):
        # 형태 = "dict_ious와 동일한 key" : (유효 iou 수, iou 누적값)
        # dict_accumulate = kargs['dict_accumulate']

        # dict_ious = kargs['dict_ious']
        
        if "miou" in dict_accumulate:
            item_current = dict_accumulate["miou"]
        else:
            item_current = (0,0)
            
        dict_accumulate["miou"] = (item_current[0] + 1, item_current[1] + miou)
        
        for i_key in dict_ious:
            # 초기값 불러오기
            if i_key in dict_accumulate:
                # 유효한 key 인 경우
                item_current = dict_accumulate[i_key]
            else:
                # key가 존재하지 않았을 경우
                item_current = (0,0)
            
            if dict_ious[i_key] == "NaN":
                # 현재 라벨에 대한 값이 유효하지 않은 경우
                item_new = item_current
            else:
                # 현재 라벨에 대한 값이 유효한 경우
                item_new = (item_current[0] + 1, item_current[1] + float(dict_ious[i_key]))
            
            # dict 업데이트
            dict_accumulate[i_key] = item_new
        
    #=== End of accumulate_dict_ious
    
    
    # [최우선 초기화요소 시행]------------------------
    # colab 여부 판별용 (colab == -1)
    try:
        RUN_WHERE = kargs['RUN_WHERE']
    except:
        RUN_WHERE = 1
    
    # log dict 이어받기
    dict_log_init = kargs['dict_log_init']
    
    # 사용 decive 설정
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # 랜덤 시드(seed) 적용
    HP_SEED = kargs['HP_SEED']
    random.seed(HP_SEED)
    np.random.seed(HP_SEED)
    # pytorch 랜덤시드 고정 (CPU)
    torch.manual_seed(HP_SEED)
    
    
    update_dict_v2("", ""
                  ,"", "랜덤 시드값 (random numpy pytorch)"
                  ,"", "HP_SEED: " + str(HP_SEED)
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    if device == 'cuda':
        # pytorch 랜덤시드 고정 (GPU & multi-GPU)
        torch.cuda.manual_seed(HP_SEED)
        torch.cuda.manual_seed_all(HP_SEED)
    
    # epoch 수
    HP_EPOCH = kargs['HP_EPOCH']
    # batch 크기 & (train) 데이터셋 루프 횟수
    HP_BATCH_TRAIN = kargs['HP_BATCH_TRAIN']
    HP_DATASET_LOOP = kargs['HP_DATASET_LOOP']
    HP_BATCH_VAL = kargs['HP_BATCH_VAL']
    HP_BATCH_TEST = kargs['HP_BATCH_TEST']
    
    update_dict_v2("", ""
                  ,"", "최대 epoch 설정: " + str(HP_EPOCH)
                  ,"", "batch 크기"
                  ,"", "HP_BATCH_TRAIN: " + str(HP_BATCH_TRAIN)
                  ,"", "학습 시 데이터셋 반복횟수"
                  ,"", "HP_DATASET_LOOP: " + str(HP_DATASET_LOOP)
                  ,"", "그래디언트 축적(Gradient Accumulation) 사용 안함"
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    # [입출력 Data 관련]-----------------------------
    # 경로: 입력
    PATH_BASE_IN = kargs['PATH_BASE_IN']
    NAME_FOLDER_TRAIN = kargs['NAME_FOLDER_TRAIN']
    NAME_FOLDER_VAL = kargs['NAME_FOLDER_VAL']
    NAME_FOLDER_TEST = kargs['NAME_FOLDER_TEST']
    NAME_FOLDER_IMAGES = kargs['NAME_FOLDER_IMAGES']
    NAME_FOLDER_LABELS = kargs['NAME_FOLDER_LABELS']
    
    # 경로: 출력
    PATH_OUT_IMAGE = kargs['PATH_OUT_IMAGE']
    PATH_OUT_MODEL = kargs['PATH_OUT_MODEL']
    PATH_OUT_LOG = kargs['PATH_OUT_LOG']
    
    # 원본 이미지 크기
    HP_ORIGIN_IMG_W = kargs['HP_ORIGIN_IMG_W']
    HP_ORIGIN_IMG_H = kargs['HP_ORIGIN_IMG_H']
    # 이미지 모델입력 크기 (train & val & test)
    HP_MODEL_IMG_W = kargs['HP_MODEL_IMG_W']
    HP_MODEL_IMG_H = kargs['HP_MODEL_IMG_H']
    # 이미지&라벨&모델출력물 채널 수
    HP_CHANNEL_RGB = kargs['HP_CHANNEL_RGB']
    HP_CHANNEL_GRAY = kargs['HP_CHANNEL_GRAY']
    HP_CHANNEL_HYPO = kargs['HP_CHANNEL_HYPO']
    
    # 라벨 정보
    HP_LABEL_TOTAL = kargs['HP_LABEL_TOTAL']
    HP_LABEL_VOID = kargs['HP_LABEL_VOID']
    HP_COLOR_MAP = kargs['HP_COLOR_MAP']
    
    update_dict_v2("", ""
                  ,"", "원본 Dataset 이미지 크기"
                  ,"", "HP_ORIGIN_IMG_(W H): (" + str(HP_ORIGIN_IMG_W) + " " + str(HP_ORIGIN_IMG_H) + ")"
                  ,"", "모델 입출력 이미지 크기 (train val test)"
                  ,"", "HP_MODEL_IMG_(W H): (" + str(HP_MODEL_IMG_W) + " " + str(HP_MODEL_IMG_H) + ")"
                  ,"", "이미지 채널 수 (이미지): " + str(HP_CHANNEL_RGB)
                  ,"", "이미지 채널 수 (라벨): " + str(HP_CHANNEL_GRAY)
                  ,"", "이미지 채널 수 (모델출력물): " + str(HP_CHANNEL_HYPO)
                  ,"", "원본 데이터 라벨 수(void 포함): " + str(HP_LABEL_TOTAL)
                  ,"", "void 라벨 번호: " + str(HP_LABEL_VOID)
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    # 라벨 정보 (CamVid 12)
    update_dict_v2("", ""
                  ,"", "라벨 별 RGB 매핑"
                  ,"", "0:  [128 128 128]  # 00 sky"
                  ,"", "1:  [128   0   0]  # 01 building"
                  ,"", "2:  [192 192 128]  # 02 column_pole"
                  ,"", "3:  [128  64 128]  # 03 road"
                  ,"", "4:  [  0   0 192]  # 04 sidewalk"
                  ,"", "5:  [128 128   0]  # 05 Tree"
                  ,"", "6:  [192 128 128]  # 06 SignSymbol"
                  ,"", "7:  [ 64  64 128]  # 07 Fence"
                  ,"", "8:  [ 64   0 128]  # 08 Car"
                  ,"", "9:  [ 64  64   0]  # 09 Pedestrian"
                  ,"", "10: [  0 128 192]  # 10 Bicyclist"
                  ,"", "11: [  0   0   0]  # 11 Void"
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    
    
    # [model, 모델 추가정보, optimizer, scheduler, loss]--------------------
    #<<< 
    #    현재 지원되는 모델 리스트
    #    1. DeepLab v3 plus
    #    2. model_a
    #
    model_name = kargs['model_name']
    #>>>
    
    model = kargs['model']
    
    update_dict_v2("", ""
                  ,"", "모델 종류: " + str(model_name)
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    optimizer = kargs['optimizer']
    scheduler = kargs['scheduler']
    HP_SCHEDULER_UPDATE_INTERVAL = kargs['HP_SCHEDULER_UPDATE_INTERVAL']
    # loss
    criterion = kargs['criterion']
    
    # [Automatic Mixed Precision 선언] ---
    amp_scaler = torch.cuda.amp.GradScaler(enabled = True)
    update_dict_v2("", ""
                  ,"", "Automatic Mixed Precision 사용됨"
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    # [data augmentation 관련]--------------------
    
    HP_AUGM_RANGE_CROP_INIT = kargs['HP_AUGM_RANGE_CROP_INIT']
    HP_AUGM_ROTATION_MAX = kargs['HP_AUGM_ROTATION_MAX']
    HP_AUGM_PROB_FLIP = kargs['HP_AUGM_PROB_FLIP']
    HP_AUGM_PROB_CROP = kargs['HP_AUGM_PROB_CROP']
    HP_AUGM_PROB_ROTATE  = kargs['HP_AUGM_PROB_ROTATE']
    # colorJitter 관련
    # https://pytorch.org/vision/master/generated/torchvision.transforms.ColorJitter.html#torchvision.transforms.ColorJitter
    HP_CJ_BRIGHTNESS = kargs['HP_CJ_BRIGHTNESS']
    HP_CJ_CONTRAST   = kargs['HP_CJ_CONTRAST']
    HP_CJ_SATURATION = kargs['HP_CJ_SATURATION']
    HP_CJ_HUE        = kargs['HP_CJ_HUE']
    
    transform_cj = transforms.ColorJitter(brightness = HP_CJ_BRIGHTNESS
                                         ,contrast   = HP_CJ_CONTRAST
                                         ,saturation = HP_CJ_SATURATION
                                         ,hue        = HP_CJ_HUE
                                         )
    
    update_dict_v2("", ""
                  ,"", "ColorJitter 설정"
                  ,"", "brightness: ( " + " ".join([str(t_element) for t_element in HP_CJ_BRIGHTNESS]) +" )"
                  ,"", "contrast:   ( " + " ".join([str(t_element) for t_element in HP_CJ_CONTRAST])   +" )"
                  ,"", "saturation: ( " + " ".join([str(t_element) for t_element in HP_CJ_SATURATION]) +" )"
                  ,"", "hue:        ( " + " ".join([str(t_element) for t_element in HP_CJ_HUE])        +" )"
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    # [이미지 변수 -> 텐서 변수 변환]-------------------
    # 정규화 여부
    is_norm_in_transform_to_tensor = kargs['is_norm_in_transform_to_tensor']
    
    if is_norm_in_transform_to_tensor:
        # 평균
        HP_TS_NORM_MEAN = kargs['HP_TS_NORM_MEAN']
        # 표준편차
        HP_TS_NORM_STD = kargs['HP_TS_NORM_STD']
        # 입력 이미지 텐서 변환 후 정규화 시행
        transform_to_ts_img = transforms.Compose([# PIL 이미지 or npArray -> pytorch 텐서
                                                  transforms.ToTensor()
                                                  # 평균, 표준편차를 활용해 정규화
                                                 ,transforms.Normalize(mean = HP_TS_NORM_MEAN, std = HP_TS_NORM_STD)
                                                 ,
                                                 ])
        
        # 역정규화 변환
        transform_ts_inv_norm = transforms.Compose([# 평균, 표준편차를 역으로 활용해 역정규화
                                                    transforms.Normalize(mean = [ 0., 0., 0. ]
                                                                        ,std = [ 1/HP_TS_NORM_STD[0], 1/HP_TS_NORM_STD[1], 1/HP_TS_NORM_STD[2] ])
                                                     
                                                   ,transforms.Normalize(mean = [ -HP_TS_NORM_MEAN[0], -HP_TS_NORM_MEAN[1], -HP_TS_NORM_MEAN[2] ]
                                                                        ,std = [ 1., 1., 1. ])
                                                                        
                                                   ,
                                                   ])
        
        update_dict_v2("", ""
                      ,"", "입력 이미지(in_x) 정규화 시행됨"
                      ,"", "mean=[ " + str(HP_TS_NORM_MEAN[0]) + " " + str(HP_TS_NORM_MEAN[1]) + " "+ str(HP_TS_NORM_MEAN[2]) + " ]"
                      ,"", "std=[ " + str(HP_TS_NORM_STD[0]) + " " + str(HP_TS_NORM_STD[1]) + " "+ str(HP_TS_NORM_STD[2]) + " ]"
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
    else:
        # 정규화 없이 이미지를 텐서형으로 변환
        transform_to_ts_img = transforms.Compose([# PIL 이미지 or npArray -> pytorch 텐서
                                                  # https://pytorch.org/vision/stable/generated/torchvision.transforms.ToTensor.html#torchvision.transforms.ToTensor
                                                  # 일반적인 경우 (PIL mode: L, LA, P, I, F, RGB, YCbCr, RGBA, CMYK, 1 또는 numpy.ndarray), 
                                                  # (H x W x C) in the range [0, 255] 입력 데이터를
                                                  # (C x H x W) in the range [0.0, 1.0] 출력 데이터로 변환함 (scaled)
                                                  transforms.ToTensor()
                                                 ])
        
        update_dict_v2("", ""
                      ,"", "입력 이미지(in_x) 정규화 시행 안함"
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
    
    # [Degradation 관련]-------------------------------
    # (bool) 학습 & 평가 시 Degradaded Input 사용 여부
    option_apply_degradation = True
    
    if option_apply_degradation:
        # "Train & Test 과정에 Degradation 시행 됨"
        
        try:
            PATH_BASE_IN_SUB = kargs['PATH_BASE_IN_SUB']
            HP_DG_CSV_NAME = kargs['HP_DG_CSV_NAME']
            if not PATH_BASE_IN_SUB[-1] == "/":
                PATH_BASE_IN_SUB += "/"
            
            dict_loaded_pils = load_pils_2_dict(# 경로 내 pil 이미지를 전부 불러와서 dict 형으로 묶어버림
                                                # (str) 파일 경로
                                                in_path = PATH_BASE_IN_SUB
                                                # (선택, str) 파일 경로 - 하위폴더명
                                               ,in_path_sub = NAME_FOLDER_IMAGES
                                               )
            print("Pre-Degraded images loaded from:", PATH_BASE_IN_SUB + NAME_FOLDER_IMAGES)
            
            dict_dg_csv = csv_2_dict(path_csv = PATH_BASE_IN_SUB + HP_DG_CSV_NAME)
            print("Pre-Degrade option csv re-loaded from:", PATH_BASE_IN_SUB + HP_DG_CSV_NAME)
            
            flag_pre_degraded_images_loaded = True
            tmp_log_pre_degraded_images_load = "Degraded 이미지를 불러왔습니다."
        except:
            print("(exc) Pre-Degraded images load FAIL")
            flag_pre_degraded_images_loaded = False
            tmp_log_pre_degraded_images_load = "Degraded 이미지를 불러오지 않습니다."
        
        update_dict_v2("", ""
                      ,"", "Degraded 이미지 옵션: " + tmp_log_pre_degraded_images_load
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
        
        # 고정옵션 dict
        HP_DG_CSV_NAME = kargs['HP_DG_CSV_NAME']
        HP_DG_CSV_PATH = PATH_BASE_IN_SUB + HP_DG_CSV_NAME
        dict_dg_csv = csv_2_dict(path_csv = HP_DG_CSV_PATH)
        
        # scale_factor 고정값
        HP_DG_SCALE_FACTOR = kargs['HP_DG_SCALE_FACTOR']
        # resize (downscale) 옵션
        HP_DG_RESIZE_OPTION = kargs['HP_DG_RESIZE_OPTION']
        
        # Gaussian 노이즈 시그마 범위
        HP_DG_RANGE_NOISE_SIGMA = kargs['HP_DG_RANGE_NOISE_SIGMA']
        # Gray 노이즈 확률 (%)
        HP_DG_NOISE_GRAY_PROB = kargs['HP_DG_NOISE_GRAY_PROB']
        
        update_dict_v2("", ""
                      ,"", "Degradation 관련"
                      ,"", "시행여부: " + "Train & Test 과정에 Degradation 시행 됨"
                      ,"", "DG 지정값 파일 경로: " + HP_DG_CSV_PATH
                      ,"", "Scale Factor 고정값 = x" + str(HP_DG_SCALE_FACTOR)
                      ,"", "Resize 옵션 = " + HP_DG_RESIZE_OPTION
                      ,"", "Gaussian 노이즈 시그마 범위 = [ " + str(HP_DG_RANGE_NOISE_SIGMA[0]) + " " + str(HP_DG_RANGE_NOISE_SIGMA[-1]) + " ]"
                      ,"", "노이즈 종류 (Color or Gray 중 Gray 노이즈 확률 = " + str(HP_DG_NOISE_GRAY_PROB)
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
        
        
    else:
        # "Train & Test 과정에 Degradation 시행 안됨"
        update_dict_v2("", ""
                      ,"", "Degradation 관련"
                      ,"", "시행여부: " + "Train & Test 과정에 Degradation 시행 안됨"
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
    
    
    dict_2_txt_v2(in_file_path = PATH_OUT_LOG
                 ,in_file_name = "log_init.csv"
                 ,in_dict = dict_log_init
                 )
    
    
    # [data & model load]--------------------------
    
    dataset_train = Custom_Dataset_V3(# Return: dict key order -> 'file_name'
                                      #                         , 'pil_img_hr', 'ts_img_hr', 'info_augm'
                                      #                         , 'pil_lab_hr', 'ts_lab_hr'
                                      #                         , 'pil_img_lr', 'ts_img_lr', 'info_deg'
                                      name_memo                     = 'train'
                                     ,in_path_dataset               = PATH_BASE_IN
                                     ,in_category                   = NAME_FOLDER_TRAIN
                                     ,in_name_folder_image          = NAME_FOLDER_IMAGES
                                     
                                      #--- options for train 
                                     ,is_train                      = True
                                      # below options can be skipped when above option is False
                                     ,opt_augm_crop_init_range      = HP_AUGM_RANGE_CROP_INIT
                                     ,opt_augm_rotate_max_degree    = HP_AUGM_ROTATION_MAX
                                     ,opt_augm_prob_flip            = HP_AUGM_PROB_FLIP
                                     ,opt_augm_prob_crop            = HP_AUGM_PROB_CROP
                                     ,opt_augm_prob_rotate          = HP_AUGM_PROB_ROTATE
                                     ,opt_augm_cj_brigntess         = HP_CJ_BRIGHTNESS
                                     ,opt_augm_cj_contrast          = HP_CJ_CONTRAST
                                     ,opt_augm_cj_saturation        = HP_CJ_SATURATION
                                     ,opt_augm_cj_hue               = HP_CJ_HUE
                                     
                                      #--- options for HR label
                                     ,is_return_label               = True
                                      # below options can be skipped when above option is False
                                     ,in_name_folder_label          = NAME_FOLDER_LABELS
                                     ,label_number_total            = HP_LABEL_TOTAL
                                     ,label_number_void             = HP_LABEL_VOID
                                     ,is_label_dilated              = True
                                     
                                      #--- options for LR image
                                     ,is_return_image_lr            = True
                                      # below options can be skipped when above option is False
                                     ,scalefactor                   = HP_DG_SCALE_FACTOR
                                      # sub-option a : don't use with sub-option b
                                      #,in_path_dlc                 = not used
                                      #,in_name_dlc_csv             = not used
                                      # sub-option b : don't use with sub-option a
                                     ,opt_dg_blur                   = "Gaussian"
                                     ,opt_dg_interpolation          = HP_DG_RESIZE_OPTION
                                     ,opt_dg_noise                  = "Gaussian"
                                     ,opt_dg_noise_sigma_range      = HP_DG_RANGE_NOISE_SIGMA
                                     ,opt_dg_noise_gray_prob        = HP_DG_NOISE_GRAY_PROB
                                     
                                      #--- increase dataset length
                                     ,in_dataset_loop               = HP_DATASET_LOOP                               #@@@ check required
                                     
                                      #--- options for generate patch
                                     ,is_patch                      = False
                                     
                                      #--- optionas for generate tensor
                                     ,model_input_size              = (HP_MODEL_IMG_W, HP_MODEL_IMG_H)              #@@@ check required
                                     ,transform_img                 = transform_to_ts_img                           #@@@ check required
                                     )
    
    dataset_val   = Custom_Dataset_V3(# Return: dict key order -> 'file_name'
                                      #                         , 'pil_img_hr', 'ts_img_hr'
                                      #                         , 'pil_lab_hr', 'ts_lab_hr'
                                      #                         , 'pil_img_lr', 'ts_img_lr', 'info_deg'
                                      name_memo                     = ' val '
                                     ,in_path_dataset               = PATH_BASE_IN
                                     ,in_category                   = NAME_FOLDER_VAL
                                     ,in_name_folder_image          = NAME_FOLDER_IMAGES
                                     
                                      #--- options for train 
                                     ,is_train                      = False
                                     
                                      #--- options for HR label
                                     ,is_return_label               = True
                                      # below options can be skipped when above option is False
                                     ,in_name_folder_label          = NAME_FOLDER_LABELS
                                     ,label_number_total            = HP_LABEL_TOTAL
                                     ,label_number_void             = HP_LABEL_VOID
                                     ,is_label_dilated              = False
                                     
                                      #--- options for LR image
                                     ,is_return_image_lr            = True
                                      # below options can be skipped when above option is False
                                     ,scalefactor                   = HP_DG_SCALE_FACTOR
                                      # sub-option a : don't use with sub-option b
                                     ,in_path_dlc                   = PATH_BASE_IN_SUB
                                     ,in_name_dlc_csv               = HP_DG_CSV_NAME
                                     
                                      #--- options for generate patch
                                     ,is_patch                      = False
                                     
                                      #--- optionas for generate tensor
                                     ,model_input_size              = (HP_MODEL_IMG_W, HP_MODEL_IMG_H)              #@@@ check required
                                     ,transform_img                 = transform_to_ts_img                           #@@@ check required
                                     )
    
    
    dataset_test  = Custom_Dataset_V3(# Return: dict key order -> 'file_name'
                                      #                         , 'pil_img_hr', 'ts_img_hr'
                                      #                         , 'pil_lab_hr', 'ts_lab_hr'
                                      #                         , 'pil_img_lr', 'ts_img_lr', 'info_deg'
                                      name_memo                     = 'test '
                                     ,in_path_dataset               = PATH_BASE_IN
                                     ,in_category                   = NAME_FOLDER_TEST
                                     ,in_name_folder_image          = NAME_FOLDER_IMAGES
                                     
                                      #--- options for train 
                                     ,is_train                      = False
                                     
                                      #--- options for HR label
                                     ,is_return_label               = True
                                      # below options can be skipped when above option is False
                                     ,in_name_folder_label          = NAME_FOLDER_LABELS
                                     ,label_number_total            = HP_LABEL_TOTAL
                                     ,label_number_void             = HP_LABEL_VOID
                                     ,is_label_dilated              = False
                                     
                                      #--- options for LR image
                                     ,is_return_image_lr            = True
                                      # below options can be skipped when above option is False
                                     ,scalefactor                   = HP_DG_SCALE_FACTOR
                                      # sub-option a : don't use with sub-option b
                                     ,in_path_dlc                   = PATH_BASE_IN_SUB
                                     ,in_name_dlc_csv               = HP_DG_CSV_NAME
                                     
                                      #--- options for generate patch
                                     ,is_patch                      = False
                                     
                                      #--- optionas for generate tensor
                                     ,model_input_size              = (HP_MODEL_IMG_W, HP_MODEL_IMG_H)              #@@@ check required
                                     ,transform_img                 = transform_to_ts_img                           #@@@ check required
                                     )
    
    
    #https://pytorch.org/docs/stable/data.html#torch.utils.data.DataLoader
    
    dataloader_train = torch.utils.data.DataLoader(dataset     = dataset_train
                                                  ,batch_size  = HP_BATCH_TRAIN
                                                  ,shuffle     = True
                                                  ,num_workers = 0
                                                  ,prefetch_factor = 2
                                                  ,drop_last = True
                                                  )
    
    dataloader_val   = torch.utils.data.DataLoader(dataset     = dataset_val
                                                  ,batch_size  = HP_BATCH_VAL
                                                  ,shuffle     = False
                                                  ,num_workers = 0
                                                  ,prefetch_factor = 2
                                                  )
    
    dataloader_test  = torch.utils.data.DataLoader(dataset     = dataset_test
                                                  ,batch_size  = HP_BATCH_TEST
                                                  ,shuffle     = False
                                                  ,num_workers = 0
                                                  ,prefetch_factor = 2
                                                  )
    
    '''
    # data_x : image / data_y = label
    dataloader_train = custom_dataloader(in_path_dataset = PATH_BASE_IN
                                        ,in_category = NAME_FOLDER_TRAIN
                                        ,in_name_folder_image = NAME_FOLDER_IMAGES
                                        ,in_name_folder_label = NAME_FOLDER_LABELS
                                        ,in_dataset_loop = HP_DATASET_LOOP
                                        ,batch_size = HP_BATCH_TRAIN
                                        ,shuffle = True
                                        )

    dataloader_val =   custom_dataloader(in_path_dataset = PATH_BASE_IN
                                        ,in_category = NAME_FOLDER_VAL
                                        ,in_name_folder_image = NAME_FOLDER_IMAGES
                                        ,in_name_folder_label = NAME_FOLDER_LABELS
                                        ,batch_size = HP_BATCH_VAL
                                        ,shuffle = False
                                        )

    dataloader_test =  custom_dataloader(in_path_dataset = PATH_BASE_IN
                                        ,in_category = NAME_FOLDER_TEST
                                        ,in_name_folder_image = NAME_FOLDER_IMAGES
                                        ,in_name_folder_label = NAME_FOLDER_LABELS
                                        ,batch_size = HP_BATCH_TEST
                                        ,shuffle = False
                                        )
    '''
    
    # [Train & Val & Test]-----------------------------
    print("pause before init trainer")
    time.sleep(3)
        
    # 1 epoch 마다 시행할 mode list
    list_mode = ["train", "val", "test"]

    # 학습 전체 기록
    dict_log_total_train = {}
    dict_log_total_val = {}
    dict_log_total_test = {}

    # total log dict의 dict
    dict_dict_log_total = {list_mode[0]: dict_log_total_train
                          ,list_mode[1]: dict_log_total_val
                          ,list_mode[2]: dict_log_total_test
                          }

    for i_key in list_mode:
        tmp_str_labels =  "0(Sky),1(Building),2(Column_pole),3(Road),4(Sidewalk),5(Tree),"
        tmp_str_labels += "6(SignSymbol),7(Fence),8(Car),9(Pedestrian),10(Bicyclist)"
        update_dict_v2("epoch", "loss_(" + i_key + "),mIoU_(" +  i_key + ")," + tmp_str_labels
                      ,in_dict_dict = dict_dict_log_total
                      ,in_dict_key = i_key
                      ,in_print_head = "dict_log_total_" + i_key
                      )
    
    
    #<<< new_record_system
    # 학습 전체 기록
    d_log_total_train = {}
    d_log_total_val   = {}
    d_log_total_test  = {}
    
    # total log dict의 dict
    d_d_log_total = {list_mode[0]: d_log_total_train
                    ,list_mode[1]: d_log_total_val
                    ,list_mode[2]: d_log_total_test
                    }
    
    for i_key in list_mode:
        tmp_str_front = "loss_(" + i_key + "),PSNR_(" + i_key + "),SSIM_(" + i_key + "),NIQE_(" + i_key + ")"
        
        tmp_str_labels =  "0(Sky),1(Building),2(Column_pole),3(Road),4(Sidewalk),5(Tree),"
        tmp_str_labels += "6(SignSymbol),7(Fence),8(Car),9(Pedestrian),10(Bicyclist)"
        
        update_dict_v2("epoch", tmp_str_front + ",mIoU_(" +  i_key + ")," + tmp_str_labels
                      ,in_dict_dict = d_d_log_total
                      ,in_dict_key = i_key
                      ,in_print_head = "d_log_total_" + i_key
                      )
    
    #at .update_epoch(), set is_print_sub = True to see epoch info
    
    rb_train_loss = RecordBox(name = "train_loss", print_interval = 10, is_print = False)
    rb_train_psnr = RecordBox(name = "train_psnr", print_interval = 10, is_print = False)
    rb_train_ssim = RecordBox(name = "train_ssim", print_interval = 10, is_print = False)
    rb_train_niqe = RecordBox(name = "train_niqe", print_interval = 10, is_print = False)
    rb_train_ious = RecordBox4IoUs(name = "train_ious", print_interval = 10, is_print = False)
    
    rb_val_loss = RecordBox(name = "val_loss", is_print = False)
    rb_val_psnr = RecordBox(name = "val_psnr", is_print = False)
    rb_val_ssim = RecordBox(name = "val_ssim", is_print = False)
    rb_val_niqe = RecordBox(name = "val_niqe", is_print = False)
    rb_val_ious = RecordBox4IoUs(name = "val_ious", is_print = False)
    
    rb_test_loss = RecordBox(name = "test_loss", is_print = False)
    rb_test_psnr = RecordBox(name = "test_psnr", is_print = False)
    rb_test_ssim = RecordBox(name = "test_ssim", is_print = False)
    rb_test_niqe = RecordBox(name = "test_niqe", is_print = False)
    rb_test_ious = RecordBox4IoUs(name = "test_ious", is_print = False)
    
    
    calc_niqe = _calc_niqe()         # new niqe method
    #>>> new_record_system
    
    
    
    for i_epoch in range(HP_EPOCH):
        # train -> val -> test -> train ... 순환
        # epoch 단위 기록
        dict_log_epoch_train = {}
        dict_log_epoch_val = {}
        dict_log_epoch_test = {}
        
        # epoch log dict의 dict
        dict_dict_log_epoch = {list_mode[0]: dict_log_epoch_train
                              ,list_mode[1]: dict_log_epoch_val
                              ,list_mode[2]: dict_log_epoch_test
                              }
        
        #<<< new_record_system
        # epoch 단위 기록
        d_log_epoch_train = {}
        d_log_epoch_val   = {}
        d_log_epoch_test  = {}
        
        # epoch log dict의 dict
        d_d_log_epoch = {list_mode[0]: d_log_epoch_train
                        ,list_mode[1]: d_log_epoch_val
                        ,list_mode[2]: d_log_epoch_test
                        }
        
        #>>> new_record_system
        
        
        for i_mode in list_mode:
            print("--- init", i_mode, "---")
            # [공용 변수 초기화] ---
            # 오류 기록용 dict
            dict_log_error = {}
            update_dict_v2("", "오류 기록용 dict"
                          ,in_dict = dict_log_error
                          ,in_print_head = "dict_log_error"
                          ,is_print = False
                          )
            # 오류 발생여부 flag
            flag_error = 0
            
            #<<< #i_mode in list_mode
            # GPU 캐시 메모리 비우기
            torch.cuda.empty_cache()
            
            # 이번 epoch 첫 batch 여부 플래그
            flag_init_epoch = 0
            
            # 현재 batch 번호 (이미지 묶음 단위)
            i_batch = 0
            
            
            # 이번 epoch loss 총 합
            epoch_loss_sum = 0
            # 이번 epoch miou 총 합
            epoch_miou_sum = 0
            
            # epoch log dict 들의 머리글(표 최상단) 설정
            for i_key in list_mode:
                tmp_str_labels =  "0(Sky),1(Building),2(Column_pole),3(Road),4(Sidewalk),5(Tree),"
                tmp_str_labels += "6(SignSymbol),7(Fence),8(Car),9(Pedestrian),10(Bicyclist)"
                update_dict_v2(i_key + "_"+ str(i_epoch + 1), "batch_num,file_name,loss_batch,miou_image," + tmp_str_labels
                              ,in_dict_dict = dict_dict_log_epoch
                              ,in_dict_key = i_key
                              ,in_print_head = "dict_log_epoch_" + i_key
                              ,is_print = False
                              )
                
                
                #<<< new_record_system
                #epoch 번호 - batch 번호, 파일 이름, Loss PSRN SSIM NIQE mIoU IoUs
                update_dict_v2(i_key + "_"+ str(i_epoch + 1), "batch_num,file_name,Loss,PSNR,SSIM,NIQE,mIoU," + tmp_str_labels
                              ,in_dict_dict = d_d_log_epoch
                              ,in_dict_key = i_key
                              ,in_print_head = "d_log_epoch_" + i_key
                              ,is_print = False
                              )
                
                #>>> new_record_system
                
            # miou 와 라벨별 iou의 유효 개수 카운트 & 누적 합 (tuple로 구성된 dict)
            dict_ious_accumulate = {}
            
            
            #<<<
            #[모드별 변수 초기화] ---
            if i_mode == "train":
                #현재 모드 batch size 재설정 (생성할 patch 개수를 의미)
                current_batch_size = HP_BATCH_TRAIN
                #dataloader 설정
                if i_epoch != 0 and i_epoch % 10 == 0:
                    #re generate train dataset
                    dataset_train = Custom_Dataset_V3(# Return: dict key order -> 'file_name'
                                                      #                         , 'pil_img_hr', 'ts_img_hr', 'info_augm'
                                                      #                         , 'pil_lab_hr', 'ts_lab_hr'
                                                      #                         , 'pil_img_lr', 'ts_img_lr', 'info_deg'
                                                      name_memo                     = 'train'
                                                     ,in_path_dataset               = PATH_BASE_IN
                                                     ,in_category                   = NAME_FOLDER_TRAIN
                                                     ,in_name_folder_image          = NAME_FOLDER_IMAGES
                                                     
                                                      #--- options for train 
                                                     ,is_train                      = True
                                                      # below options can be skipped when above option is False
                                                     ,opt_augm_crop_init_range      = HP_AUGM_RANGE_CROP_INIT
                                                     ,opt_augm_rotate_max_degree    = HP_AUGM_ROTATION_MAX
                                                     ,opt_augm_prob_flip            = HP_AUGM_PROB_FLIP
                                                     ,opt_augm_prob_crop            = HP_AUGM_PROB_CROP
                                                     ,opt_augm_prob_rotate          = HP_AUGM_PROB_ROTATE
                                                     ,opt_augm_cj_brigntess         = HP_CJ_BRIGHTNESS
                                                     ,opt_augm_cj_contrast          = HP_CJ_CONTRAST
                                                     ,opt_augm_cj_saturation        = HP_CJ_SATURATION
                                                     ,opt_augm_cj_hue               = HP_CJ_HUE
                                                     
                                                      #--- options for HR label
                                                     ,is_return_label               = True
                                                      # below options can be skipped when above option is False
                                                     ,in_name_folder_label          = NAME_FOLDER_LABELS
                                                     ,label_number_total            = HP_LABEL_TOTAL
                                                     ,label_number_void             = HP_LABEL_VOID
                                                     ,is_label_dilated              = True
                                                     
                                                      #--- options for LR image
                                                     ,is_return_image_lr            = True
                                                      # below options can be skipped when above option is False
                                                     ,scalefactor                   = HP_DG_SCALE_FACTOR
                                                      # sub-option a : don't use with sub-option b
                                                      #,in_path_dlc                 = not used
                                                      #,in_name_dlc_csv             = not used
                                                      # sub-option b : don't use with sub-option a
                                                     ,opt_dg_blur                   = "Gaussian"
                                                     ,opt_dg_interpolation          = HP_DG_RESIZE_OPTION
                                                     ,opt_dg_noise                  = "Gaussian"
                                                     ,opt_dg_noise_sigma_range      = HP_DG_RANGE_NOISE_SIGMA
                                                     ,opt_dg_noise_gray_prob        = HP_DG_NOISE_GRAY_PROB
                                                     
                                                      #--- increase dataset length
                                                     ,in_dataset_loop               = HP_DATASET_LOOP
                                                     
                                                      #--- options for generate patch
                                                     ,is_patch                      = False
                                                     
                                                      #--- optionas for generate tensor
                                                     ,model_input_size              = (HP_MODEL_IMG_W, HP_MODEL_IMG_H)
                                                     ,transform_img                 = transform_to_ts_img
                                                     )
                    
                    dataloader_train = torch.utils.data.DataLoader(dataset     = dataset_train
                                                                  ,batch_size  = HP_BATCH_TRAIN
                                                                  ,shuffle     = True
                                                                  ,num_workers = 0
                                                                  ,prefetch_factor = 2
                                                                  ,drop_last = True
                                                                  )
                
                dataloader_input = dataloader_train
                #모델 모드 설정 (train / eval)
                model.train()
            elif i_mode == "val":
                #현재 모드 batch size 재설정
                # (trainer_dsrl에선 patch 생성 안함 = 전체 이미지를 단일 patch로 처리 -> 차량전방영상 Segm 특성때문에 patch 사용시 성능이 더 떨어짐)
                current_batch_size = HP_BATCH_VAL
                dataloader_input = dataloader_val
                model.eval()
            elif i_mode == "test":
                #현재 모드 batch size 재설정 (patch 생성 없이 원본 이미지 입력 시행)
                current_batch_size = HP_BATCH_TEST
                dataloader_input = dataloader_test
                model.eval()
            #>>>
            
            #전체 batch 개수
            i_batch_max = len(dataloader_input)
            
            print("\ncurrent_batch_size & total_batch_numbers", current_batch_size, i_batch_max)
            
            
            count_dataloader = 0
            
            '''
            # 결과병합 (PIL, 저장경로, 파일이름) 묶음 (초기화)
            try:
                del list_result_summary_pil_n_info
            except:
                pass
            
            list_result_summary_pil_n_info = []
            
            # cross-feature (PIL, 저장경로, 파일이름) 묶음 (초기화)
            try:
                del list_cross_feature_pil_n_info
            except:
                pass
            
            list_cross_feature_pil_n_info = []
            '''
            
            # MP 함수용 버퍼 (초기화)
            try:
                del list_mp_buffer
            except:
                pass
            list_mp_buffer = []
            
            
            
            # [train val test 공용 반복 구간] ---
            # x: 입력(이미지), y: 정답(라벨)
            for dataloader_items in dataloader_input:
                count_dataloader += 1
                # 이제 콘솔 출력 epoch 값과 실제 epoch 값이 동일함
                #print("", end = '\r')
                print("\rin", i_mode, (i_epoch + 1), count_dataloader, "/", i_batch_max, end = '')
                
                #print("number of items from dataloader:", len(dataloader_items), type(dataloader_items))
                
                #for i in range(len(dataloader_items)):
                #    print(i, type(dataloader_items[i]))
                
                #item distribute (length == batch size)
                if i_mode == "train":
                    dl_str_file_name    = dataloader_items[0]
                    dl_pil_img_hr_raw   = tensor_2_list_pils_v1(in_tensor = dataloader_items[1])
                    #resized or patch ver of RAW
                    dl_pil_img_hr       = tensor_2_list_pils_v1(in_tensor = dataloader_items[2])
                    dl_ts_img_hr        = dataloader_items[2].float()
                    dl_str_info_augm    = dataloader_items[3]
                    
                    dl_pil_lab_hr       = tensor_2_list_pils_v1(in_tensor = dataloader_items[4])
                    dl_ts_lab_hr        = dataloader_items[5].float()
                    
                    dl_pil_img_lr       = tensor_2_list_pils_v1(in_tensor = dataloader_items[6])
                    dl_ts_img_lr        = dataloader_items[7].float().requires_grad_(True)
                    dl_str_info_deg     = dataloader_items[8]
                    
                elif i_mode == "val":
                    dl_str_file_name    = dataloader_items[0]
                    dl_pil_img_hr_raw   = tensor_2_list_pils_v1(in_tensor = dataloader_items[1])
                    #resized or patch ver of RAW
                    dl_pil_img_hr       = tensor_2_list_pils_v1(in_tensor = dataloader_items[2])
                    dl_ts_img_hr        = dataloader_items[2].float()
                    dl_str_info_augm    = ["Not Train: no augmentation applied"]
                    
                    dl_pil_lab_hr       = tensor_2_list_pils_v1(in_tensor = dataloader_items[3])
                    dl_ts_lab_hr        = dataloader_items[4].float()
                    
                    dl_pil_img_lr       = tensor_2_list_pils_v1(in_tensor = dataloader_items[5])
                    dl_ts_img_lr        = dataloader_items[6].float()
                    dl_str_info_deg     = dataloader_items[7]
                    
                elif i_mode == "test":
                    dl_str_file_name    = dataloader_items[0]
                    dl_pil_img_hr_raw   = tensor_2_list_pils_v1(in_tensor = dataloader_items[1])
                    #resized or patch ver of RAW -> Test should same with RAW
                    dl_pil_img_hr       = tensor_2_list_pils_v1(in_tensor = dataloader_items[2])
                    dl_ts_img_hr        = dataloader_items[2].float()
                    dl_str_info_augm    = ["Not Train: no augmentation applied"]
                    
                    dl_pil_lab_hr       = tensor_2_list_pils_v1(in_tensor = dataloader_items[3])
                    dl_ts_lab_hr        = dataloader_items[4].float()
                    
                    dl_pil_img_lr       = tensor_2_list_pils_v1(in_tensor = dataloader_items[5])
                    dl_ts_img_lr        = dataloader_items[6].float()
                    dl_str_info_deg     = dataloader_items[7]
                    
                
                
                #print("\nDataloader 형태 확인")
                #print("dl_str_file_name", type(dl_str_file_name), dl_str_file_name)
                #print("dl_str_info_augm", type(dl_str_info_augm), dl_str_info_augm)
                #print("dl_str_info_deg",  type(dl_str_info_deg),  dl_str_info_deg)
                
                #print("dl_pil_img_hr", type(dl_pil_img_hr), len(dl_pil_img_hr))
                #print("dl_pil_lab_hr", type(dl_pil_lab_hr), len(dl_pil_lab_hr))
                #print("dl_pil_img_lr", type(dl_pil_img_lr), len(dl_pil_img_lr))
                
                #print("dl_ts_img_hr", type(dl_ts_img_hr), dl_ts_img_hr.shape)
                #print("dl_ts_lab_hr", type(dl_ts_lab_hr), dl_ts_lab_hr.shape)
                #initial input = (in_b, in_c, in_h, in_w) -> [2, 3, 90, 120]
                #print("dl_ts_img_lr", type(dl_ts_img_lr), dl_ts_img_lr.shape)
                
                #imshow_pil(dl_pil_img_hr[0])
                #imshow_pil(dl_pil_lab_hr[0])
                #imshow_pil(dl_pil_img_lr[0])
                
                dl_ts_img_hr = dl_ts_img_hr.to(device)
                dl_ts_lab_hr = dl_ts_lab_hr.to(device)
                dl_ts_img_lr = dl_ts_img_lr.to(device)
                
                
                
                if i_mode == "train":
                    if i_batch == 0:
                        # 기울기 초기화
                        optimizer.zero_grad()
                        print("optimizer.zero_grad()")
                    
                    with torch.cuda.amp.autocast(enabled=True):
                        #<<< AMP
                        in_batch_size, _, _, _ = dl_ts_img_lr.shape
                        if i_mode == "train" and in_batch_size != current_batch_size:
                            print("Batch size is not same with HyperParameter:", in_batch_size, current_batch_size)
                            sys.exit(-1)
                        
                        
                        if model_name == "DeepLab v3 plus":
                            # (tensor) Segm 결과, SR 결과, Segm feature map, SR feature map
                            tensor_out_seg, tensor_out_sr, tensor_out_ft_seg, tensor_out_ft_sr = model(dl_ts_img_lr)
                        elif model_name == "model_a" or model_name == "model_proposed":
                            # (tensor) Segm 결과, SR 결과, Restored 결과
                            tensor_out_seg, tensor_out_sr, tensor_out_lr = model(dl_ts_img_lr)
                        elif model_name == "model_d":
                            # (tensor) Segm 결과, SR 결과, Intermediate_Feature, Restored 결과
                            tensor_out_seg, tensor_out_sr, tensor_out_if, tensor_out_lr = model(dl_ts_img_lr)
                        elif model_name == "model_aa":
                            # (tensor) Segm 결과, SR 결과, Intermediate_Feature, Restored 결과(1,2)
                            tensor_out_seg, tensor_out_sr, tensor_out_if, tensor_out_lr_1, tensor_out_lr_2 = model(dl_ts_img_lr)
                        
                        
                        
                        # label 예측결과 softmax 시행
                        tensor_out_seg_softmax = F.softmax(tensor_out_seg, dim = 1)
                        # softmax 값을 바탕으로 label image 형태로 tensor 생성 (형태 변경 4D [B, C, H, W] -> 3D [B, H, W]) -> 이미지 생성에 사용됨
                        tensor_out_seg_label = torch.argmax(tensor_out_seg_softmax.clone().detach(), dim = 1)
                        
                        # loss 계산
                        if model_name == "DeepLab v3 plus":
                            # https://github.com/Dootmaan/DSRL/blob/1822d6469dd8cca4b61afc42daa6df98067b4f80/train.py#L111
                            # loss_segm + loss_sr + loss_FA 
                            
                            loss = criterion.calc(tensor_out_seg_softmax
                                                 ,tensor_out_sr
                                                 ,tensor_out_ft_seg
                                                 ,tensor_out_ft_sr
                                                 ,dl_ts_lab_hr
                                                 ,dl_ts_img_hr
                                                 ,is_AMP = True
                                                 )
                        elif model_name == "model_a" or model_name == "model_proposed":
                            loss = criterion.calc_v3(tensor_out_seg_softmax
                                                    ,tensor_out_sr
                                                    ,dl_ts_lab_hr
                                                    ,dl_ts_img_hr
                                                    ,is_AMP = True
                                                    #,cfa_sub_sample_rate = 8
                                                    )
                        
                        elif model_name == "model_d":
                            loss = criterion.calc_v3(tensor_out_seg_softmax
                                                    ,tensor_out_sr
                                                    ,tensor_out_lr
                                                    ,dl_ts_lab_hr
                                                    ,dl_ts_img_hr
                                                    ,is_AMP = True
                                                    )
                        
                        elif model_name == "model_aa":
                            loss = criterion.calc_v3(tensor_out_seg_softmax
                                                    ,tensor_out_sr
                                                    ,tensor_out_lr_1
                                                    ,tensor_out_lr_2
                                                    ,dl_ts_lab_hr
                                                    ,dl_ts_img_hr
                                                    ,is_AMP = True
                                                    )
                        
                        # SR 이미지텐서 역 정규화
                        if is_norm_in_transform_to_tensor:
                            tensor_out_sr = transform_ts_inv_norm(tensor_out_sr)
                    
                        #>>> AMP
                    
                    
                    
                    batch_loss = loss.item()
                    epoch_loss_sum += batch_loss
                    
                    #<<< new_record_system
                    rb_train_loss.add_item(loss.item())
                    #>>> new_record_system
                    
                    try:
                        # loss overflow, underflow 오류 방지
                        amp_scaler.scale(loss).backward()
                    except:
                        flag_error = 1
                        update_dict_v2("", "in " + str(i_epoch) + " " + str(i_batch)
                                      ,"", "loss.backward 실패():" + str(loss.item())
                                      ,in_dict = dict_log_error
                                      ,in_print_head = "dict_log_error"
                                      )
                    
                    # 가중치 갱신 (batch 마다)
                    #optimizer.step()
                    amp_scaler.step(optimizer)
                    #print("optimizer.step()", i_batch)
                    amp_scaler.update()
                    # 기울기 초기화
                    optimizer.zero_grad()
                    #print("optimizer.zero_grad()")
                    if HP_SCHEDULER_UPDATE_INTERVAL == "batch":
                        # 스케쥴러 갱신
                        scheduler.step()
                        print("scheduler.step()")
                    
                
                else: # val or test
                    with torch.no_grad():
                        #<<< @@@
                        if model_name == "DeepLab v3 plus":
                            # (tensor) Segm 결과, SR 결과, Segm feature map, SR feature map
                            tensor_out_seg, tensor_out_sr, tensor_out_ft_seg, tensor_out_ft_sr = model(dl_ts_img_lr)
                        elif model_name == "model_a" or model_name == "model_proposed":
                            # (tensor) Segm 결과, SR 결과, Restored 결과
                            tensor_out_seg, tensor_out_sr, tensor_out_lr = model(dl_ts_img_lr)
                        elif model_name == "model_d":
                            # (tensor) Segm 결과, SR 결과, Intermediate_Feature, Restored 결과
                            tensor_out_seg, tensor_out_sr, tensor_out_if, tensor_out_lr = model(dl_ts_img_lr)
                        elif model_name == "model_aa":
                            # (tensor) Segm 결과, SR 결과, Intermediate_Feature, Restored 결과(1,2)
                            tensor_out_seg, tensor_out_sr, tensor_out_if, tensor_out_lr_1, tensor_out_lr_2 = model(dl_ts_img_lr)
                        
                        #label 예측결과 softmax 시행
                        tensor_out_seg_softmax = F.softmax(tensor_out_seg, dim = 1)
                        # softmax 값을 바탕으로 label image 형태로 tensor 생성 (형태 변경 4D [B, C, H, W] -> 3D [B, H, W]) -> 이미지 생성에 사용됨
                        tensor_out_seg_label = torch.argmax(tensor_out_seg_softmax.clone().detach(), dim = 1)
                        
                        # loss 계산
                        if model_name == "DeepLab v3 plus":
                            # https://github.com/Dootmaan/DSRL/blob/1822d6469dd8cca4b61afc42daa6df98067b4f80/train.py#L111
                            # loss_segm + loss_sr + loss_FA 
                            
                            loss = criterion.calc(tensor_out_seg_softmax
                                                 ,tensor_out_sr
                                                 ,tensor_out_ft_seg
                                                 ,tensor_out_ft_sr
                                                 ,dl_ts_lab_hr
                                                 ,dl_ts_img_hr
                                                 ,is_AMP = True
                                                 )
                        elif model_name == "model_a" or model_name == "model_proposed":
                            loss = criterion.calc_v3(tensor_out_seg_softmax
                                                    ,tensor_out_sr
                                                    ,dl_ts_lab_hr
                                                    ,dl_ts_img_hr
                                                    ,is_AMP = True
                                                    #,cfa_sub_sample_rate = 8
                                                    )
                        elif model_name == "model_d":
                            loss = criterion.calc_v3(tensor_out_seg_softmax
                                                    ,tensor_out_sr
                                                    ,tensor_out_lr
                                                    ,dl_ts_lab_hr
                                                    ,dl_ts_img_hr
                                                    ,is_AMP = False
                                                    )
                        elif model_name == "model_aa":
                            loss = criterion.calc_v3(tensor_out_seg_softmax
                                                    ,tensor_out_sr
                                                    ,tensor_out_lr_1
                                                    ,tensor_out_lr_2
                                                    ,dl_ts_lab_hr
                                                    ,dl_ts_img_hr
                                                    ,is_AMP = False
                                                    )
                        
                        # SR 이미지텐서 역 정규화
                        if is_norm_in_transform_to_tensor:
                            tensor_out_sr = transform_ts_inv_norm(tensor_out_sr)
                        
                        #>>> @@@
                        
                        
                        batch_loss = loss.item()
                        epoch_loss_sum += batch_loss
                        
                        #<<< new_record_system
                        if i_mode == "val":
                            rb_val_loss.add_item(loss.item())
                        elif i_mode == "test":
                            rb_test_loss.add_item(loss.item())
                        #>>> new_record_system
                 
                #print("\nTensor 형태 확인")
                #print("tensor_out_seg", tensor_out_seg.shape)
                #print("tensor_out_sr", tensor_out_sr.shape)
                #print("tensor_out_ft_seg", tensor_out_ft_seg.shape)
                #print("tensor_out_ft_sr", tensor_out_ft_sr.shape)
                
                
                #VVV [Tensor -> model 예측결과 생성] -----------------------
                
                list_out_pil_label = tensor_2_list_pils_v1(# 텐서 -> pil 이미지 리스트
                                                           # (tensor) 변환할 텐서, 모델에서 다중 결과물이 생성되는 경우, 단일 출력물 묶음만 지정해서 입력 
                                                           # (예: MPRNet -> in_tensor = tensor_sr_hypo[0])
                                                           in_tensor = tensor_out_seg_label
                                                           
                                                           # (bool) 라벨 여부 (출력 pil 이미지 = 3ch, 라벨 = 1ch 고정) (default: False)
                                                          ,is_label = True
                                                           
                                                           # (bool) pil 이미지 크기 변환 시행여부 (default: False)
                                                          ,is_resized = False
                                                          )
                
                list_out_pil_sr = tensor_2_list_pils_v1(# 텐서 -> pil 이미지 리스트
                                                       # (tensor) 변환할 텐서, 모델에서 다중 결과물이 생성되는 경우, 단일 출력물 묶음만 지정해서 입력 
                                                       # (예: MPRNet -> in_tensor = tensor_sr_hypo[0])
                                                       in_tensor = tensor_out_sr
                                                       
                                                       # (bool) 라벨 여부 (출력 pil 이미지 = 3ch, 라벨 = 1ch 고정) (default: False)
                                                      ,is_label = False
                                                       
                                                       # (bool) pil 이미지 크기 변환 시행여부 (default: False)
                                                      ,is_resized = False
                                                      )
                
                if model_name == "DeepLab v3 plus":
                    
                    list_out_feature_ss = tensor_2_list_pils_v1(# 텐서 -> pil 이미지 리스트
                                                           # (tensor) 변환할 텐서, 모델에서 다중 결과물이 생성되는 경우, 단일 출력물 묶음만 지정해서 입력 
                                                           # (예: MPRNet -> in_tensor = tensor_sr_hypo[0])
                                                           in_tensor = tensor_out_ft_seg
                                                           
                                                           # (bool) 라벨 여부 (출력 pil 이미지 = 3ch, 라벨 = 1ch 고정) (default: False)
                                                          ,is_label = False
                                                           
                                                           # (bool) pil 이미지 크기 변환 시행여부 (default: False)
                                                          ,is_resized = False
                                                          )
                    
                    list_out_feature_sr = tensor_2_list_pils_v1(# 텐서 -> pil 이미지 리스트
                                                           # (tensor) 변환할 텐서, 모델에서 다중 결과물이 생성되는 경우, 단일 출력물 묶음만 지정해서 입력 
                                                           # (예: MPRNet -> in_tensor = tensor_sr_hypo[0])
                                                           in_tensor = tensor_out_ft_sr
                                                           
                                                           # (bool) 라벨 여부 (출력 pil 이미지 = 3ch, 라벨 = 1ch 고정) (default: False)
                                                          ,is_label = False
                                                           
                                                           # (bool) pil 이미지 크기 변환 시행여부 (default: False)
                                                          ,is_resized = False
                                                          )
                elif model_name == "model_a" or model_name == "model_proposed":
                    list_out_pil_lr = tensor_2_list_pils_v1(# 텐서 -> pil 이미지 리스트
                                                            # (tensor) 변환할 텐서, 모델에서 다중 결과물이 생성되는 경우, 단일 출력물 묶음만 지정해서 입력 
                                                            # (예: MPRNet -> in_tensor = tensor_sr_hypo[0])
                                                            in_tensor = tensor_out_lr
                                                            
                                                            # (bool) 라벨 여부 (출력 pil 이미지 = 3ch, 라벨 = 1ch 고정) (default: False)
                                                           ,is_label = False
                                                            
                                                            # (bool) pil 이미지 크기 변환 시행여부 (default: False)
                                                           ,is_resized = False
                                                           )
                
                elif model_name == "model_d" or model_name == "model_aa":
                    list_out_pil_if = tensor_2_list_pils_v1(# 텐서 -> pil 이미지 리스트
                                                            # (tensor) 변환할 텐서, 모델에서 다중 결과물이 생성되는 경우, 단일 출력물 묶음만 지정해서 입력 
                                                            # (예: MPRNet -> in_tensor = tensor_sr_hypo[0])
                                                            in_tensor = tensor_out_if
                                                            
                                                            # (bool) 라벨 여부 (출력 pil 이미지 = 3ch, 라벨 = 1ch 고정) (default: False)
                                                           ,is_label = False
                                                            
                                                            # (bool) pil 이미지 크기 변환 시행여부 (default: False)
                                                           ,is_resized = False
                                                           )
                
                
                #AAA [batch 단위 이미지 평가 (mIoU)] --------------------------
                # batch 이미지 들의 miou 누적변수
                batch_miou_sum = 0
                
                for i_image in range(current_batch_size):
                    
                    # 입력 x LR 이미지
                    # list_patch_pil_x[i_image] -> dl_pil_img_lr[i_image]
                    
                    # 입력 y HR 라벨 
                    # list_patch_pil_y[i_image] -> dl_pil_lab_hr[i_image]
                    
                    #라벨 예측결과를 원본 라벨 크기로 변환 ->  크기변환 없음
                    #pil_hypo_resized = list_out_pil_label[i_image]
                    
                    #mIoU 계산 (batch단위 평균값) (mIoU 연산에 사용한 이미지 수 = in_batch_size)
                    try:
                        tmp_miou, dict_ious = calc_miou_gray(pil_gray_answer  = dl_pil_lab_hr[i_image]
                                                            ,pil_gray_predict = list_out_pil_label[i_image]
                                                            ,int_total_labels = HP_LABEL_TOTAL
                                                            ,int_void_label = HP_LABEL_VOID
                                                            )
                    except:
                        print("(exc) mIoU 측정 실패")
                        imshow_pil(dl_pil_lab_hr[i_image])
                        imshow_pil(list_out_pil_label[i_image])
                        
                        print(dl_pil_lab_hr[i_image].size, list_out_pil_label[i_image].size)
                        print(np.max(np.array(dl_pil_lab_hr[i_image])), np.min(np.array(dl_pil_lab_hr[i_image])))
                        print(np.max(np.array(list_out_pil_label[i_image])), np.min(np.array(list_out_pil_label[i_image])))
                        
                        tmp_miou, dict_ious = calc_miou_gray(pil_gray_answer  = dl_pil_lab_hr[i_image]
                                                            ,pil_gray_predict = list_out_pil_label[i_image]
                                                            ,int_total_labels = HP_LABEL_TOTAL
                                                            ,int_void_label = HP_LABEL_VOID
                                                            )
                        sys.exit(9)
                    
                    batch_miou_sum += tmp_miou
                    
                    #<<< new_record_system
                    if i_mode == "train":
                        rb_train_ious.add_item(dict_ious)
                    elif i_mode == "val":
                        rb_val_ious.add_item(dict_ious)
                    elif i_mode == "test":
                        rb_test_ious.add_item(dict_ious)
                    #>>> new_record_system
                    
                    #--- PSNR SSIM NIQE
                    try:
                        out_psnr, out_ssim = calc_psnr_ssim(pil_original = dl_pil_img_hr[i_image]
                                                           ,pil_contrast = list_out_pil_sr[i_image]
                                                           )
                        
                    except:
                        print("(exc) PSRN SSIM calc FAIL")
                        out_psnr, out_ssim = -999, -999
                    
                    try:
                        # out_niqe = calc_niqe_with_pil(list_out_pil_sr[i_image])
                        out_niqe = calc_niqe.with_pil(list_out_pil_sr[i_image])
                    except:
                        print("(exc) NIQE calc FAIL")
                        out_niqe = -999
                    
                    
                    #<<< new_record_system
                    if i_mode == "train":
                        rb_train_psnr.add_item(out_psnr)
                        rb_train_ssim.add_item(out_ssim)
                        rb_train_niqe.add_item(out_niqe)
                    elif i_mode == "val":
                        rb_val_psnr.add_item(out_psnr)
                        rb_val_ssim.add_item(out_ssim)
                        rb_val_niqe.add_item(out_niqe)
                    elif i_mode == "test":
                        rb_test_psnr.add_item(out_psnr)
                        rb_test_ssim.add_item(out_ssim)
                        rb_test_niqe.add_item(out_niqe)
                    
                    #>>> new_record_system
                    
                    
                    
                    # 이미지 단위 로그 갱신
                    # "","batch_num,file_name,loss_batch,miou_image,[라벨별 iou]"
                    tmp_file_name = dl_str_file_name[i_image]
                    
                    tmp_ious = ""
                    for i_key in dict_ious:
                        tmp_ious += "," + dict_ious[i_key]
                    
                    
                    update_dict_v2("", str(count_dataloader) + "," + tmp_file_name + "," + str(batch_loss) + "," + str(tmp_miou) + tmp_ious
                                  ,in_dict_dict = dict_dict_log_epoch
                                  ,in_dict_key = i_mode
                                  ,in_print_head = "dict_log_epoch_" + i_mode
                                  ,is_print = False
                                  )
                    
                    #<<< new_record_system
                    #epoch 번호 - batch 번호, 파일 이름, Loss PSRN SSIM NIQE mIoU IoUs
                    #@@@
                    tmp_str_contents = (str(count_dataloader) + "," + tmp_file_name + "," + str(batch_loss) 
                                       +"," + str(out_psnr) + "," + str(out_ssim) + "," + str(out_niqe)
                                       +"," + str(tmp_miou) + tmp_ious
                                       )
                    
                    update_dict_v2("", tmp_str_contents
                                  ,in_dict_dict = d_d_log_epoch
                                  ,in_dict_key = i_mode
                                  ,in_print_head = "d_log_epoch_" + i_mode
                                  ,is_print = False
                                  )
                    
                    #>>> new_record_system
                    
                    # 이미지별 miou & ious 누적기록 업데이트
                    accumulate_dict_ious(dict_ious_accumulate, tmp_miou, dict_ious)
                    
                    #<<< 예측결과를 이미지로 생성
                    
                    if i_mode == "train":
                        if i_batch % (i_batch_max//20 + 1) == 0:
                            # epoch 마다 n 장 정도의 결과 이미지를 저장해봄
                            plt_title = "File name: " + dl_str_file_name[i_image]
                            plt_title += "\n" + dl_str_info_augm[i_image]
                            if option_apply_degradation:
                                # 현재 patch의 degrad- 옵션 불러오기
                                plt_title += "\n" + dl_str_info_deg[i_image]
                            plt_title += "\nPSNR: " + str(round(out_psnr, 4))
                            plt_title += "  SSIM: " + str(round(out_ssim, 4))
                            plt_title += "  NIQE: " + str(round(out_niqe, 4))
                            plt_title += "\nmIoU: " + str(round(tmp_miou, 4))
                            
                            tmp_bool = True
                        else:
                            tmp_bool = False
                    
                    elif i_mode == "test" and RUN_WHERE == -1:  #Test phase on colab
                        if i_batch % (i_batch_max//20 + 1) == 0:
                            # epoch 마다 n 장 정도의 결과 이미지를 저장해봄
                            plt_title = "File name: " + dl_str_file_name[i_image]
                            plt_title += "\n" + dl_str_info_augm[i_image]
                            if option_apply_degradation:
                                # 현재 patch의 degrad- 옵션 불러오기
                                plt_title += "\n" + dl_str_info_deg[i_image]
                            plt_title += "\nPSNR: " + str(round(out_psnr, 4))
                            plt_title += "  SSIM: " + str(round(out_ssim, 4))
                            plt_title += "  NIQE: " + str(round(out_niqe, 4))
                            plt_title += "\nmIoU: " + str(round(tmp_miou, 4))
                            
                            tmp_bool = True
                        else:
                            tmp_bool = False
                    
                    
                    else: # val or test
                        # 모든 이미지를 저장함
                        plt_title = "File name: " + dl_str_file_name[i_image]
                        if option_apply_degradation:
                            # 현재 patch의 degrad- 옵션 불러오기
                            plt_title += "\n" + dl_str_info_deg[i_image]
                        
                        plt_title += "\nPSNR: " + str(round(out_psnr, 4))
                        plt_title += "  SSIM: " + str(round(out_ssim, 4))
                        plt_title += "  NIQE: " + str(round(out_niqe, 4))
                        plt_title += "\nmIoU: " + str(round(tmp_miou, 4))
                        tmp_bool = True
                    
                    if tmp_bool:
                        tmp_file_name = (i_mode + "_" + str(i_epoch + 1) + "_" + str(i_batch + 1) + "_"
                                        +dl_str_file_name[i_image]
                                        )
                        
                        if model_name == "DeepLab v3 plus":
                        
                            pils_show_save(in_pil_1 = dl_pil_img_lr[i_image]
                                          ,in_pil_2 = label_2_RGB(dl_pil_lab_hr[i_image], HP_COLOR_MAP)
                                          ,in_pil_3 = label_2_RGB(list_out_pil_label[i_image], HP_COLOR_MAP)
                                          
                                          ,in_pil_4 = list_out_pil_sr[i_image]
                                          ,in_pil_5 = list_out_feature_sr[i_image]
                                          ,in_pil_6 = list_out_feature_ss[i_image]
                                          
                                          
                                           # (bool) 각 이미지 크기정보를 title_sub에 덧붙일것인가?
                                          ,is_add_size_info = True
                                          
                                          ,in_title_sub_1 = "LR Image"
                                          ,in_title_sub_2 = "Label Answer"
                                          ,in_title_sub_3 = "Predicted"
                                          
                                          ,in_title_sub_4 = "SR Image"
                                          ,in_title_sub_5 = "SR Feature Map"
                                          ,in_title_sub_6 = "SS Feature Map"
                                          
                                          ,show = False
                                          ,save = True
                                          ,path = PATH_OUT_IMAGE + i_mode + "/" + str(i_epoch + 1)
                                          ,name = tmp_file_name
                                          ,title = plt_title
                                          ,figsize = (21, 16)
                                          )
                        
                        elif model_name == "model_a" or model_name == "model_proposed":
                            
                            if len(list_mp_buffer) >= 60:
                                # chunk full -> toss mp_buffer -> empty mp_buffer
                                if i_mode == 'test':
                                    tmp_is_best = rb_val_psnr.is_best_max   #chunk 단위 buffer 구조상 valid 기준으로 best여부 검사
                                else:
                                    tmp_is_best = False
                                plts_saver(list_mp_buffer, is_best = tmp_is_best)
                                
                                try:
                                    del list_mp_buffer
                                except:
                                    pass
                                list_mp_buffer = []
                                
                            
                            list_mp_buffer.append((# 0 (model name)
                                                   model_name
                                                   # 1 ~ 6 (pils)
                                                  ,dl_pil_img_hr[i_image], label_2_RGB(dl_pil_lab_hr[i_image], HP_COLOR_MAP)
                                                  ,label_2_RGB(list_out_pil_label[i_image], HP_COLOR_MAP), dl_pil_img_lr[i_image]
                                                  ,list_out_pil_lr[i_image], list_out_pil_sr[i_image]
                                                   # 7 ~ 12 (sub title)
                                                  ,"HR Image", "Label Answer", "Predicted", "LR Image", "Intermediate Feature", "SR Image"
                                                   # 13 (path plt)
                                                  ,PATH_OUT_IMAGE + i_mode + "/" + str(i_epoch + 1)
                                                   # 14 ~ 17 (data CF)
                                                  ,tensor_out_seg_softmax[i_image].clone().detach().cpu()
                                                  ,tensor_out_sr[i_image].clone().detach().cpu()
                                                  ,dl_ts_lab_hr[i_image].clone().detach().cpu()
                                                  ,dl_ts_img_hr[i_image].clone().detach().cpu()
                                                   # 18 (path CF)
                                                  ,PATH_OUT_IMAGE + i_mode + "/_CrossFeature/" + str(i_epoch + 1)
                                                   # 19 (path pil)
                                                  ,PATH_OUT_IMAGE + i_mode + "/_SR_Images/" + str(i_epoch + 1)
                                                   # 20 (plt title)
                                                  ,plt_title
                                                   # 21 (file name)
                                                  ,tmp_file_name
                                                  )
                                                 )
                        
                        elif model_name == "model_d" or model_name == "model_aa":
                            
                            if len(list_mp_buffer) >= 60:
                                # chunk full -> toss mp_buffer -> empty mp_buffer
                                if i_mode == 'test':
                                    tmp_is_best = rb_val_psnr.is_best_max   #chunk 단위 buffer 구조상 valid 기준으로 best여부 검사
                                else:
                                    tmp_is_best = False
                                plts_saver(list_mp_buffer, is_best = tmp_is_best)
                                
                                try:
                                    del list_mp_buffer
                                except:
                                    pass
                                list_mp_buffer = []
                            
                            list_mp_buffer.append((# 0 (model name)
                                                   model_name
                                                   # 1 ~ 6 (pils)
                                                  ,dl_pil_img_hr[i_image], label_2_RGB(dl_pil_lab_hr[i_image], HP_COLOR_MAP)
                                                  ,label_2_RGB(list_out_pil_label[i_image], HP_COLOR_MAP), dl_pil_img_lr[i_image]
                                                  ,list_out_pil_if[i_image], list_out_pil_sr[i_image]
                                                   # 7 ~ 12 (sub title)
                                                  ,"HR Image", "Label Answer", "Predicted", "LR Image", "Intermediate Feature", "SR Image"
                                                   # 13 (path plt)
                                                  ,PATH_OUT_IMAGE + i_mode + "/" + str(i_epoch + 1)
                                                   # 14 ~ 17 (data CF)
                                                  ,tensor_out_seg_softmax[i_image].clone().detach().cpu()
                                                  ,tensor_out_sr[i_image].clone().detach().cpu()
                                                  ,dl_ts_lab_hr[i_image].clone().detach().cpu()
                                                  ,dl_ts_img_hr[i_image].clone().detach().cpu()
                                                   # 18 (path CF)
                                                  ,PATH_OUT_IMAGE + i_mode + "/_CrossFeature/" + str(i_epoch + 1)
                                                   # 19 (path pil)
                                                  ,PATH_OUT_IMAGE + i_mode + "/_SR_Images/" + str(i_epoch + 1)
                                                   # 20 (plt title)
                                                  ,plt_title
                                                   # 21 (file name)
                                                  ,tmp_file_name
                                                  )
                                                 )
                            
                        
                    #>>> 예측결과를 이미지로 생성
                    
                # 이번 batch의 평균 mIoU
                batch_miou_mean = batch_miou_sum / current_batch_size
                # epoch 단위 누적기록 갱신
                epoch_miou_sum += batch_miou_mean
                
                #VVV [batch 단위 이미지 평가 (mIoU)] --------------------------
                
                
                #<<< new_record_system
                if i_mode == "train":
                    rb_train_loss.update_batch()
                    rb_train_psnr.update_batch()
                    rb_train_ssim.update_batch()
                    rb_train_niqe.update_batch()
                    rb_train_ious.update_batch()
                elif i_mode == "val":
                    rb_val_loss.update_batch()
                    rb_val_psnr.update_batch()
                    rb_val_ssim.update_batch()
                    rb_val_niqe.update_batch()
                    rb_val_ious.update_batch()
                elif i_mode == "test":
                    rb_test_loss.update_batch()
                    rb_test_psnr.update_batch()
                    rb_test_ssim.update_batch()
                    rb_test_niqe.update_batch()
                    rb_test_ious.update_batch()
                    
                #>>> new_record_system
                
                
                i_batch += 1
                
            # End of "for path_x, path_y in dataloader_input:"
            # dataloader_input 종료됨
            
            # summary plt pil save
            if model_name == "model_a" or model_name == "model_proposed" or model_name == "model_d" or model_name == "model_aa":
                if not list_mp_buffer:
                    print("(caution) list_mp_buffer is emply...")
                else:
                    if i_mode == 'test':
                        tmp_is_best = rb_val_psnr.is_best_max   #chunk 단위 buffer 구조상 valid 기준으로 best여부 검사
                    else:
                        tmp_is_best = False
                    plts_saver(list_mp_buffer, is_best = tmp_is_best)
                    
                
            
            #<<< new_record_system
            if i_mode == "train":
                str_result_epoch_loss = str(rb_train_loss.update_epoch(is_return = True, is_print_sub = True))
                str_result_epoch_psnr = str(rb_train_psnr.update_epoch(is_return = True, is_print_sub = True))
                str_result_epoch_ssim = str(rb_train_ssim.update_epoch(is_return = True, is_print_sub = True))
                str_result_epoch_niqe = str(rb_train_niqe.update_epoch(is_return = True, is_print_sub = True))
                str_result_epoch_miou_ious = rb_train_ious.update_epoch(is_return = True, is_print_sub = True)
                
            elif i_mode == "val":
                str_result_epoch_loss = str(rb_val_loss.update_epoch(is_return = True, is_print_sub = True))
                str_result_epoch_psnr = str(rb_val_psnr.update_epoch(is_return = True, is_print_sub = True))
                str_result_epoch_ssim = str(rb_val_ssim.update_epoch(is_return = True, is_print_sub = True))
                str_result_epoch_niqe = str(rb_val_niqe.update_epoch(is_return = True, is_print_sub = True))
                str_result_epoch_miou_ious = rb_val_ious.update_epoch(is_return = True, is_print_sub = True)
                
            elif i_mode == "test":
                str_result_epoch_loss = str(rb_test_loss.update_epoch(is_return = True, is_print_sub = True))
                str_result_epoch_psnr = str(rb_test_psnr.update_epoch(is_return = True, is_print_sub = True))
                str_result_epoch_ssim = str(rb_test_ssim.update_epoch(is_return = True, is_print_sub = True))
                str_result_epoch_niqe = str(rb_test_niqe.update_epoch(is_return = True, is_print_sub = True))
                str_result_epoch_miou_ious = rb_test_ious.update_epoch(is_return = True, is_print_sub = True)
                
            
            # log total dict 업데이트
            tmp_str_contents = str_result_epoch_loss
            tmp_str_contents += "," + str_result_epoch_psnr + "," + str_result_epoch_ssim + "," + str_result_epoch_niqe
            tmp_str_contents += "," + str_result_epoch_miou_ious
            #epoch 번호 - Loss PSRN SSIM NIQE mIoU IoUs
            update_dict_v2(str(i_epoch + 1), tmp_str_contents
                          ,in_dict_dict = d_d_log_total
                          ,in_dict_key = i_mode
                          ,in_print_head = "d_log_total_" + i_mode
                          )
            print("\n")
            
            # log 기록 업데이트 (epoch 단위)
            dict_2_txt_v2(in_file_path = PATH_OUT_LOG + i_mode + "/"
                         ,in_file_name = "new_log_epoch_" + i_mode + "_" + str(i_epoch + 1) + ".csv"
                         ,in_dict_dict = d_d_log_epoch
                         ,in_dict_key = i_mode
                         )
            # log 기록 업데이트 (학습 전체 단위)
            dict_2_txt_v2(in_file_path = PATH_OUT_LOG
                         ,in_file_name = "new_log_total_" + i_mode + ".csv"
                         ,in_dict_dict = d_d_log_total
                         ,in_dict_key = i_mode
                         )
            
            
            
            #>>> new_record_system
            
            
            
            epoch_loss_mean = epoch_loss_sum / i_batch_max
            epoch_miou_mean = epoch_miou_sum / i_batch_max
            
            # 라벨별 iou 평균 계산
            tmp_str = ""
            for i_key in dict_ious_accumulate:
                tmp_count, tmp_iou_sum = dict_ious_accumulate[i_key][0], dict_ious_accumulate[i_key][-1]
                # print(tmp_count, tmp_iou_sum, str(tmp_iou_sum / tmp_count))
                tmp_str += "," + str(tmp_iou_sum / tmp_count)
            
            # log total dict 업데이트
            update_dict_v2(str(i_epoch + 1), str(epoch_loss_mean) + tmp_str
                          ,in_dict_dict = dict_dict_log_total
                          ,in_dict_key = i_mode
                          ,in_print_head = "dict_log_total_" + i_mode
                          )
            print("\n")
            
            # log 기록 업데이트 (epoch 단위)
            dict_2_txt_v2(in_file_path = PATH_OUT_LOG + i_mode + "/"
                         ,in_file_name = "log_epoch_" + i_mode + "_" + str(i_epoch + 1) + ".csv"
                         ,in_dict_dict = dict_dict_log_epoch
                         ,in_dict_key = i_mode
                         )
            # log 기록 업데이트 (학습 전체 단위)
            dict_2_txt_v2(in_file_path = PATH_OUT_LOG
                         ,in_file_name = "log_total_" + i_mode + ".csv"
                         ,in_dict_dict = dict_dict_log_total
                         ,in_dict_key = i_mode
                         )
            
            # epoch 단위 scheduler 갱신 -> state_dict & check_point 저장 
            if i_mode == "train":
                if HP_SCHEDULER_UPDATE_INTERVAL == "epoch":
                    # 스케쥴러 갱신
                    scheduler.step()
                    print("scheduler.step()")
                
                # state_dict 저장경로
                tmp_path = PATH_OUT_MODEL + "state_dicts/"
                if not os.path.exists(tmp_path):
                    os.makedirs(tmp_path)
                torch.save(model.state_dict()
                          ,tmp_path + str(i_epoch + 1) +'_model_dsrl_state_dict.pt'
                          )
                
                if i_epoch % 10 == 0:
                    tmp_path = PATH_OUT_MODEL + "check_points/"
                    if not os.path.exists(tmp_path):
                        os.makedirs(tmp_path)
                    # 모델 체크포인트 저장
                    torch.save({'epoch': (i_epoch + 1)                           # (int) 중단 시점 epoch 값
                               ,'model_state_dict': model.state_dict()        # (state_dict) model.state_dict()
                               ,'optimizer_state_dict': optimizer.state_dict()   # (state_dict) optimizer.state_dict()
                               ,'scheduler_state_dict': scheduler.state_dict()   # (state_dict) scheduler.state_dict()
                               }
                              ,tmp_path + str(i_epoch + 1) +'_check_point.tar'
                              )
                
                
            # 에러 발생했던 경우, 로그 저장
            if flag_error != 0:
                dict_2_txt(in_file_path = PATH_OUT_LOG + "error/"
                          ,in_file_name = "log_error_" + i_mode + "_" + str(i_epoch) + ".csv"
                          ,in_dict = dict_log_error
                          )
            
            # [epoch 완료 -> 변수 초기화] ---
            
            print("epoch 완료")
            i_batch = 0
            
            

#=== End of trainer_dsrl



print("End of trainer_dsrl.py")