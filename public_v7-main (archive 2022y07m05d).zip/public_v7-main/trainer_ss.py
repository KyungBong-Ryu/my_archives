# trainer_ss.py
# [memo] --------------
# https://pytorch.org/tutorials/recipes/recipes/amp_recipe.html
# AMP(Automatic Mixed Precision) 사용됨
# 2 Fold 데이터 분할 (Train 45% Val 5% Test 50%): CamVid_12_2Fold_v4

# [기본 라이브러리]----------------------
import os
import numpy as np
import random
import sys

import torch
import torch.nn.functional as F
import torch.optim as optim

import torchvision
import torchvision.transforms as transforms
from torchvision.transforms.functional import to_pil_image

import argparse
import matplotlib.pyplot as plt
from PIL import Image
import cv2

import time

# [py 파일]--------------------------
from data_load_n_save import *
from data_tool import *
from calc_func import *

# https://github.com/KyungBong-Ryu/Codes_implementation/blob/main/BasicSR_NIQE.py
from BasicSR_NIQE import calc_niqe_with_pil

#<<< @@@ trainer_ss


def trainer_ss(**kargs):
    '''#========================================#
    trainer_ss(# <patch를 통해 학습 & RGB 이미지를 생성하는 모델>#
               # 초기화 기록 dict 이어받기
              ,dict_log_init = 
               # 랜덤 시드 고정
              ,HP_SEED = HP_SEED
              
              
               # 학습 관련 기본 정보(epoch 수, batch 크기(train은 생성할 patch 수), 학습 시 dataset 루프 횟수)
              ,HP_EPOCH = HP_EPOCH
              ,HP_BATCH_TRAIN_SS = HP_BATCH_TRAIN_SS
              ,HP_DATASET_LOOP_SS = HP_DATASET_LOOP_SS
              ,HP_BATCH_VAL = HP_BATCH_VAL
              ,HP_BATCH_TEST = HP_BATCH_TEST
              
              
               # 데이터 입출력 경로, 폴더명
              ,PATH_BASE_IN = PATH_BASE_IN
              ,NAME_FOLDER_TRAIN = NAME_FOLDER_TRAIN
              ,NAME_FOLDER_VAL = NAME_FOLDER_VAL
              ,NAME_FOLDER_TEST = NAME_FOLDER_TEST
              ,NAME_FOLDER_IMAGES = NAME_FOLDER_IMAGES
              ,NAME_FOLDER_LABELS = NAME_FOLDER_LABELS
              
               # (선택) degraded image 불러올 경로
              ,PATH_BASE_IN_SUB = PATH_BASE_IN_SUB
              
              ,PATH_OUT_IMAGE = PATH_OUT_IMAGE
              ,PATH_OUT_MODEL = PATH_OUT_MODEL
              ,PATH_OUT_LOG = PATH_OUT_LOG
              
              
               # 데이터(이미지) 입출력 크기 (원본 이미지, 모델 입력 이미지), 이미지 채널 수(이미지, 라벨, 모델출력물)
              ,HP_ORIGIN_IMG_W = HP_ORIGIN_IMG_W
              ,HP_ORIGIN_IMG_H = HP_ORIGIN_IMG_H
              ,HP_MODEL_SS_IMG_W = HP_MODEL_SS_IMG_W
              ,HP_MODEL_SS_IMG_H = HP_MODEL_SS_IMG_H
              ,HP_CHANNEL_RGB = HP_CHANNEL_RGB
              ,HP_CHANNEL_GRAY = HP_CHANNEL_GRAY
              ,HP_CHANNEL_HYPO = HP_CHANNEL_HYPO
              
               # 라벨 정보(원본 데이터 라벨 수(void 포함), void 라벨 번호, 컬러매핑)
              ,HP_LABEL_TOTAL = HP_LABEL_TOTAL
              ,HP_LABEL_VOID = HP_LABEL_VOID
              ,HP_COLOR_MAP = HP_COLOR_MAP
              
               # 모델 이름 -> 모델에 따라 예측결과 형태가 다르기에 모델입출력물을 조정하는 역할
               # 지원 리스트 = (의미없음)"DeeplabV3Plus"
              ,model_ss_name = model_ss_name
              
               # model, optimizer, scheduler, loss
              ,model_ss = model_ss
              ,optimizer = optimizer
              ,scheduler = scheduler
              ,criterion_ss = criterion_ss
               # 스케쥴러 업데이트 간격("epoch" 또는 "batch")
              ,HP_SCHEDULER_UPDATE_INTERVAL_SS = HP_SCHEDULER_UPDATE_INTERVAL_SS
              
              
               # DataAugm- 관련 (colorJitter 포함)
              ,HP_AUGM_RANGE_CROP_INIT = HP_AUGM_RANGE_CROP_INIT
              ,HP_AUGM_ROTATION_MAX = HP_AUGM_ROTATION_MAX
              ,HP_AUGM_PROB_FLIP = HP_AUGM_PROB_FLIP
              ,HP_AUGM_PROB_CROP = HP_AUGM_PROB_CROP
              ,HP_AUGM_PROB_ROTATE = HP_AUGM_PROB_ROTATE
              ,HP_CJ_BRIGHTNESS = HP_CJ_BRIGHTNESS
              ,HP_CJ_CONTRAST = HP_CJ_CONTRAST
              ,HP_CJ_SATURATION = HP_CJ_SATURATION
              ,HP_CJ_HUE = HP_CJ_HUE
              
              
               # 이미지 -> 텐서 시 norm 관련 (정규화 시행여부, 평균, 표준편차)
              ,is_norm_in_transform_to_tensor = 
              ,HP_TS_NORM_MEAN = HP_TS_NORM_MEAN
              ,HP_TS_NORM_STD = HP_TS_NORM_STD
              
              
               # Degradation 관련
               # (bool) 학습 & 평가 시 Degradaded Input 사용 여부
              ,option_apply_degradation = 
               # (귀속) Degradation 기타 설정값
              ,HP_DG_CSV_NAME = HP_DG_CSV_NAME
              ,HP_DG_SCALE_FACTOR = HP_DG_SCALE_FACTOR
              ,HP_DG_RESIZE_OPTION = HP_DG_RESIZE_OPTION
              ,HP_DG_RANGE_NOISE_SIGMA = HP_DG_RANGE_NOISE_SIGMA
              ,HP_DG_NOISE_GRAY_PROB = HP_DG_NOISE_GRAY_PROB
              
              )
    
    '''#========================================#
    # calc_miou_gray 함수의 dict_ious 결과물을 하나의 dict에 누적시키는 함수
    # 범용성이 떨어져서 trainer_ss 함수에서 선언함
    # 누적할 dict, miou 값(float), iou dict
    def accumulate_dict_ious(dict_accumulate, miou, dict_ious):
        # 형태 = "dict_ious와 동일한 key" : (유효 iou 수, iou 누적값)
        # dict_accumulate = kargs['dict_accumulate']

        # dict_ious = kargs['dict_ious']
        
        if "miou" in dict_accumulate:
            item_current = dict_accumulate["miou"]
        else:
            item_current = (0,0)
            
        dict_accumulate["miou"] = (item_current[0] + 1, item_current[1] + miou)
        
        for i_key in dict_ious:
            # 초기값 불러오기
            if i_key in dict_accumulate:
                # 유효한 key 인 경우
                item_current = dict_accumulate[i_key]
            else:
                # key가 존재하지 않았을 경우
                item_current = (0,0)
            
            if dict_ious[i_key] == "NaN":
                # 현재 라벨에 대한 값이 유효하지 않은 경우
                item_new = item_current
            else:
                # 현재 라벨에 대한 값이 유효한 경우
                item_new = (item_current[0] + 1, item_current[1] + float(dict_ious[i_key]))
            
            # dict 업데이트
            dict_accumulate[i_key] = item_new
        
    #=== End of accumulate_dict_ious
    
    
    # [최우선 초기화요소 시행]------------------------
    # log dict 이어받기
    dict_log_init = kargs['dict_log_init']
    
    # 사용 decive 설정
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # 랜덤 시드(seed) 적용
    HP_SEED = kargs['HP_SEED']
    random.seed(HP_SEED)
    np.random.seed(HP_SEED)
    # pytorch 랜덤시드 고정 (CPU)
    torch.manual_seed(HP_SEED)
    
    
    update_dict_v2("", ""
                  ,"", "랜덤 시드값 (random numpy pytorch)"
                  ,"", "HP_SEED: " + str(HP_SEED)
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    if device == 'cuda':
        # pytorch 랜덤시드 고정 (GPU & multi-GPU)
        torch.cuda.manual_seed(HP_SEED)
        torch.cuda.manual_seed_all(HP_SEED)
    
    # epoch 수
    HP_EPOCH = kargs['HP_EPOCH']
    # batch 크기 & (train) 데이터셋 루프 횟수
    HP_BATCH_TRAIN_SS = kargs['HP_BATCH_TRAIN_SS']
    HP_DATASET_LOOP_SS = kargs['HP_DATASET_LOOP_SS']
    HP_BATCH_VAL = kargs['HP_BATCH_VAL']
    HP_BATCH_TEST = kargs['HP_BATCH_TEST']
    
    update_dict_v2("", ""
                  ,"", "최대 epoch 설정: " + str(HP_EPOCH)
                  ,"", "batch 크기"
                  ,"", "HP_BATCH_TRAIN_SS: " + str(HP_BATCH_TRAIN_SS)
                  ,"", "학습 시 데이터셋 반복횟수"
                  ,"", "HP_DATASET_LOOP_SS: " + str(HP_DATASET_LOOP_SS)
                  ,"", "그래디언트 축적(Gradient Accumulation) 사용 안함"
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    # [입출력 Data 관련]-----------------------------
    # 경로: 입력
    PATH_BASE_IN = kargs['PATH_BASE_IN']
    NAME_FOLDER_TRAIN = kargs['NAME_FOLDER_TRAIN']
    NAME_FOLDER_VAL = kargs['NAME_FOLDER_VAL']
    NAME_FOLDER_TEST = kargs['NAME_FOLDER_TEST']
    NAME_FOLDER_IMAGES = kargs['NAME_FOLDER_IMAGES']
    NAME_FOLDER_LABELS = kargs['NAME_FOLDER_LABELS']
    
    
    
    
    # 경로: 출력
    PATH_OUT_IMAGE = kargs['PATH_OUT_IMAGE']
    PATH_OUT_MODEL = kargs['PATH_OUT_MODEL']
    PATH_OUT_LOG = kargs['PATH_OUT_LOG']
    
    
    # 원본 이미지 크기
    HP_ORIGIN_IMG_W = kargs['HP_ORIGIN_IMG_W']
    HP_ORIGIN_IMG_H = kargs['HP_ORIGIN_IMG_H']
    # 이미지 모델입력 크기 (train & val & test)
    HP_MODEL_SS_IMG_W = kargs['HP_MODEL_SS_IMG_W']
    HP_MODEL_SS_IMG_H = kargs['HP_MODEL_SS_IMG_H']
    # 이미지&라벨&모델출력물 채널 수
    HP_CHANNEL_RGB = kargs['HP_CHANNEL_RGB']
    HP_CHANNEL_GRAY = kargs['HP_CHANNEL_GRAY']
    HP_CHANNEL_HYPO = kargs['HP_CHANNEL_HYPO']
    
    # 라벨 정보
    HP_LABEL_TOTAL = kargs['HP_LABEL_TOTAL']
    HP_LABEL_VOID = kargs['HP_LABEL_VOID']
    HP_COLOR_MAP = kargs['HP_COLOR_MAP']
    
    update_dict_v2("", ""
                  ,"", "원본 Dataset 이미지 크기"
                  ,"", "HP_ORIGIN_IMG_(W H): (" + str(HP_ORIGIN_IMG_W) + " " + str(HP_ORIGIN_IMG_H) + ")"
                  ,"", "모델 입출력 이미지 크기 (train val test)"
                  ,"", "HP_MODEL_SS_IMG_(W H): (" + str(HP_MODEL_SS_IMG_W) + " " + str(HP_MODEL_SS_IMG_H) + ")"
                  ,"", "이미지 채널 수 (이미지): " + str(HP_CHANNEL_RGB)
                  ,"", "이미지 채널 수 (라벨): " + str(HP_CHANNEL_GRAY)
                  ,"", "이미지 채널 수 (모델출력물): " + str(HP_CHANNEL_HYPO)
                  ,"", "원본 데이터 라벨 수(void 포함): " + str(HP_LABEL_TOTAL)
                  ,"", "void 라벨 번호: " + str(HP_LABEL_VOID)
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    # 라벨 정보 (CamVid 12)
    update_dict_v2("", ""
                  ,"", "라벨 별 RGB 매핑"
                  ,"", "0:  [128 128 128]  # 00 sky"
                  ,"", "1:  [128   0   0]  # 01 building"
                  ,"", "2:  [192 192 128]  # 02 column_pole"
                  ,"", "3:  [128  64 128]  # 03 road"
                  ,"", "4:  [  0   0 192]  # 04 sidewalk"
                  ,"", "5:  [128 128   0]  # 05 Tree"
                  ,"", "6:  [192 128 128]  # 06 SignSymbol"
                  ,"", "7:  [ 64  64 128]  # 07 Fence"
                  ,"", "8:  [ 64   0 128]  # 08 Car"
                  ,"", "9:  [ 64  64   0]  # 09 Pedestrian"
                  ,"", "10: [  0 128 192]  # 10 Bicyclist"
                  ,"", "11: [  0   0   0]  # 11 Void"
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    
    
    # [model, 모델 추가정보, optimizer, scheduler, loss]--------------------
    #<<< 
    #    현재 지원되는 모델 리스트
    #    1. (의미없음) DeeplabV3Plus
    #       
    #
    model_ss_name = kargs['model_ss_name']
    #>>>
    
    model_ss = kargs['model_ss']
    
    update_dict_v2("", ""
                  ,"", "모델 종류: " + str(model_ss_name)
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    optimizer = kargs['optimizer']
    scheduler = kargs['scheduler']
    HP_SCHEDULER_UPDATE_INTERVAL_SS = kargs['HP_SCHEDULER_UPDATE_INTERVAL_SS']
    # loss
    criterion_ss = kargs['criterion_ss']
    
    # [Automatic Mixed Precision 선언] ---
    amp_scaler = torch.cuda.amp.GradScaler(enabled = True)
    update_dict_v2("", ""
                  ,"", "Automatic Mixed Precision 사용됨"
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    # [data augmentation 관련]--------------------
    
    HP_AUGM_RANGE_CROP_INIT = kargs['HP_AUGM_RANGE_CROP_INIT']
    HP_AUGM_ROTATION_MAX = kargs['HP_AUGM_ROTATION_MAX']
    HP_AUGM_PROB_FLIP = kargs['HP_AUGM_PROB_FLIP']
    HP_AUGM_PROB_CROP = kargs['HP_AUGM_PROB_CROP']
    HP_AUGM_PROB_ROTATE  = kargs['HP_AUGM_PROB_ROTATE']
    # colorJitter 관련
    # https://pytorch.org/vision/master/generated/torchvision.transforms.ColorJitter.html#torchvision.transforms.ColorJitter
    HP_CJ_BRIGHTNESS = kargs['HP_CJ_BRIGHTNESS']
    HP_CJ_CONTRAST   = kargs['HP_CJ_CONTRAST']
    HP_CJ_SATURATION = kargs['HP_CJ_SATURATION']
    HP_CJ_HUE        = kargs['HP_CJ_HUE']
    
    transform_cj = transforms.ColorJitter(brightness = HP_CJ_BRIGHTNESS
                                         ,contrast   = HP_CJ_CONTRAST
                                         ,saturation = HP_CJ_SATURATION
                                         ,hue        = HP_CJ_HUE
                                         )
    
    update_dict_v2("", ""
                  ,"", "ColorJitter 설정"
                  ,"", "brightness: ( " + " ".join([str(t_element) for t_element in HP_CJ_BRIGHTNESS]) +" )"
                  ,"", "contrast:   ( " + " ".join([str(t_element) for t_element in HP_CJ_CONTRAST])   +" )"
                  ,"", "saturation: ( " + " ".join([str(t_element) for t_element in HP_CJ_SATURATION]) +" )"
                  ,"", "hue:        ( " + " ".join([str(t_element) for t_element in HP_CJ_HUE])        +" )"
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    # [이미지 변수 -> 텐서 변수 변환]-------------------
    # 정규화 여부
    is_norm_in_transform_to_tensor = kargs['is_norm_in_transform_to_tensor']
    
    if is_norm_in_transform_to_tensor:
        # 평균
        HP_TS_NORM_MEAN = kargs['HP_TS_NORM_MEAN']
        # 표준편차
        HP_TS_NORM_STD = kargs['HP_TS_NORM_STD']
        # 입력 이미지 텐서 변환 후 정규화 시행
        transform_to_ts_img = transforms.Compose([# PIL 이미지 or npArray -> pytorch 텐서
                                                  transforms.ToTensor()
                                                  # 평균, 표준편차를 활용해 정규화
                                                 ,transforms.Normalize(mean = HP_TS_NORM_MEAN, std = HP_TS_NORM_STD)
                                                 ,
                                                 ])
        
        # 역정규화 변환
        transform_ts_inv_norm = transforms.Compose([# PIL 이미지 or npArray -> pytorch 텐서
                                                    transforms.ToTensor()
                                                    
                                                   ,transforms.Normalize(mean = [ 0., 0., 0. ]
                                                                        ,std = [ 1/HP_TS_NORM_STD[0], 1/HP_TS_NORM_STD[1], 1/HP_TS_NORM_STD[2] ])
                                                     
                                                   ,transforms.Normalize(mean = [ -HP_TS_NORM_MEAN[0], -HP_TS_NORM_MEAN[1], -HP_TS_NORM_MEAN[2] ]
                                                                        ,std = [ 1., 1., 1. ])
                                                                        
                                                   ,
                                                   ])
        
        update_dict_v2("", ""
                      ,"", "입력 이미지(in_x) 정규화 시행됨"
                      ,"", "mean=[ " + str(HP_TS_NORM_MEAN[0]) + " " + str(HP_TS_NORM_MEAN[1]) + " "+ str(HP_TS_NORM_MEAN[2]) + " ]"
                      ,"", "std=[ " + str(HP_TS_NORM_STD[0]) + " " + str(HP_TS_NORM_STD[1]) + " "+ str(HP_TS_NORM_STD[2]) + " ]"
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
    else:
        # 정규화 없이 이미지를 텐서형으로 변환
        transform_to_ts_img = transforms.Compose([# PIL 이미지 or npArray -> pytorch 텐서
                                                  # https://pytorch.org/vision/stable/generated/torchvision.transforms.ToTensor.html#torchvision.transforms.ToTensor
                                                  # 일반적인 경우 (PIL mode: L, LA, P, I, F, RGB, YCbCr, RGBA, CMYK, 1 또는 numpy.ndarray), 
                                                  # (H x W x C) in the range [0, 255] 입력 데이터를
                                                  # (C x H x W) in the range [0.0, 1.0] 출력 데이터로 변환함 (scaled)
                                                  transforms.ToTensor()
                                                 ])
        
        update_dict_v2("", ""
                      ,"", "입력 이미지(in_x) 정규화 시행 안함"
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
    
    # [Degradation 관련]-------------------------------
    # (bool) 학습 & 평가 시 Degradaded Input 사용 여부
    option_apply_degradation = kargs['option_apply_degradation']
    
    if option_apply_degradation:
        # "Train & Test 과정에 Degradation 시행 됨"
        
        try:
            PATH_BASE_IN_SUB = kargs['PATH_BASE_IN_SUB']
            HP_DG_CSV_NAME = kargs['HP_DG_CSV_NAME']
            if not PATH_BASE_IN_SUB[-1] == "/":
                PATH_BASE_IN_SUB += "/"
            
            dict_loaded_pils = load_pils_2_dict(# 경로 내 pil 이미지를 전부 불러와서 dict 형으로 묶어버림
                                                # (str) 파일 경로
                                                in_path = PATH_BASE_IN_SUB
                                                # (선택, str) 파일 경로 - 하위폴더명
                                               ,in_path_sub = NAME_FOLDER_IMAGES
                                               )
            print("Pre-Degraded images loaded from:", PATH_BASE_IN_SUB + NAME_FOLDER_IMAGES)
            
            dict_dg_csv = csv_2_dict(path_csv = PATH_BASE_IN_SUB + HP_DG_CSV_NAME)
            print("Pre-Degrade option csv re-loaded from:", PATH_BASE_IN_SUB + HP_DG_CSV_NAME)
            
            flag_pre_degraded_images_loaded = True
            tmp_log_pre_degraded_images_load = "Degraded 이미지를 불러왔습니다."
        except:
            print("(exc) Pre-Degraded images load FAIL")
            flag_pre_degraded_images_loaded = False
            tmp_log_pre_degraded_images_load = "Degraded 이미지를 불러오지 않습니다."
        
        update_dict_v2("", ""
                      ,"", "Degraded 이미지 옵션: " + tmp_log_pre_degraded_images_load
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
        
        # 고정옵션 dict
        HP_DG_CSV_NAME = kargs['HP_DG_CSV_NAME']
        HP_DG_CSV_PATH = PATH_BASE_IN + HP_DG_CSV_NAME
        dict_dg_csv = csv_2_dict(path_csv = HP_DG_CSV_PATH)
        
        # scale_factor 고정값
        HP_DG_SCALE_FACTOR = kargs['HP_DG_SCALE_FACTOR']
        # resize (downscale) 옵션
        HP_DG_RESIZE_OPTION = kargs['HP_DG_RESIZE_OPTION']
        
        # Gaussian 노이즈 시그마 범위
        HP_DG_RANGE_NOISE_SIGMA = kargs['HP_DG_RANGE_NOISE_SIGMA']
        # Gray 노이즈 확률 (%)
        HP_DG_NOISE_GRAY_PROB = kargs['HP_DG_NOISE_GRAY_PROB']
        
        update_dict_v2("", ""
                      ,"", "Degradation 관련"
                      ,"", "시행여부: " + "Train & Test 과정에 Degradation 시행 됨"
                      ,"", "DG 지정값 파일 경로: " + HP_DG_CSV_PATH
                      ,"", "Scale Factor 고정값 = x" + str(HP_DG_SCALE_FACTOR)
                      ,"", "Resize 옵션 = " + HP_DG_RESIZE_OPTION
                      ,"", "Gaussian 노이즈 시그마 범위 = [ " + str(HP_DG_RANGE_NOISE_SIGMA[0]) + " " + str(HP_DG_RANGE_NOISE_SIGMA[-1]) + " ]"
                      ,"", "노이즈 종류 (Color or Gray 중 Gray 노이즈 확률 = " + str(HP_DG_NOISE_GRAY_PROB)
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
        
        
    else:
        # "Train & Test 과정에 Degradation 시행 안됨"
        update_dict_v2("", ""
                      ,"", "Degradation 관련"
                      ,"", "시행여부: " + "Train & Test 과정에 Degradation 시행 안됨"
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
    
    
    dict_2_txt_v2(in_file_path = PATH_OUT_LOG
                 ,in_file_name = "log_init.csv"
                 ,in_dict = dict_log_init
                 )
    
    
    # [data & model load]--------------------------
    # data_x : image / data_y = label
    dataloader_train = custom_dataloader(in_path_dataset = PATH_BASE_IN
                                        ,in_category = NAME_FOLDER_TRAIN
                                        ,in_name_folder_image = NAME_FOLDER_IMAGES
                                        ,in_name_folder_label = NAME_FOLDER_LABELS
                                        ,in_dataset_loop = HP_DATASET_LOOP_SS
                                        ,batch_size = HP_BATCH_TRAIN_SS
                                        ,shuffle = True
                                        )

    dataloader_val =   custom_dataloader(in_path_dataset = PATH_BASE_IN
                                        ,in_category = NAME_FOLDER_VAL
                                        ,in_name_folder_image = NAME_FOLDER_IMAGES
                                        ,in_name_folder_label = NAME_FOLDER_LABELS
                                        ,batch_size = HP_BATCH_VAL
                                        ,shuffle = False
                                        )

    dataloader_test =  custom_dataloader(in_path_dataset = PATH_BASE_IN
                                        ,in_category = NAME_FOLDER_TEST
                                        ,in_name_folder_image = NAME_FOLDER_IMAGES
                                        ,in_name_folder_label = NAME_FOLDER_LABELS
                                        ,batch_size = HP_BATCH_TEST
                                        ,shuffle = False
                                        )
    
    
    # [Train & Val & Test]-----------------------------
    print("pause before init trainer_ss")
    time.sleep(10)
        
    # 1 epoch 마다 시행할 mode list
    list_mode = ["train", "val", "test"]

    # 학습 전체 기록
    dict_log_total_train = {}
    dict_log_total_val = {}
    dict_log_total_test = {}

    # total log dict의 dict
    dict_dict_log_total = {list_mode[0]: dict_log_total_train
                          ,list_mode[1]: dict_log_total_val
                          ,list_mode[2]: dict_log_total_test
                          }

    for i_key in list_mode:
        tmp_str_labels =  "0(Sky),1(Building),2(Column_pole),3(Road),4(Sidewalk),5(Tree),"
        tmp_str_labels += "6(SignSymbol),7(Fence),8(Car),9(Pedestrian),10(Bicyclist)"
        update_dict_v2("epoch", "loss_(" + i_key + "),mIoU_(" +  i_key + ")," + tmp_str_labels
                      ,in_dict_dict = dict_dict_log_total
                      ,in_dict_key = i_key
                      ,in_print_head = "dict_log_total_" + i_key
                      )
    
    
    for i_epoch in range(HP_EPOCH):
        # train -> val -> test -> train ... 순환
        # epoch 단위 기록
        dict_log_epoch_train = {}
        dict_log_epoch_val = {}
        dict_log_epoch_test = {}
        
        # epoch log dict의 dict
        dict_dict_log_epoch = {list_mode[0]: dict_log_epoch_train
                              ,list_mode[1]: dict_log_epoch_val
                              ,list_mode[2]: dict_log_epoch_test
                              }
        
        
        for i_mode in list_mode:
            print("--- init", i_mode, "---")
            # [공용 변수 초기화] ---
            # 오류 기록용 dict
            dict_log_error = {}
            update_dict_v2("", "오류 기록용 dict"
                          ,in_dict = dict_log_error
                          ,in_print_head = "dict_log_error"
                          )
            # 오류 발생여부 flag
            flag_error = 0
            
            #<<< #i_mode in list_mode
            # GPU 캐시 메모리 비우기
            torch.cuda.empty_cache()
            
            # 이번 epoch 첫 batch 여부 플래그
            flag_init_epoch = 0
            
            # 현재 batch 번호 (이미지 묶음 단위)
            i_batch = 0
            
            
            # 이번 epoch loss 총 합
            epoch_loss_sum = 0
            # 이번 epoch miou 총 합
            epoch_miou_sum = 0
            
            # epoch log dict 들의 머리글(표 최상단) 설정
            for i_key in list_mode:
                tmp_str_labels =  "0(Sky),1(Building),2(Column_pole),3(Road),4(Sidewalk),5(Tree),"
                tmp_str_labels += "6(SignSymbol),7(Fence),8(Car),9(Pedestrian),10(Bicyclist)"
                update_dict_v2(i_key + "_"+ str(i_epoch + 1), "batch_num,file_name,loss_batch,miou_image," + tmp_str_labels
                              ,in_dict_dict = dict_dict_log_epoch
                              ,in_dict_key = i_key
                              ,in_print_head = "dict_log_epoch_" + i_key
                              )
            
            # miou 와 라벨별 iou의 유효 개수 카운트 & 누적 합 (tuple로 구성된 dict)
            dict_ious_accumulate = {}
            
            
            #<<<
            #[모드별 변수 초기화] ---
            if i_mode == "train":
                #현재 모드 batch size 재설정 (생성할 patch 개수를 의미)
                current_batch_size = HP_BATCH_TRAIN_SS
                #dataloader 설정
                dataloader_input = dataloader_train
                #모델 모드 설정 (train / eval)
                model_ss.train()
            elif i_mode == "val":
                #현재 모드 batch size 재설정 (trainer_SS에선 patch 생성 안함)
                current_batch_size = HP_BATCH_VAL
                dataloader_input = dataloader_val
                model_ss.eval()
            elif i_mode == "test":
                #현재 모드 batch size 재설정 (patch 생성 없이 원본 이미지 입력 시행)
                current_batch_size = HP_BATCH_TEST
                dataloader_input = dataloader_test
                model_ss.eval()
            #>>>
            
            #전체 batch 개수
            i_batch_max = len(dataloader_input)
            
            print("current_batch_size & total_batch_numbers", current_batch_size, i_batch_max)
            
            
            
            
            count_dataloader = 0
            
            # [train val test 공용 반복 구간] ---
            # x: 입력(이미지), y: 정답(라벨)
            for path_x, path_y in dataloader_input:
                count_dataloader += 1
                # 이제 콘솔 출력 epoch 값과 실제 epoch 값이 동일함
                print("\nin", i_mode, (i_epoch + 1), count_dataloader, "/", len(dataloader_input))
                #print("\nin", i_mode, i_epoch, count_dataloader, "/", len(dataloader_input))
                
                # data augm- 옵션 기록 관련 (초기화)
                str_used_option = ""
                list_option_data_augm_total = []
                
                # degraded 옵션 기록 관련 (초기화)
                option_degrad_total = ""
                list_option_degrad_total = []
                
                # 생성된 이미지 저장용 list (초기화)
                list_patch_pil_x = []
                list_patch_pil_y = []
                
                for i_image in range(len(path_x)):
                # Segmentation은 이미지 전체를 하나의 patch로 가정한다.
                #AAA [list_patch_pil_x (이미지) & list_patch_pil_y (라벨) 생성] -------------------------------
                    # [데이터 불러오기] --------------------------------
                    # i_image = 0 ~ (batch 크기 - 1)
                    in_pil_x_raw = Image.open(path_x[i_image])
                    in_pil_y_raw = Image.open(path_y[i_image])
                    
                    if i_mode == "train":
                        # Data Augm- 시행 (우선 x & y 동일 이미지 저장 -> 이후에 degrad 시행)
                        in_pil_x_augm, in_pil_y_augm, str_used_option = pil_augm_v3(in_pil_x = in_pil_x_raw
                                                                                   ,in_option_resize_x = Image.LANCZOS
                                                                                   ,in_option_rotate_x = Image.BICUBIC
                                                                                   ,in_pil_y = in_pil_y_raw
                                                                                   ,in_option_resize_y = Image.NEAREST
                                                                                   ,in_option_rotate_y = Image.NEAREST
                                                                                   ,in_crop_wh_min = HP_AUGM_RANGE_CROP_INIT[0]
                                                                                   ,in_crop_wh_max = HP_AUGM_RANGE_CROP_INIT[-1]
                                                                                   ,in_rotate_degree_max = HP_AUGM_ROTATION_MAX
                                                                                   ,in_percent_flip = HP_AUGM_PROB_FLIP
                                                                                   ,in_percent_crop = HP_AUGM_PROB_CROP
                                                                                   ,in_percent_rotate = HP_AUGM_PROB_ROTATE
                                                                                   ,is_return_options = True
                                                                                   )
                        
                        list_option_data_augm_total.append("(Data Augm) " + str_used_option)
                        
                        in_pil_x_input = transform_cj(in_pil_x_augm)
                        in_pil_y_input = in_pil_y_augm
                        
                    else: # val, test
                        # Data Augm- 생략 (우선 x & y 동일 이미지 저장 -> 이후에 degrad 시행)
                        in_pil_x_input = in_pil_x_raw
                        in_pil_y_input = in_pil_y_raw
                    
                    if option_apply_degradation:
                        # Degrad- 시행 (Tr, Val, Ts 공통) (결과물 -> x: LR)
                        
                        # Degrade fix값 불러오기 (val or test에만 사용)
                        list_dg_csv = dict_dg_csv[path_x[i_image].split("/")[-1]]
                        
                        tmp_is_load = False
                        if i_mode == "train":
                            is_fixed_noise_mode = False
                            
                        else: # val test
                            if flag_pre_degraded_images_loaded:
                                tmp_is_load = True
                                
                            else:
                                is_fixed_noise_mode = True
                        
                        
                        if tmp_is_load: # Degraded 이미지를 불러온 경우 (Val & Test)
                            in_pil_x_input = dict_loaded_pils[path_x[i_image].split("/")[-1]]
                            
                            if HP_DG_CSV_NAME == "degradation_2.csv":
                                #degradation_2.csv
                                option_degrad_1st = "\n(Pre-Degraded) Blur = Gaussian, Downscale(" + tmp_scale_factor
                                option_degrad_1st += ") = " + HP_DG_RESIZE_OPTION + ", Noise = (Gaussian, " + list_dg_csv[0]
                                option_degrad_1st += ", mu = 0, Sigma = " + list_dg_csv[1] + ")"
                            else:
                                option_degrad_1st = "\n(Pre-Degraded) check csv option"
                            
                        else: # Degraded 이미지를 불러오지 않은 경우
                            # 1st degrad- (HR(y) -> LR(x))
                            in_pil_x_input, option_degrad_1st = degradation_total_v7(in_pil = in_pil_x_input
                                                                                    ,is_return_options = True
                                                                                     #---블러
                                                                                    ,in_option_blur = "Gaussian"
                                                                                     #---다운 스케일
                                                                                    ,in_scale_factor = HP_DG_SCALE_FACTOR
                                                                                    ,in_option_resize = HP_DG_RESIZE_OPTION
                                                                                     #---노이즈 (Gaussian 고정)
                                                                                    ,in_option_noise = "Gaussian"
                                                                                     # 노이즈 시그마값 범위 (tuple)
                                                                                    ,in_range_noise_sigma = HP_DG_RANGE_NOISE_SIGMA
                                                                                     # Gray 노이즈 (v 채널 노이즈) 확룔 (int)
                                                                                    ,in_percent_gray_noise = HP_DG_NOISE_GRAY_PROB
                                                                                     # 노이즈 고정값 옵션
                                                                                    ,is_fixed_noise = is_fixed_noise_mode
                                                                                    ,in_fixed_noise_channel = list_dg_csv[0]
                                                                                    ,in_fixed_noise_sigma   = list_dg_csv[1]
                                                                                    )
                            
                            option_degrad_total = "(Degradation) " + option_degrad_1st 
                            #print("option_degrad_total:", option_degrad_total)
                        
                        list_option_degrad_total.append(option_degrad_total)
                        
                        #<<< SS 모델은 Degraded 이미지를 "HP_DG_RESIZE_OPTION" 옵션으로 원본 크기로 복원한 후에 입력
                        in_pil_x_input = pil_resize(in_pil = in_pil_x_input
                                                   ,out_w = HP_ORIGIN_IMG_W
                                                   ,out_h = HP_ORIGIN_IMG_H
                                                   ,option = HP_DG_RESIZE_OPTION
                                                   )
                        #>>> SS 모델은 Degraded 이미지를 "HP_DG_RESIZE_OPTION" 옵션으로 원본 크기로 복원한 후에 입력
                    
                    # [이하 (이미지)in_pil_x_input & (라벨)in_pil_y_input 사용] -----
                    list_patch_pil_x.append(in_pil_x_input)
                    list_patch_pil_y.append(in_pil_y_input)
                    
                    
                #VVV [list_patch_pil_x (이미지) & list_patch_pil_y (라벨) 생성] -------------------------------
                #>>> for i_image in range(len(path_x)): 끝
                
                # print("최종 생성된 patch 묶음 길이:", len(list_patch_pil_x), ",", len(list_patch_pil_y))
                
                #AAA [patch list -> Tensor 변환] ---------------------------------
                
                if i_mode =="train" and i_batch == 0:
                    # 기울기 초기화
                    optimizer.zero_grad()
                    print("optimizer.zero_grad()")
                
                tensor_x = pils_2_tensor_v1(#(list - pil) list로 묶인 PIL 이미지 묶음을 pytorch tensor로 변환해줌
                                            #label should be GRAY
                                            list_pils = list_patch_pil_x
                                           
                                            #(int) pil 이미지 채널 수 (Color = 3, Gray = 1)
                                           ,pil_channels = HP_CHANNEL_RGB
                                           
                                            #(bool) 라벨 여부 (one-hot 변환여부 결정) (default: False)
                                           ,is_label = False
                                           
                                            #(bool) pil 이미지 크기 변환 시행여부 (default: False)
                                           ,is_resized = True
                                            #(귀속) (tuple) pil 변환결과 크기 (w, h)
                                           ,resized_size = (HP_MODEL_SS_IMG_W, HP_MODEL_SS_IMG_H)
                                            #(귀속) (str) interpolation 방식 ("NEAREST", "BILINEAR", "BICUBIC", "LANCZOS")
                                           ,resized_method = "LANCZOS"
                                           
                                            #(transforms) pil to tensor 함수 (label은 자동으로 ToTensor 고정)
                                           ,transforms_to_tensor = transform_to_ts_img
                                            #(bool) requires grad 여부
                                           ,is_requires_grad = True
                                           )
                
                
                tensor_y = pils_2_tensor_v1(#(list - pil) list로 묶인 PIL 이미지 묶음을 pytorch tensor로 변환해줌
                                            #label should be GRAY
                                            list_pils = list_patch_pil_y
                                           
                                            #(int) pil 이미지 채널 수 (Color = 3, Gray = 1)
                                           ,pil_channels = HP_CHANNEL_GRAY
                                           
                                            #(bool) 라벨 여부 (one-hot 변환여부 결정) (default: False)
                                           ,is_label = True
                                            #(귀속) (int) 전체 라벨 수 (void 포함)
                                           ,label_total = HP_LABEL_TOTAL
                                            #(귀속) (int) void 라벨 번호
                                           ,label_void = HP_LABEL_VOID
                                            #(귀속) (bool) 라벨 스무딩 적용여부
                                           ,is_label_dilated = True
                                           
                                            #(bool) pil 이미지 크기 변환 시행여부 (default: False)
                                           ,is_resized = True
                                            #(귀속) (tuple) pil 변환결과 크기 (w, h)
                                           ,resized_size = (HP_MODEL_SS_IMG_W, HP_MODEL_SS_IMG_H)
                                            #(귀속) (str) interpolation 방식 ("NEAREST", "BILINEAR", "BICUBIC", "LANCZOS")
                                           ,resized_method = "NEAREST"
                                           
                                            #(transforms) pil to tensor 함수 (label은 자동으로 ToTensor 고정)
                                           ,transforms_to_tensor = transform_to_ts_img
                                            #(bool) requires grad 여부
                                           ,is_requires_grad = False
                                           )
                
                #VVV [patch list -> Tensor 변환] ---------------------------------
                
                
                #AAA [Tensor -> model_ss 예측결과 생성] -----------------------
                in_batch_size, _, _, _ = tensor_x.shape
                if i_mode == "train" and in_batch_size != current_batch_size:
                    print("Batch size is not same with HyperParameter:", in_batch_size, current_batch_size)
                    print("Use HP_DATASET_LOOP option to match these values")
                    sys.exit(-1)
                
                tensor_x = tensor_x.to(device)
                tensor_y = tensor_y.to(device)
                
                if i_mode == "train":
                    with torch.cuda.amp.autocast(enabled=True):
                    #<<< AMP
                        tensor_hypo = model_ss(tensor_x)
                        tensor_hypo_softmax = F.softmax(tensor_hypo, dim = 1)
                        # softmax 값을 바탕으로 label image 형태로 tensor 생성 (형태 변경 4D [B, C, H, W] -> 3D [B, H, W])
                        tensor_hypo_label = torch.argmax(tensor_hypo_softmax, dim = 1)
                        # loss 계산
                        loss = criterion_ss(tensor_hypo_softmax, tensor_y)
                    #>>> AMP
                    batch_loss = loss.item()
                    epoch_loss_sum += batch_loss
                    
                    try:
                        # loss overflow, underflow 오류 방지
                        amp_scaler.scale(loss).backward()
                    except:
                        flag_error = 1
                        update_dict_v2("", "in " + str(i_epoch) + " " + str(i_batch)
                                      ,"", "loss.backward 실패():" + str(loss.item())
                                      ,in_dict = dict_log_error
                                      ,in_print_head = "dict_log_error"
                                      )
                    
                    # 가중치 갱신 (batch 마다)
                    #optimizer.step()
                    amp_scaler.step(optimizer)
                    #print("optimizer.step()", i_batch)
                    amp_scaler.update()
                    # 기울기 초기화
                    optimizer.zero_grad()
                    #print("optimizer.zero_grad()")
                    if HP_SCHEDULER_UPDATE_INTERVAL_SS == "batch":
                        # 스케쥴러 갱신
                        scheduler.step()
                        print("scheduler.step()")
                    
                else: # val or test
                    with torch.no_grad():
                        tensor_hypo = model_ss(tensor_x)
                        tensor_hypo_softmax = F.softmax(tensor_hypo, dim = 1)
                        # softmax 값을 바탕으로 label image 형태로 tensor 생성 (형태 변경 4D [B, C, H, W] -> 3D [B, H, W])
                        tensor_hypo_label = torch.argmax(tensor_hypo_softmax, dim = 1)
                        # loss 계산
                        loss = criterion_ss(tensor_hypo_softmax, tensor_y)
                        
                        batch_loss = loss.item()
                        epoch_loss_sum += batch_loss
                 
                #VVV [Tensor -> model_ss 예측결과 생성] -----------------------
                
                #AAA [batch 단위 이미지 평가 (mIoU)] --------------------------
                # batch 이미지 들의 miou 누적변수
                batch_miou_sum = 0
                
                for i_image in range(current_batch_size):
                    # 입력 x 이미지
                    # list_patch_pil_x[i_image]
                    # 입력 y 라벨
                    # list_patch_pil_y[i_image]
                    
                    
                    
                    #라벨 예측결과를 원본 라벨 크기로 변환
                    pil_hypo_resized = pil_resize(in_pil = Image.fromarray(tensor_hypo_label.detach().cpu().numpy()[i_image].astype('uint8'))
                                                 ,option = "NEAREST"
                                                 ,in_w = HP_ORIGIN_IMG_W
                                                 ,in_h = HP_ORIGIN_IMG_H
                                                 ,out_w = HP_MODEL_SS_IMG_W
                                                 ,out_h = HP_MODEL_SS_IMG_H
                                                 ,is_reverse = True
                                                 )
                    
                    #mIoU 계산 (batch단위 평균값) (mIoU 연산에 사용한 이미지 수 = in_batch_size)
                    try:
                        tmp_miou, dict_ious = calc_miou_gray(pil_gray_answer  = list_patch_pil_y[i_image]
                                                            ,pil_gray_predict = pil_hypo_resized
                                                            ,int_total_labels = HP_LABEL_TOTAL
                                                            ,int_void_label = HP_LABEL_VOID
                                                            )
                    except:
                        print("mIoU 측정 실패")
                        imshow_pil(list_patch_pil_y[i_image])
                        imshow_pil(pil_hypo_resized)
                        
                        print(list_patch_pil_y[i_image].size, pil_hypo_resized.size)
                        print(np.max(np.array(list_patch_pil_y[i_image])), np.min(np.array(list_patch_pil_y[i_image])))
                        print(np.max(np.array(pil_hypo_resized)), np.min(np.array(pil_hypo_resized)))
                        
                        tmp_miou, dict_ious = calc_miou_gray(pil_gray_answer  = list_patch_pil_y[i_image]
                                                            ,pil_gray_predict = pil_hypo_resized
                                                            ,int_total_labels = HP_LABEL_TOTAL
                                                            ,int_void_label = HP_LABEL_VOID
                                                            )
                        sys.exit(9)
                    
                    batch_miou_sum += tmp_miou
                    
                    # 이미지 단위 로그 갱신
                    # "","batch_num,file_name,loss_batch,miou_image,[라벨별 iou]"
                    tmp_file_name = path_x[i_image].split("/")[-1].split(".")[0]
                    
                    tmp_ious = ""
                    for i_key in dict_ious:
                        tmp_ious += "," + dict_ious[i_key]
                    
                    # 연산결과 출력여부 결정
                    if i_mode == "train":
                        if i_batch % (i_batch_max//20 + 1) == 0:
                            tmp_is_print = True
                        else:
                            tmp_is_print = False
                    else: # "val" or "test"
                        tmp_is_print = True
                    
                    update_dict_v2("", str(count_dataloader) + "," + tmp_file_name + "," + str(batch_loss) + "," + str(tmp_miou) + tmp_ious
                                  ,in_dict_dict = dict_dict_log_epoch
                                  ,in_dict_key = i_mode
                                  ,in_print_head = "dict_log_epoch_" + i_mode
                                  ,is_print = tmp_is_print
                                  )
                    
                    # 이미지별 miou & ious 누적기록 업데이트
                    accumulate_dict_ious(dict_ious_accumulate, tmp_miou, dict_ious)
                    
                    #<<< 예측결과를 이미지로 생성
                    
                    if i_mode == "train":
                        if i_batch % (i_batch_max//20 + 1) == 0:
                            # epoch 마다 n 장 정도의 결과 이미지를 저장해봄
                            plt_title = "File name: " + path_x[i_image].split("/")[-1] 
                            plt_title += "\n" + list_option_data_augm_total[i_image]
                            if option_apply_degradation:
                                # 현재 patch의 degrad- 옵션 불러오기
                                plt_title += "\n" + list_option_degrad_total[i_image]
                            plt_title += "\nmIoU: " + str(tmp_miou)
                            
                            tmp_bool = True
                        else:
                            tmp_bool = False

                    else: # val or test
                        # 모든 이미지를 저장함
                        plt_title = "File name: " + path_x[i_image].split("/")[-1]
                        if option_apply_degradation:
                            # 현재 patch의 degrad- 옵션 불러오기
                            plt_title += "\n" + list_option_degrad_total[i_image]
                        plt_title += "\nmIoU: " + str(tmp_miou)
                        tmp_bool = True
                    
                    if tmp_bool:
                        pils_show_save(in_pil_1 = list_patch_pil_x[i_image]
                                      ,in_pil_2 = label_2_RGB(list_patch_pil_y[i_image], HP_COLOR_MAP)
                                      ,in_pil_3 = label_2_RGB(pil_hypo_resized, HP_COLOR_MAP)
                                       # (bool) 각 이미지 크기정보를 title_sub에 덧붙일것인가?
                                      ,is_add_size_info = True
                                      
                                      ,in_title_sub_1 = "Image"
                                      ,in_title_sub_2 = "Label"
                                      ,in_title_sub_3 = "Predicted"
                                      ,show = False
                                      ,save = True
                                      ,path = PATH_OUT_IMAGE + i_mode + "/" + str(i_epoch + 1)
                                      ,name = i_mode + "_" + str(i_epoch + 1) + "_" + path_x[i_image].split("/")[-1].split(".")[0] + ".png"
                                      ,title = plt_title
                                      ,figsize = (21, 10)
                                      )
                    
                    #>>> 예측결과를 이미지로 생성
                    
                # 이번 batch의 평균 mIoU
                batch_miou_mean = batch_miou_sum / current_batch_size
                # epoch 단위 누적기록 갱신
                epoch_miou_sum += batch_miou_mean
                
                #VVV [batch 단위 이미지 평가 (mIoU)] --------------------------
                
                try:
                    del tensor_x
                    del tensor_y
                    del tensor_hypo
                except:
                    print("일부 변수 삭제 실패")
                
                i_batch += 1
                
            # End of "for path_x, path_y in dataloader_input:"
            # dataloader_input 종료됨
            
            epoch_loss_mean = epoch_loss_sum / i_batch_max
            epoch_miou_mean = epoch_miou_sum / i_batch_max
            
            # 라벨별 iou 평균 계산
            tmp_str = ""
            for i_key in dict_ious_accumulate:
                tmp_count, tmp_iou_sum = dict_ious_accumulate[i_key][0], dict_ious_accumulate[i_key][-1]
                print(tmp_count, tmp_iou_sum, str(tmp_iou_sum / tmp_count))
                tmp_str += "," + str(tmp_iou_sum / tmp_count)
            
            # log total dict 업데이트
            update_dict_v2(str(i_epoch + 1), str(epoch_loss_mean) + tmp_str
                          ,in_dict_dict = dict_dict_log_total
                          ,in_dict_key = i_mode
                          ,in_print_head = "dict_log_total_" + i_mode
                          )
            
            
            # log 기록 업데이트 (epoch 단위)
            dict_2_txt_v2(in_file_path = PATH_OUT_LOG + i_mode + "/"
                         ,in_file_name = "log_epoch_" + i_mode + "_" + str(i_epoch + 1) + ".csv"
                         ,in_dict_dict = dict_dict_log_epoch
                         ,in_dict_key = i_mode
                         )
            # log 기록 업데이트 (학습 전체 단위)
            dict_2_txt_v2(in_file_path = PATH_OUT_LOG
                         ,in_file_name = "log_total_" + i_mode + ".csv"
                         ,in_dict_dict = dict_dict_log_total
                         ,in_dict_key = i_mode
                         )
            
            # epoch 단위 scheduler 갱신 -> state_dict & check_point 저장 
            if i_mode == "train":
                if HP_SCHEDULER_UPDATE_INTERVAL_SS == "epoch":
                    # 스케쥴러 갱신
                    scheduler.step()
                    print("scheduler.step()")
                
                # state_dict 저장경로
                tmp_path = PATH_OUT_MODEL + "state_dicts/"
                if not os.path.exists(tmp_path):
                    os.makedirs(tmp_path)
                torch.save(model_ss.state_dict()
                          ,tmp_path + str(i_epoch + 1) +'_model_ss_state_dict.pt'
                          )
                
                if i_epoch % 10 == 0:
                    tmp_path = PATH_OUT_MODEL + "check_points/"
                    if not os.path.exists(tmp_path):
                        os.makedirs(tmp_path)
                    # 모델 체크포인트 저장
                    torch.save({'epoch': (i_epoch + 1)                           # (int) 중단 시점 epoch 값
                               ,'model_state_dict': model_ss.state_dict()        # (state_dict) model.state_dict()
                               ,'optimizer_state_dict': optimizer.state_dict()   # (state_dict) optimizer.state_dict()
                               ,'scheduler_state_dict': scheduler.state_dict()   # (state_dict) scheduler.state_dict()
                               }
                              ,tmp_path + str(i_epoch + 1) +'_check_point.tar'
                              )
                
                
            # 에러 발생했던 경우, 로그 저장
            if flag_error != 0:
                dict_2_txt(in_file_path = PATH_OUT_LOG + "error/"
                          ,in_file_name = "log_error_" + i_mode + "_" + str(i_epoch) + ".csv"
                          ,in_dict = dict_log_error
                          )
            
            # [epoch 완료 -> 변수 초기화] ---
            try:
                del loss
                del tensor_x
                del tensor_y
                del tensor_hypo
            except:
                print("(-1) 일부 변수 삭제 실패")
            print("epoch 완료")
            i_batch = 0
            
            

#=== End of trainer_ss



print("End of trainer_ss.py")
