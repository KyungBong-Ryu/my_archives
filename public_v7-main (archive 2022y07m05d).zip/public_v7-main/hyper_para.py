#hyper_para.py
#version 7_1
#변수명 변경됨 (HP_DG_NOISE_SIGMA -> HP_DG_RANGE_NOISE_SIGMA)
import time
import datetime as dt
import numpy as np
import os
import sys
#*****************
#(데이터셋 경로)
#PATH_BASE_IN + NAME_FOLDER_DATASET + "/" + NAME_FOLDER_(TRAIN/VAL/TEST)

#현재 online(colab) train은 지원 안됨
#*****************

"""
#폴더 형태
"Drive Name"
    LAB
        _RUN_on_N
        datasets
            project_use
                "name_dataset"
                    train
                        images
                        labels
                    val
                        images
                        labels
                    test
                        images
                        labels
                        
                "name_dataset_DLC"
                    "name_sub"
                        images
                        labels
                
        result_files
            "name_project"
                logs
                    train
                    val
                    test
                models
                    chech_point
                    state_dict
                images
                    train
                        "epoch_number"
                    val
                        "epoch_number"
                    test
                        "epoch_number"
        for_tests
            model_state_dict
"""

print("init hyper_para.py")

dt_now = dt.datetime.now()

#코드 테스트 목적인 경우, True
#is_sample = True
is_sample = False

#---(HP 0) 경로 설정 관련

#(str) 실행 날짜 기록
HP_INIT_DATE_TIME = str(dt_now.year) + " 년 " + str(dt_now.month) + " 월 " + str(dt_now.day) + " 일"

#[수정 가능 변수]--------------------
#(-9): CPU, C drive 환경 -> not ready yet
#(-1): 온라인 환경
#0: 새 컴퓨터 (vram 8) / 1: 집 컴퓨터 (vram 12) / 2:연구실 컴퓨터 (vram 8)
RUN_WHERE = -1

#불러올 데이터셋 폴더 이름
#NAME_FOLDER_DATASET = "name_dataset"
NAME_FOLDER_DATASET = "CamVid_12_2Fold_v4/A_set"
#NAME_FOLDER_DATASET = "CamVid_12_2Fold_v4/B_set"

#추가로 불러올 폴더 이름
#NAME_FOLDER_DATASET_SUB = "name_dataset_DLC"
NAME_FOLDER_DATASET_SUB = "CamVid_12_DLC_v1/x4_BILINEAR"

#결과물 저장 폴더 이름
#-9: 노트북 (no GPU)
if RUN_WHERE == -9:
    NAME_FOLDER_PROJECT = "this_is_sample" #RRDBNet (ESRGAN Net stage)
    is_sample = True
    
#-1: colab (vram 12 ~)
elif RUN_WHERE == -1:
    NAME_FOLDER_PROJECT = "name_project" #RRDBNet (ESRGAN Net stage)
    
#0: 새 컴퓨터 (vram 8)
elif RUN_WHERE == 0:
    NAME_FOLDER_PROJECT = "p10_v7_rrdbnet" #RRDBNet (ESRGAN Net stage)
    
#1:낡은 집 컴퓨터 (vram 12)
elif RUN_WHERE == 1:
    NAME_FOLDER_PROJECT = "p10_v7_mprnet" #MPRNet
    
#2~:연구실 컴퓨터 (vram 8)
elif RUN_WHERE == 2:
    NAME_FOLDER_PROJECT = "p10_v7_d3p" #Deeplab v3 Plus


#---


#CamVid 12 label dataset (SFSegNet ver) -> 2 Fold 변환됨 (링크 언제 바뀔지 모름)
PATH_DATASET_GOOGLE_DRIVE = "https://drive.google.com/file/d/1sRP0AsV3sE9MCrAzMSDTKqXcw00rfEP3/view?usp=sharing"


NAME_FOLDER_PROJECT += "_" + NAME_FOLDER_DATASET.split("/")[0] + "_" + NAME_FOLDER_DATASET.split("/")[-1]

if is_sample:
    print("=== === === [Sample Run] === === ===")
    NAME_FOLDER_DATASET = "Sample_set/A_set"
    NAME_FOLDER_DATASET_SUB = "Sample_set_DLC/x4_BILINEAR"
    NAME_FOLDER_PROJECT = "Sample_set_A_set"
    
if RUN_WHERE == (-1):
    print("RUN on Online (colab)")

else:
    print("RUN on Local")
#[수정 불가 변수] ------------------------
#입출력 공통 폴더명 구성
NAME_FOLDER_TRAIN = "train"
NAME_FOLDER_VAL = "val"
NAME_FOLDER_TEST = "test"

NAME_FOLDER_IMAGES = "images"
NAME_FOLDER_LABELS = "labels"

#-9: 노트북 (no GPU)
if RUN_WHERE == -9:
    PATH_BASE = "C:/LAB/"

#-1: colab (vram 12 ~)
elif RUN_WHERE == -1:
    PATH_BASE = "/content/LAB/"
    
#0: 새 컴퓨터 (vram 8)
elif RUN_WHERE == 0:
    PATH_BASE = "D:/LAB/"
    
#1:낡은 집 컴퓨터 (vram 12)
elif RUN_WHERE == 1:
    PATH_BASE = "E:/LAB/"
    
#2~:연구실 컴퓨터 (vram 8)
elif RUN_WHERE == 2:
    PATH_BASE = "D:/LAB/"
    

#RUN_WHERE 값 확인용 -> 현재 사용중인 LAB 폴더 바로 아래에 "_RUN_on_{번호}" 폴더 생성해두기
if not os.path.isdir(PATH_BASE + "_RUN_on_" + str(RUN_WHERE)):
    print("Wrong [RUN_WHERE] input:", RUN_WHERE)
    sys.exit(9)
else:
    print("RUN on", RUN_WHERE, PATH_BASE)

PATH_BASE_IN = PATH_BASE + "datasets/project_use/" + NAME_FOLDER_DATASET + "/"
PATH_BASE_IN_SUB = PATH_BASE + "datasets/project_use/" + NAME_FOLDER_DATASET_SUB + "/"
PATH_BASE_OUT = PATH_BASE + "result_files/"+ NAME_FOLDER_PROJECT + "/"

PATH_MODEL_STATE_DICT = PATH_BASE + "for_tests/model_state_dict/"

#log 저장 폴더 경로
PATH_OUT_LOG = PATH_BASE_OUT + "logs/"
#모델 CP & SD 저장 폴더 경로
PATH_OUT_MODEL = PATH_BASE_OUT + "models/"
#생성된 이미지 저장 폴더 경로
PATH_OUT_IMAGE = PATH_BASE_OUT + "images/"

#[hyper parameters]----------------------------------------

#---(HP 1) Batch 크기 & Gradient Accumulation (Batch Accumulation) 관련
#batch 크기
#Patch를 사용하는 학습의 경우, 모델 1회 입력 묶음에 사용할 Patch 의 개수를 의미한다. 
#한 이미지에서 이 값만큼 Patch 생성 후 batch 단위의 입력으로 모두 사용

HP_BATCH_TRAIN_SS = 2 #CamVid (12, 480x360) 확정값
#ESRGAN(RRDBNet): 4(64x64) = 4200MB -> GAN 형태 학습을 고려하여 VRAM 여유롭게 잡음 -> 앞으로 모든 SR 실험 (Patch = 64x64)은 batch = 4로 확정
HP_BATCH_TRAIN_SR = 4 #CamVid (12, 480x360) 확정값, 실제론 생성 patch 수

HP_BATCH_TRAIN_GAN = 4   # 아직 안돌려봄

HP_BATCH_TRAIN_DSRL = 2  # 아직 안돌려봄

''' #그래디언트 축적-> 사용 안함
#그래디언트 축적 기능 사용여부
is_grad_acc = False #비교실험을 위해 복원모델에 한해서 사용 안하는 방향으로 결정함
#그래디언트 축적(Gradient Accumulation) -> optimizer.step() 의 간격 (아래 개수만큼의 batch마다 step 시행)
#-> 편의상 Patch 사용 모델에선 HP_BATCH 대신에 Dataset 생성 시 1 묶음당 데이터 개수(기존 BATCH 크기 의미)로 활용한다
HP_BATCH_ACCUMULATION = 4 #변경 가능

if is_grad_acc == False:
    HP_BATCH_ACCUMULATION = 1 #고정값 (1)
'''

HP_BATCH_VAL = 1 #고정값 (1)
HP_BATCH_TEST  = 1 #고정값 (1)

#---(HP 2) epoch, dataset 반복횟수, Learning Rate, weight decay

#epoch 값
HP_EPOCH = 502
#1 epoch 당 dataset 반복 횟수 (SS: segm-, SR: super_res-)
#HP_BATCH_TRAIN_SS의 배수로 설정되어야 함
HP_DATASET_LOOP_SS = HP_BATCH_TRAIN_SS * 4
#HP_BATCH_TRAIN_SR을 무시하고 설정 가능
HP_DATASET_LOOP_SR = 4
#HP_BATCH_TRAIN_GAN을 무시하고 설정 가능
HP_DATASET_LOOP_GAN = 4
#HP_BATCH_TRAIN_DSRL의 배수로 설정되어야 함
HP_DATASET_LOOP_DSRL = HP_BATCH_TRAIN_DSRL * 4


if is_sample:
    HP_DATASET_LOOP_SS = 2
    HP_DATASET_LOOP_SR = 2

#Learning Rate & Weight Decay
#-9: notebook (CPU)
if RUN_WHERE == -9:
    #learning rate (SS, SR ,GAN-G, GAN-D, DSRL)
    HP_LR_SS = 1e-4
    HP_LR_SR = 1e-4
    HP_LR_G = 1e-4
    HP_LR_D = 1e-4
    HP_LR_DSRL = 1e-4
    #weight decay 사용여부 (SS & SR & DSRL)
    is_weight_decay = True
    #weight decay 사용여부 (GAN)
    is_weight_decay_g = True
    is_weight_decay_d = True
    #weight decay(SS, SR ,GAN-G, GAN-D, DSRL)
    HP_WD_SS = 1e-9
    HP_WD_SR = 1e-9
    HP_WD_G = 1e-9
    HP_WD_D = 1e-9
    HP_WD_DSRL = 1e-9

#-1: colab (vram 12 ~)
elif RUN_WHERE == -1:
    #learning rate (SS, SR ,GAN-G, GAN-D, DSRL)
    HP_LR_SS = 1e-4
    HP_LR_SR = 1e-4
    HP_LR_G = 1e-4
    HP_LR_D = 1e-4
    HP_LR_DSRL = 1e-4
    #weight decay 사용여부 (SS & SR & DSRL)
    is_weight_decay = True
    #weight decay 사용여부 (GAN)
    is_weight_decay_g = True
    is_weight_decay_d = True
    #weight decay(SS, SR ,GAN-G, GAN-D, DSRL)
    HP_WD_SS = 1e-9
    HP_WD_SR = 1e-9
    HP_WD_G = 1e-9
    HP_WD_D = 1e-9
    HP_WD_DSRL = 1e-9
    
#0: 새 컴퓨터 (vram 8)
elif RUN_WHERE == 0:
    HP_LR_SS = 1e-4
    HP_LR_SR = 1e-4
    HP_LR_G = 1e-4
    HP_LR_D = 1e-4
    HP_LR_DSRL = 1e-4
    is_weight_decay = True
    is_weight_decay_g = True
    is_weight_decay_d = True
    HP_WD_SS = 1e-9
    HP_WD_SR = 1e-9
    HP_WD_G = 1e-9
    HP_WD_D = 1e-9
    HP_WD_DSRL = 1e-9
    
#1: 집 컴퓨터 (vram 12)
elif RUN_WHERE == 1:
    HP_LR_SS = 1e-4
    HP_LR_SR = 1e-4
    HP_LR_G = 1e-4
    HP_LR_D = 1e-4
    HP_LR_DSRL = 1e-4
    is_weight_decay = True
    is_weight_decay_g = True
    is_weight_decay_d = True
    HP_WD_SS = 1e-9
    HP_WD_SR = 1e-9
    HP_WD_G = 1e-9
    HP_WD_D = 1e-9
    HP_WD_DSRL = 1e-9
    
#2~:연구실 컴퓨터 (vram 8)
elif RUN_WHERE == 2:
    HP_LR_SS = 1e-4
    HP_LR_SR = 1e-4
    HP_LR_G = 1e-4
    HP_LR_D = 1e-4
    HP_LR_DSRL = 1e-4
    is_weight_decay = True
    is_weight_decay_g = True
    is_weight_decay_d = True
    HP_WD_SS = 1e-9
    HP_WD_SR = 1e-9
    HP_WD_G = 1e-9
    HP_WD_D = 1e-9
    HP_WD_DSRL = 1e-9

#scheduler
#사용할 스케쥴러 종류 ("CosineAnnealingLR", "CyclicLR") -> 모든 환경에서 고정
HP_SCHEDULER_OPTION_SS    = "CosineAnnealingLR"
HP_SCHEDULER_OPTION_SR    = "CosineAnnealingLR"
HP_SCHEDULER_OPTION_G     = "CosineAnnealingLR"
HP_SCHEDULER_OPTION_D     = "CosineAnnealingLR"
HP_SCHEDULER_OPTION_DSRL  = "CosineAnnealingLR"
#스케줄려 갱신 간격 ("epoch" 또는 "batch") -> 모든 환경에서 고정
HP_SCHEDULER_UPDATE_INTERVAL_SS    = "batch"
HP_SCHEDULER_UPDATE_INTERVAL_SR    = "epoch"
HP_SCHEDULER_UPDATE_INTERVAL_G     = "epoch"
HP_SCHEDULER_UPDATE_INTERVAL_D     = "epoch"
HP_SCHEDULER_UPDATE_INTERVAL_DSRL  = "epoch"



#개별 파라미터 (서로다른 스케쥴러의 파라미터 이름이 곂치지 않도록 주의)
#--9: notebook (CPU)
if RUN_WHERE == -9:
    #for "CosineAnnealingLR" (SS & SR, GAN-G, GAN-D)
    HP_SCHEDULER_T_MAX   = 50
    HP_SCHEDULER_ETA_MIN = 1e-7
    
    HP_SCHEDULER_T_MAX_G   = 50
    HP_SCHEDULER_ETA_MIN_G = 1e-7
    
    HP_SCHEDULER_T_MAX_D   = 50
    HP_SCHEDULER_ETA_MIN_D = 1e-7

#-1: colab (vram 12 ~)
elif RUN_WHERE == -1:
    #for "CosineAnnealingLR" (SS & SR, GAN-G, GAN-D)
    HP_SCHEDULER_T_MAX   = 50
    HP_SCHEDULER_ETA_MIN = 1e-7
    
    HP_SCHEDULER_T_MAX_G   = 50
    HP_SCHEDULER_ETA_MIN_G = 1e-7
    
    HP_SCHEDULER_T_MAX_D   = 50
    HP_SCHEDULER_ETA_MIN_D = 1e-7
    
    
    #for "CyclicLR" (not supported)
    '''
    #최소 Learning Rate (Lower Bound)
    HP_SCHEDULER_BASE_LR        = 1e-7
    #최대 Learning Rate (Upper Bound)
    HP_SCHEDULER_MAX_LR         = 1e-2
    #(base_lr -> max_lr) epoch 수
    HP_SCHEDULER_STEP_SIZE_UP   = 5
    #(max_lr -> base_lr) epoch 수
    HP_SCHEDULER_STEP_SIZE_DOWN = 5
    #(str) 모드: triangular2 = 주기(step_size_up + step_size_down)마다 max_lr이 반감됨
    HP_SCHEDULER_MODE           = 'triangular2'
    '''
#0: 새 컴퓨터 (vram 8)
elif RUN_WHERE == 0:
    #for "CosineAnnealingLR"
    HP_SCHEDULER_T_MAX   = 50
    HP_SCHEDULER_ETA_MIN = 1e-7
    
    HP_SCHEDULER_T_MAX_G   = 50
    HP_SCHEDULER_ETA_MIN_G = 1e-7
    
    HP_SCHEDULER_T_MAX_D   = 50
    HP_SCHEDULER_ETA_MIN_D = 1e-7
    
    
    
#1: 집 컴퓨터 (vram 12)
elif RUN_WHERE == 1:
    HP_SCHEDULER_T_MAX   = 50
    HP_SCHEDULER_ETA_MIN = 1e-7
    
    HP_SCHEDULER_T_MAX_G   = 50
    HP_SCHEDULER_ETA_MIN_G = 1e-7
    
    HP_SCHEDULER_T_MAX_D   = 50
    HP_SCHEDULER_ETA_MIN_D = 1e-7
    
    
#2~:연구실 컴퓨터 (vram 8)
elif RUN_WHERE == 2:
    HP_SCHEDULER_T_MAX   = 50
    HP_SCHEDULER_ETA_MIN = 1e-7
    
    HP_SCHEDULER_T_MAX_G   = 50
    HP_SCHEDULER_ETA_MIN_G = 1e-7
    
    HP_SCHEDULER_T_MAX_D   = 50
    HP_SCHEDULER_ETA_MIN_D = 1e-7
    
    


#---(HP 3) 랜덤 관련: 랜덤 시드값, 정규분포(랜덤) 생성 시 사용되는 시그마 값

#랜덤 시드값 (pytorch, numpy rand)
#PR_SEED -> HP_SEED
HP_SEED = 15

#정규분포 시그마 값
#PR_SIGMA -> HP_SIGMA
#HP_SIGMA = 1

#---(HP 4) 원본 이미지 크기, 모델입력 이미지 크기, 

#데이터셋 이미지 관련

#원본 이미지 크기 (dataset train & val & test)
HP_ORIGIN_IMG_W, HP_ORIGIN_IMG_H = 480, 360
#학습에 사용될 이미지 크기 (model input & output)
#SS 모델 (Semantic Segmentation) 입력 이미지 크기 (HP_MODEL_IMG_W&H ->HP_MODEL_SS_IMG_W&H 로 변경됨)
HP_MODEL_SS_IMG_W, HP_MODEL_SS_IMG_H = 513, 513 #DeepLab v3+
#HP_MODEL_SS_IMG_W, HP_MODEL_SS_IMG_H = HP_ORIGIN_IMG_W, HP_ORIGIN_IMG_H  # DeepLab v3+ (원본크기 그대로 입력)

#SR 모델 (Super Resolution) 입력 이미지 크기 (patch size)
'''
2022y04m24d 기준
해상도 25%에 대해
    (128, 128) patch 학습 완료됨 (stride (32,32)) (mIoU 9% 하락 확인됨)
    (256, 256) patch 학습 완료됨 (stride (32,32)) (mIoU 8% 하락 확인됨) & 학습 더 오래걸리는거같음
    (256, 256) patch 에 대해 stride 32 vs 64 -> 32가 덜 뭉개지는 느낌으로 확인됨
    ->앞으로 학습은 (128, 128) patch에 (16, 16) stride로 시행할 예정

2022y05m23d 기준
Scale Factor x4에 대해
원본 해상도가 480x360 이기에 SR 모델에 대해 128x128 patch 사용이 불가능 -> 64x64로 감소시킴
'''
#HP_MODEL_SR_IMG_W, HP_MODEL_SR_IMG_H = 256, 256  #MPRNet 논문에 소개된 크기 -> 정식 학습시 vram 9GB 할당됨 (batch = 2)
#HP_MODEL_SR_IMG_W, HP_MODEL_SR_IMG_H = 128, 128  #MPRNet -> 정식 학습시 vram 3GB, 5GB, 8GB 할당됨 (batch = 2, 4, 8)

#CamVid 12 480x360 에 대해 확정됨
HP_MODEL_SR_IMG_W, HP_MODEL_SR_IMG_H = 64, 64     #ESRGAN(RRDBNet) -> vram 4GB 할당됨 (batch = 4)
#-> 원본 이미지 크기 (480x360 으로 인해 SF x4 에 LR 128x128 patch는 사용 부적함함에 따라 축소)
#LR patch 크기를 의미 -> HR patch 크기는 여기에 ScaleFactor 곱하면 됨

#GAN - G 입력크기
HP_MODEL_G_IMG_W, HP_MODEL_G_IMG_H = HP_MODEL_SR_IMG_W, HP_MODEL_SR_IMG_H #(patch) 64, 64
#GAN - D 입력크기
HP_MODEL_D_IMG_W, HP_MODEL_D_IMG_H = 128, 128 #ESRGAN의 D 입력크기

#DSRL 입력 크기
HP_MODEL_DSRL_IMG_W, HP_MODEL_DSRL_IMG_H = HP_ORIGIN_IMG_W // 4, HP_ORIGIN_IMG_H // 4 #Scale Factor 적용됨 (4배율)

#---(HP 5) Semantic Segmentation 라벨 정보 (CamVid 12)

#라벨 수
#PR_LABEL -> HP_LABEL_TOTAL
HP_LABEL_TOTAL = 12
#void 라벨값
#PR_VOID -> HP_VOID_LABEL
HP_LABEL_VOID = 11

#이미지 별 채널 수
HP_CHANNEL_RGB = 3                   #RGB 이미지 (입력 이미지)
HP_CHANNEL_GRAY = 1                  #GRAY 이미지 (라벨 이미지)
HP_CHANNEL_HYPO = HP_LABEL_TOTAL - 1 #모델 출력 이미지 (void 라벨 제외)

#라벨 당 컬러 지정 (CamVid 12)
#label_color_map -> HP_COLOR_MAP
HP_COLOR_MAP = {0:  [128, 128, 128]  # 00 Sky
               ,1:  [128,   0,   0]  # 01 Building
               ,2:  [192, 192, 128]  # 02 Column_pole
               ,3:  [128,  64, 128]  # 03 Road
               ,4:  [  0,   0, 192]  # 04 Sidewalk
               ,5:  [128, 128,   0]  # 05 Tree
               ,6:  [192, 128, 128]  # 06 SignSymbol
               ,7:  [ 64,  64, 128]  # 07 Fence
               ,8:  [ 64,   0, 128]  # 08 Car
               ,9:  [ 64,  64,   0]  # 09 Pedestrian
               ,10: [  0, 128, 192]  # 10 Bicyclist
               ,11: [  0,   0,   0]  # 11 Void
               }

#---(HP 6) optimizer, scheduler, amp_scaler 관련

#스케쥴러 cosLR 파라미터 -> 편의상 workspace로 이동됨
#HP_SCHEDULER_T_MAX = 50
#HP_SCHEDULER_ETA_MIN = 1e-7

#---(HP 7) Data Augm- & ColorJitter 관련
#각 축의 crop 시작좌표 범위 (min, max)
HP_AUGM_RANGE_CROP_INIT = (4, 10)
#회전각도 최대값
HP_AUGM_ROTATION_MAX = 5
#flip 확률
HP_AUGM_PROB_FLIP = 50
#crop 확률
HP_AUGM_PROB_CROP = 70
#rotation 확률
HP_AUGM_PROB_ROTATE = 20



#transforms.Normalize 옵션 (HP_TS_NORM_MEAN & HP_TS_NORM_STD 을 SS / SR / GAN-G / GAN-D 분리함)
#mean
HP_TS_NORM_MEAN_SS = [0.485, 0.456, 0.406]
#std
HP_TS_NORM_STD_SS =  [0.229, 0.224, 0.225]

#mean
HP_TS_NORM_MEAN_SR = [0.485, 0.456, 0.406]
#std
HP_TS_NORM_STD_SR =  [0.229, 0.224, 0.225]

#mean
HP_TS_NORM_MEAN_G = [0.485, 0.456, 0.406]
#std
HP_TS_NORM_STD_G =  [0.229, 0.224, 0.225]

#mean
HP_TS_NORM_MEAN_D = [0.485, 0.456, 0.406]
#std
HP_TS_NORM_STD_D =  [0.229, 0.224, 0.225]

#mean
HP_TS_NORM_MEAN_DSRL = [0.485, 0.456, 0.406]
#std
HP_TS_NORM_STD_DSRL =  [0.229, 0.224, 0.225]



#torchvision transform ColorJitter 옵션
#HP_xxxxx -> HP_CJ_xxxxx 변경됨
HP_CJ_BRIGHTNESS = (0.6, 1.4)
HP_CJ_CONTRAST   = (0.7, 1.2)
HP_CJ_SATURATION = (0.9, 1.3)
HP_CJ_HUE        = (-0.05, 0.05)

#---(HP 8) Loss 관련

#가중치 사용 여부
is_loss_weight = False
#CrossEntropyLoss npArray형 가중치 (label: 0 ~ 10 (void 11번 제외))
HP_LOSS_WEIGHT = np.array([0.12, 0.17, 3.5, 0.12, 0.17, 0.23, 1.32, 1.11, 0.25, 1.28, 5])

#---(HP 9) Super Resolution 관련

#원본 이미지 patch 크기 (SR 모델 입력 크기와 동일하게 설정) -> 변수 사용 안함
#HP_SR_PATCH_IMG_W, HP_SR_PATCH_IMG_H = 256, 256
#HP_SR_PATCH_IMG_W, HP_SR_PATCH_IMG_H = HP_MODEL_SR_IMG_W, HP_MODEL_SR_IMG_H
#(tuple) 원본 이미지 patch 생성 stride 값 (width, height)
HP_SR_STRIDES = (8, 8) #for patch 64x64
HP_GAN_STRIDES = (8, 8) #for patch 64x64

#crop 시작좌표 범위 (tuple) 
HP_SR_RANGE_CROP_INIT_COOR = (0, 16)
HP_GAN_RANGE_CROP_INIT_COOR = (0, 16)

#---(HP 10) Degradation 관련
#Degradation 고정값 (val & test) csv 파일 이름 & 경로 (dataset의 A_set, B_set 폴더에 모두 넣으면 됨)
HP_DG_CSV_NAME = "degradation_2.csv" #확장자 .csv 까지 작성할것
HP_DG_CSV_PATH = PATH_BASE_IN_SUB + HP_DG_CSV_NAME #고정값


#DG 가변값
#SS 학습 시 DG 시행여부 (True의 경우, DG된 영상으로 train & val & test 시행함, val & test에선 csv 파일 옵션 가져다 씀)
#is_ss_degraded = True
#is_ss_degrad = False
#-> 편의상 workspace에서 작성

#해상도 변화(배율값의 역수배로 감소)
#tuple -> 범위 내 값에서 균등추출
#HP_DG_RANGE_SCALE_FACTOR = (14,20) #-> 사용 안함


#Scale Factor (배율값, 이 값으로 이미지 길이를 나눠서 Down Sampling 시행) -> x4 배율로 고정됨
HP_DG_SCALE_FACTOR = 4

#resize 방식 ("NEAREST", "BILINEAR", "BICUBIC", "LANCZOS" 중 하나 선택)
HP_DG_RESIZE_OPTION = "BILINEAR"
#추후에 list 형으로 입력시, 랜덤하게 선택하는 기능을 추가할지 고민중

#Gaussian 노이즈 시그마 범위
HP_DG_RANGE_NOISE_SIGMA = (1, 30)


#노이즈 종류 (Gray(V) or Color(H or S) 중 Gray 노이즈 확률
HP_DG_NOISE_GRAY_PROB = 40

#---(HP )

#---(HP )

#---(HP )

#---(HP )





print("inputs...")
print("dataset (PATH_BASE_IN):", PATH_BASE_IN)
print("degradation_2 (HP_DG_CSV_PATH): ", HP_DG_CSV_PATH)

print("outputs...")
print("logs (PATH_OUT_LOG):", PATH_OUT_LOG)
print("models (PATH_OUT_MODEL):", PATH_OUT_MODEL)
print("images (PATH_OUT_IMAGE):", PATH_OUT_IMAGE)


print("EoF hyper_para.py")
