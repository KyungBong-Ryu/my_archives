#workspace_rrdbnet.py
#for ESRGAN -> Net stage train

from trainers import *
from hyper_para import *
from model_esrgan import Generator as RRDBNet

#[init]----------------------------
#Prevent overwriting results
if os.path.isdir(PATH_BASE_OUT):
    print("실험결과 덮어쓰기 방지기능 작동됨 (Prevent overwriting results function activated)")
    sys.exit("Prevent overwriting results function activated")


#log dicts reset
dict_log_init = {}
# set computation device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


update_dict_v2("", "---< init >---"
              ,"", "실험 날짜: " + HP_INIT_DATE_TIME
              ,"", "--- Dataset Parameter info ---"
              ,"", "Dataset from... " + PATH_BASE_IN
              ,"", ""
              ,"", "--- Hyper Parameter info ---"
              ,"", "Device:" + str(device)
              ,in_dict = dict_log_init
              ,in_print_head = "dict_log_init"
              )


#[model_sr]------------------------

#모델 입력을 위한 텐서로의 변환 시 정규화 시행여부
#(ESRGAN: False -> 좀 더 확인 필요하나, 학습은 잘 되는거같음)
#-> SR & 복원계열 모델은 모델 특성상 SS 모델과는 달리, 정규화를 시행하지 않는게 default로 추측됨
is_norm_in_transform_to_tensor = False

model_sr_name = "RRDBNet" #ESRGAN (Net stage)
model_sr = RRDBNet()
model_sr.to(device)
update_dict_v2("", ""
              ,"", "모델 정보: " + model_sr_name
              ,"", "(github) RRDBNet (Net stage)"
              ,"", "pretrained = False"
              ,in_dict = dict_log_init
              ,in_print_head = "dict_log_init"
              )

#[optimizer]------------------------
#Adam: torch.optim.Adam(params, lr=0.001, betas=(0.9, 0.999), eps=1e-08, weight_decay=0, amsgrad=False, *, maximize=False)
#https://arxiv.org/abs/1412.6980
#https://pytorch.org/docs/stable/generated/torch.optim.Adam.html#torch.optim.Adam

if is_weight_decay: #weight decay를 사용한 경우
    
    optimizer = torch.optim.Adam(model_sr.parameters()
                                ,lr=HP_LR_SR
                                ,weight_decay = HP_WD_SR
                                )
    update_dict_v2("", ""
                  ,"", "옵티마이저 정보"
                  ,"", "optimizer: " + "torch.optim.Adam"
                  ,"", "learning_rate: " + str(HP_LR_SR)
                  ,"", "weight decay 적용됨: " + str(HP_WD_SR)
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
else: #weight decay를 사용하지 않는 경우
    optimizer = torch.optim.Adam(model_sr.parameters()
                                ,lr=HP_LR_SR
                                )
    update_dict_v2("", ""
                  ,"", "옵티마이저 정보"
                  ,"", "optimizer: " + "torch.optim.Adam"
                  ,"", "learning_rate: " + str(HP_LR_SR)
                  ,"", "weight decay 적용 안됨"
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )

#[scheduler]----------------------------------------------
#https://gaussian37.github.io/dl-pytorch-lr_scheduler/

if HP_SCHEDULER_OPTION_SR == "CosineAnnealingLR":
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer
                                                    ,T_max = HP_SCHEDULER_T_MAX
                                                    ,eta_min = HP_SCHEDULER_ETA_MIN
                                                    )

    update_dict_v2("", ""
                  ,"", "스케쥴러 정보"
                  ,"", "업데이트 간격: " + HP_SCHEDULER_UPDATE_INTERVAL_SR
                  ,"", "scheduler: " + "optim.lr_scheduler.CosineAnnealingLR"
                  ,"", "LR 최대값 도달 epoch 수 (lr 반복주기의 절반)"
                  ,"", "T_max: " + str(HP_SCHEDULER_T_MAX)
                  ,"", "lr 최소값 (default = 0)"
                  ,"", "eta_min: " + str(HP_SCHEDULER_ETA_MIN)
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    
elif HP_SCHEDULER_OPTION_SR == "CyclicLR":
    #torch.optim.Adam does not support "CyclicLR" (for cycle_momentum=True)
    #Cyclical Learning Rates for Training Neural Networks (https://arxiv.org/abs/1506.01186)
    #https://pytorch.org/docs/stable/generated/torch.optim.lr_scheduler.CyclicLR.html#torch.optim.lr_scheduler.CyclicLR
    
    scheduler = optim.lr_scheduler.CyclicLR(optimizer
                                           ,base_lr = HP_SCHEDULER_BASE_LR
                                           ,max_lr = HP_SCHEDULER_MAX_LR
                                           ,step_size_up = HP_SCHEDULER_STEP_SIZE_UP
                                           ,step_size_down = HP_SCHEDULER_STEP_SIZE_DOWN
                                           ,mode = HP_SCHEDULER_MODE
                                           )
    
    update_dict_v2("", ""
                  ,"", "스케쥴러 정보"
                  ,"", "업데이트 간격: " + HP_SCHEDULER_UPDATE_INTERVAL_SR
                  ,"", "scheduler: " + "optim.lr_scheduler.CyclicLR"
                  ,"", "최소 Learning Rate (Lower Bound)"
                  ,"", "HP_SCHEDULER_BASE_LR: " + str(HP_SCHEDULER_BASE_LR)
                  ,"", "최대 Learning Rate (Upper Bound)"
                  ,"", "HP_SCHEDULER_MAX_LR: " + str(HP_SCHEDULER_MAX_LR)
                  ,"", "(base_lr -> max_lr) epoch 수"
                  ,"", "HP_SCHEDULER_STEP_SIZE_UP" + str(HP_SCHEDULER_STEP_SIZE_UP)
                  ,"", "(max_lr -> base_lr) epoch 수"
                  ,"", "HP_SCHEDULER_STEP_SIZE_DOWN" + str(HP_SCHEDULER_STEP_SIZE_DOWN)
                  ,"", "(str) 모드: triangular2 = 주기(step_size_up + step_size_down)마다 max_lr이 반감됨"
                  ,"", "HP_SCHEDULER_MODE" + HP_SCHEDULER_MODE
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )


#[loss]--------------------------------------------------
criterion_sr = torch.nn.L1Loss()
update_dict_v2("", "loss 정보"
              ,"", "loss: L1Loss (torch.nn.L1Loss)"
              ,"", "사용 예시"
              ,"", "loss = criterion_sr(predicted and input_data)"
              ,in_dict = dict_log_init
              ,in_print_head = "dict_log_init"
              )



#=========================================================================================

trainer_sr(#<patch를 통해 학습 & RGB 이미지를 생성하는 모델>#
          #init 기록 dict 이어받기
          dict_log_init = dict_log_init
          #랜덤 시드 고정
          ,HP_SEED = HP_SEED
          
          #학습 관련 기본 정보(epoch 수, batch 크기, 생성할 patch 수, 학습 시 dataset 루프 횟수)
          ,HP_EPOCH = HP_EPOCH
          ,HP_BATCH_TRAIN_SR = HP_BATCH_TRAIN_SR
          ,HP_DATASET_LOOP_SR = HP_DATASET_LOOP_SR
          ,HP_BATCH_VAL = HP_BATCH_VAL
          ,HP_BATCH_TEST = HP_BATCH_TEST
          
          #데이터 입출력 경로, 폴더명
          ,PATH_BASE_IN = PATH_BASE_IN
          ,NAME_FOLDER_TRAIN = NAME_FOLDER_TRAIN
          ,NAME_FOLDER_VAL = NAME_FOLDER_VAL
          ,NAME_FOLDER_TEST = NAME_FOLDER_TEST
          ,NAME_FOLDER_IMAGES = NAME_FOLDER_IMAGES
          ,NAME_FOLDER_LABELS = NAME_FOLDER_LABELS
          ,PATH_OUT_IMAGE = PATH_OUT_IMAGE
          ,PATH_OUT_MODEL = PATH_OUT_MODEL
          ,PATH_OUT_LOG = PATH_OUT_LOG
          
          #데이터(이미지) 입출력 크기 (원본 이미지, patch 이미지), 이미지 채널 수
          ,HP_ORIGIN_IMG_W = HP_ORIGIN_IMG_W
          ,HP_ORIGIN_IMG_H = HP_ORIGIN_IMG_H
          ,HP_MODEL_SR_IMG_W = HP_MODEL_SR_IMG_W
          ,HP_MODEL_SR_IMG_H = HP_MODEL_SR_IMG_H
          ,HP_CHANNEL_RGB = HP_CHANNEL_RGB
          
          #모델 이름 -> 모델에 따라 예측결과 형태가 다르기에 모델입출력물을 조정하는 역할
          ,model_sr_name = model_sr_name
          
          #model, optimizer, scheduler, loss
          ,model_sr = model_sr
          ,optimizer = optimizer
          ,scheduler = scheduler
          ,criterion_sr = criterion_sr
          #스케쥴러 업데이트 간격("epoch" 또는 "batch")
          ,HP_SCHEDULER_UPDATE_INTERVAL_SR = HP_SCHEDULER_UPDATE_INTERVAL_SR
          
          #DataAugm- 관련 (colorJitter 포함)
          ,HP_AUGM_RANGE_CROP_INIT = HP_AUGM_RANGE_CROP_INIT
          ,HP_AUGM_ROTATION_MAX = HP_AUGM_ROTATION_MAX
          ,HP_AUGM_PROB_FLIP = HP_AUGM_PROB_FLIP
          ,HP_AUGM_PROB_CROP = HP_AUGM_PROB_CROP
          ,HP_AUGM_PROB_ROTATE = HP_AUGM_PROB_ROTATE
          ,HP_CJ_BRIGHTNESS = HP_CJ_BRIGHTNESS
          ,HP_CJ_CONTRAST = HP_CJ_CONTRAST
          ,HP_CJ_SATURATION = HP_CJ_SATURATION
          ,HP_CJ_HUE = HP_CJ_HUE
          
          #이미지 -> 텐서 시 norm 관련 (정규화 시행 여부, 평균, 표준편차)
          #(MPRNet: False)
          ,is_norm_in_transform_to_tensor = is_norm_in_transform_to_tensor
          ,HP_TS_NORM_MEAN = HP_TS_NORM_MEAN_SR
          ,HP_TS_NORM_STD = HP_TS_NORM_STD_SR
          
          #Degradation 관련
          ,HP_DG_CSV_PATH = HP_DG_CSV_PATH
          ,HP_DG_SCALE_FACTOR = HP_DG_SCALE_FACTOR
          ,HP_DG_RESIZE_OPTION = HP_DG_RESIZE_OPTION
          ,HP_DG_RANGE_NOISE_SIGMA = HP_DG_RANGE_NOISE_SIGMA
          ,HP_DG_NOISE_GRAY_PROB = HP_DG_NOISE_GRAY_PROB
          
          #patch 생성관련
          ,HP_SR_RANGE_CROP_INIT_COOR = HP_SR_RANGE_CROP_INIT_COOR
          ,HP_SR_STRIDES = HP_SR_STRIDES
          )


print("End of workspace_rrdbnet.py")
