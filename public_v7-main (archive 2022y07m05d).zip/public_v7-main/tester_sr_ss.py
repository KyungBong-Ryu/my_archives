#tester_sr_ss.py
#2 Fold 데이터 분할 (Train 45% Val 5% Test 50%): CamVid_12_2Fold_v4

#[기본 라이브러리]----------------------
import os
import numpy as np
import random
import sys

import torch
import torch.nn.functional as F
import torch.optim as optim

import torchvision
import torchvision.transforms as transforms
from torchvision.transforms.functional import to_pil_image

import argparse
import matplotlib.pyplot as plt
from PIL import Image
import cv2

import time

#[py 파일]--------------------------
from data_load_n_save import *
from data_tool import *
from calc_func import *

#https://github.com/KyungBong-Ryu/Codes_implementation/blob/main/BasicSR_NIQE.py
from BasicSR_NIQE import calc_niqe_with_pil


#@@@ 작성중
def tester_sr_ss(**kargs):
    '''#========================================#
    tester_sr_ss(#<patch를 통해 학습 & RGB 이미지를 생성하는 모델>#
                
                #model.to(device) 포함됨 -> workspace에서 시행 안해도 됨
                
                #초기화 기록 dict 이어받기
                dict_log_init = 
                #랜덤 시드 고정
                ,HP_SEED = HP_SEED
                
                
                #데이터 입출력 경로, 폴더명
                ,PATH_BASE_IN = PATH_BASE_IN
                ,NAME_FOLDER_TEST = NAME_FOLDER_TEST
                ,NAME_FOLDER_IMAGES = NAME_FOLDER_IMAGES
                ,NAME_FOLDER_LABELS = NAME_FOLDER_LABELS
                
                 #(선택) degraded image 불러올 경로
                ,PATH_BASE_IN_SUB = PATH_BASE_IN_SUB
                
                ,PATH_OUT_IMAGE = PATH_OUT_IMAGE
                ,PATH_OUT_LOG = PATH_OUT_LOG
                
                
                #데이터(이미지) 입출력 크기 (원본 이미지, 모델 입력 이미지), 이미지 채널 수(이미지, 라벨, 모델출력물)
                ,HP_ORIGIN_IMG_W = 
                ,HP_ORIGIN_IMG_H = 
                ,HP_MODEL_SS_IMG_W = 
                ,HP_MODEL_SS_IMG_H = 
                ,HP_CHANNEL_RGB = HP_CHANNEL_RGB
                ,HP_CHANNEL_GRAY = HP_CHANNEL_GRAY
                ,HP_CHANNEL_HYPO = HP_CHANNEL_HYPO
                
                #라벨 정보(원본 데이터 라벨 수(void 포함), void 라벨 번호, 컬러매핑)
                ,HP_LABEL_TOTAL = HP_LABEL_TOTAL
                ,HP_LABEL_VOID = HP_LABEL_VOID
                ,HP_COLOR_MAP = HP_COLOR_MAP
                
                
                #모델 이름 -> 모델에 따라 예측결과 형태가 다르기에 모델입출력물을 조정하는 역할
                #지원 리스트 SR = "MPRNet", (의미없음) "RRDBNet"
                #지원 리스트 SS = (의미없음) "DeeplabV3Plus"
                ,model_sr_name = 
                ,model_ss_name = 
                
                #model, model_state_dict 경로
                #<모델 SR>
                ,model_sr = 
                ,path_msd_sr = 
                #<모델 SS>
                ,model_ss = 
                ,path_msd_ss = 
                
                
                #이미지 -> 텐서 시 norm 관련 (정규화 시행여부, 평균, 표준편차)
                #<모델 SR>
                ,is_norm_in_transform_to_tensor_sr = 
                ,HP_TS_NORM_MEAN_SR = HP_TS_NORM_MEAN_SR
                ,HP_TS_NORM_STD_SR = HP_TS_NORM_STD_SR
                #<모델 SS>
                ,is_norm_in_transform_to_tensor_ss = 
                ,HP_TS_NORM_MEAN_SS = HP_TS_NORM_MEAN_SS
                ,HP_TS_NORM_STD_SS = HP_TS_NORM_STD_SS
                
                
                #Degradation 기타 설정값
                ,HP_DG_CSV_NAME = HP_DG_CSV_NAME
                ,HP_DG_SCALE_FACTOR = HP_DG_SCALE_FACTOR
                ,HP_DG_RESIZE_OPTION = HP_DG_RESIZE_OPTION
                
                )
    
    '''#========================================#
    
    #[최우선 초기화요소 시행]------------------------
    
    
    # 사용 decive 설정
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    #랜덤 시드(seed) 적용
    HP_SEED = kargs['HP_SEED']
    random.seed(HP_SEED)
    np.random.seed(HP_SEED)
    # pytorch 랜덤시드 고정 (CPU)
    torch.manual_seed(HP_SEED)
    
    
    if device == 'cuda':
        #pytorch 랜덤시드 고정 (GPU & multi-GPU)
        torch.cuda.manual_seed(HP_SEED)
        torch.cuda.manual_seed_all(HP_SEED)
    
    HP_BATCH_TEST = 1
    
    
    #[입출력 Data 관련]-----------------------------
    #경로: 입력
    PATH_BASE_IN = kargs['PATH_BASE_IN']
    NAME_FOLDER_TEST = kargs['NAME_FOLDER_TEST']
    NAME_FOLDER_IMAGES = kargs['NAME_FOLDER_IMAGES']
    NAME_FOLDER_LABELS = kargs['NAME_FOLDER_LABELS']
    
    #경로: 출력
    PATH_OUT_IMAGE = kargs['PATH_OUT_IMAGE']
    PATH_OUT_LOG = kargs['PATH_OUT_LOG']
    
    #원본 이미지 크기
    HP_ORIGIN_IMG_W = kargs['HP_ORIGIN_IMG_W']
    HP_ORIGIN_IMG_H = kargs['HP_ORIGIN_IMG_H']
    #SR 모델은 원본크기 이미지 입력됨
    
    #이미지 SS모델 입력 크기 (train & val & test)
    HP_MODEL_SS_IMG_W = kargs['HP_MODEL_SS_IMG_W']
    HP_MODEL_SS_IMG_H = kargs['HP_MODEL_SS_IMG_H']
    
    #이미지&라벨&모델출력물 채널 수
    HP_CHANNEL_RGB = kargs['HP_CHANNEL_RGB']
    HP_CHANNEL_GRAY = kargs['HP_CHANNEL_GRAY']
    HP_CHANNEL_HYPO = kargs['HP_CHANNEL_HYPO']
    
    #라벨 정보
    HP_LABEL_TOTAL = kargs['HP_LABEL_TOTAL']
    HP_LABEL_VOID = kargs['HP_LABEL_VOID']
    HP_COLOR_MAP = kargs['HP_COLOR_MAP']
    
    
    #[Degradation 관련]-------------------------------
    #고정옵션 dict
    HP_DG_CSV_NAME = kargs['HP_DG_CSV_NAME']
    HP_DG_CSV_PATH = PATH_BASE_IN + HP_DG_CSV_NAME
    dict_dg_csv = csv_2_dict(path_csv = HP_DG_CSV_PATH)
    
    #scale_factor 고정값
    HP_DG_SCALE_FACTOR = kargs['HP_DG_SCALE_FACTOR']
    #resize (downscale) 옵션
    HP_DG_RESIZE_OPTION = kargs['HP_DG_RESIZE_OPTION']
    
    
    
    dataloader_input = custom_dataloader(in_path_dataset = PATH_BASE_IN
                                        ,in_category = NAME_FOLDER_TEST
                                        ,in_name_folder_image = NAME_FOLDER_IMAGES
                                        ,in_name_folder_label = NAME_FOLDER_LABELS
                                        ,batch_size = 1
                                        ,shuffle = False
                                        )
    
    try:
        PATH_BASE_IN_SUB = kargs['PATH_BASE_IN_SUB']
        if not PATH_BASE_IN_SUB[-1] == "/":
            PATH_BASE_IN_SUB += "/"
        
        dict_loaded_pils = load_pils_2_dict(#경로 내 pil 이미지를 전부 불러와서 dict 형으로 묶어버림
                                            #(str) 파일 경로
                                            in_path = PATH_BASE_IN_SUB
                                            #(선택, str) 파일 경로 - 하위폴더명
                                           ,in_path_sub = NAME_FOLDER_IMAGES
                                           )
        print("Pre-Degraded images loaded from:", PATH_BASE_IN_SUB + NAME_FOLDER_IMAGES)
        
        dict_dg_csv = csv_2_dict(path_csv = PATH_BASE_IN_SUB + HP_DG_CSV_NAME)
        print("Pre-Degrade option csv re-loaded from:", PATH_BASE_IN_SUB + HP_DG_CSV_NAME)
        
        flag_pre_degraded_images_loaded = True
    except:
        print("(exc) Pre-Degraded images load FAIL")
        flag_pre_degraded_images_loaded = False
    
    #[model SR]------------------------------------------------------------------------------------------------
    ###################################################
    #<<< 
    #   현재 지원되는 모델 리스트
    #   1. MPRNet  (loss: CharbonnierLoss_custom)
    #   2. RRDBNet (loss: l1 loss in pytorch) -> GAN-G init for ESRGAN & Real-ESRGAN
    #   
    #   
    #>>>
    ###################################################
    
    model_sr_name = kargs['model_sr_name']
    
    model_sr = kargs['model_sr']
    model_sr.to(device)
    
    model_sr.load_state_dict(torch.load(kargs['path_msd_sr']))
    model_sr.eval()
    
    
    #정규화 여부
    is_norm_in_transform_to_tensor_sr = kargs['is_norm_in_transform_to_tensor_sr']
    
    if is_norm_in_transform_to_tensor_sr:
        #평균
        HP_TS_NORM_MEAN = kargs['HP_TS_NORM_MEAN_SR']
        #표준편차
        HP_TS_NORM_STD = kargs['HP_TS_NORM_STD_SR']
        #입력 이미지 텐서 변환 후 정규화 시행
        transform_to_ts_img = transforms.Compose([#PIL 이미지 or npArray -> pytorch 텐서
                                                  transforms.ToTensor()
                                                  #평균, 표준편차를 활용해 정규화
                                                 ,transforms.Normalize(mean = HP_TS_NORM_MEAN, std = HP_TS_NORM_STD),
                                                 ])
        
        # 역정규화 변환
        transform_ts_inv_norm = transforms.Compose([# PIL 이미지 or npArray -> pytorch 텐서
                                                    transforms.ToTensor()
                                                    
                                                   ,transforms.Normalize(mean = [ 0., 0., 0. ]
                                                                        ,std = [ 1/HP_TS_NORM_STD[0], 1/HP_TS_NORM_STD[1], 1/HP_TS_NORM_STD[2] ])
                                                     
                                                   ,transforms.Normalize(mean = [ -HP_TS_NORM_MEAN[0], -HP_TS_NORM_MEAN[1], -HP_TS_NORM_MEAN[2] ]
                                                                        ,std = [ 1., 1., 1. ])
                                                                        
                                                   ,
                                                   ])
        
        
    else:
        #정규화 없이 이미지를 텐서형으로 변환
        transform_to_ts_img = transforms.Compose([#PIL 이미지 or npArray -> pytorch 텐서
                                                  transforms.ToTensor()
                                                 ])
    
    
    
    #SR stage 이후 이미지 묶음 (원본, degraded, 복원됨)
    dict_after_sr_stage = {}
    
    #(flag) niqe error
    flag_niqe_error_raw = 0
    flag_niqe_error_out = 0
    
    count_dataloader = 0
    len_dataloader = len(dataloader_input)
    for path_x, path_y in dataloader_input:
        count_dataloader += 1
        
        #plt_pils_1-1 (원본 이미지)
        in_pil_x_raw = Image.open(path_x[0])
        
        #degradation 관련
        #degrad fix값 불러오기 (val or test에만 사용)
        list_dg_csv = dict_dg_csv[path_x[0].split("/")[-1]]
        
        #<<< degraded 이미지 불러오기 or 생성하기
        
        if flag_pre_degraded_images_loaded == True:
            in_pil_x_deg = dict_loaded_pils[path_x[0].split("/")[-1]]
            
            if PATH_BASE_IN_SUB[-1] == "/":
                tmp_scale_factor = PATH_BASE_IN_SUB.split('/')[-2]
            else:
                tmp_scale_factor = PATH_BASE_IN_SUB.split('/')[-1]
            
            if HP_DG_CSV_NAME == "degradation_2.csv":
                #degradation_2.csv
                option_degrad_1st = "\n(Pre-Degraded) Blur = Gaussian, Downscale(" + tmp_scale_factor
                option_degrad_1st += ") = " + HP_DG_RESIZE_OPTION + ", Noise = (Gaussian, " + list_dg_csv[0]
                option_degrad_1st += ", mu = 0, Sigma = " + list_dg_csv[1] + ")"
            else:
                option_degrad_1st = "\n(Pre-Degraded) check csv option"
            
        else: #미리 degraded 된 이미지를 불러오지 못한 경우
            #1st degrad- (HR(y) -> LR(x))
            in_pil_x_deg, option_degrad_1st = degradation_total_v7(in_pil = in_pil_x_raw
                                                                  ,is_return_options = True
                                                                  #--블러
                                                                  ,in_option_blur = "Gaussian"
                                                                  #--다운 스케일
                                                                  ,in_scale_factor = HP_DG_SCALE_FACTOR
                                                                  ,in_option_resize = HP_DG_RESIZE_OPTION
                                                                  #--노이즈 (Gaussian 고정)
                                                                  ,in_option_noise = "Gaussian"
                                                                  #노이즈 시그마값 범위 (tuple)
                                                                  ,in_range_noise_sigma = (1,30) #사용 안됨
                                                                  #Gray 노이즈 (v 채널 노이즈) 확룔 (int)
                                                                  ,in_percent_gray_noise = 40 #사용 안됨
                                                                  #노이즈 고정값 옵션
                                                                  ,is_fixed_noise = True
                                                                  ,in_fixed_noise_channel = list_dg_csv[0]
                                                                  ,in_fixed_noise_sigma   = list_dg_csv[1]
                                                                  )
        #>>> degraded 이미지 불러오기 or 생성하기
        
        #plt_pils_2-1 (degraded 이미지)
        #<<< 모델 종류에 따라 in_pil_x_input 보정 시행 (HP_DG_RESIZE_OPTION 재활용)
        if model_sr_name == "MPRNet":
            in_pil_x_deg = pil_resize(in_pil = in_pil_x_deg
                                     ,out_w = HP_ORIGIN_IMG_W
                                     ,out_h = HP_ORIGIN_IMG_H
                                     ,option = HP_DG_RESIZE_OPTION
                                     )
        
        elif model_sr_name == "RRDBNet":
            pass
        
        #>>> 모델 종류에 따라 in_pil_x_input 보정 시행 (HP_DG_RESIZE_OPTION 재활용)
        
        tensor_x = transform_to_ts_img(in_pil_x_deg)
        
        with torch.no_grad():
            #tensor_x & tensor_y reshape -> ([b*c, h, w] 형태 텐서를 [b, c, h, w]로 변환)
            tensor_x = tensor_reshape(tensor_x, HP_CHANNEL_RGB)
            #tensor to device
            tensor_x = tensor_x.to(device)
            tensor_sr_hypo = model_sr(tensor_x)
        
        #plt_pils_3-1 (sr 모델로 복원된 이미지)
        #<<< 모델 종류에 따라 예측 결과물 보정작업 시행
        if model_sr_name == "MPRNet":
            out_pil_x = to_pil_image(torch.clamp(tensor_sr_hypo[0][0], min=0, max=1))
        elif model_sr_name == "RRDBNet":
            out_pil_x = to_pil_image(torch.clamp(tensor_sr_hypo[0], min=0, max=1))
        #>>> 모델 종류에 따라 예측 결과물 보정작업 시행
        
        #복원된 이미지 저장
        if not PATH_OUT_IMAGE[-1] == "/":
            tmp_path = PATH_OUT_IMAGE + "/" + model_sr_name + "/"
        else:
            tmp_path = PATH_OUT_IMAGE + model_sr_name + "/"
        save_pil(#경로대로 폴더 생성 후 pil 이미지 저장
                 #(pil) 이미지 
                 pil = out_pil_x
                 #(str) 저장경로: ".asd/fghj"
                ,path = tmp_path
                 #(str) 파일이름 + 확장자: "name.png"
                ,name = path_x[0].split("/")[-1]
                )
        
        
        #psnr & ssim & niqe 연산
        
        hypo_psnr, hypo_ssim = calc_psnr_ssim(pil_original = in_pil_x_raw
                                             ,pil_contrast = out_pil_x
                                             )
        
        
        try:
            hypo_niqe_raw = calc_niqe_with_pil(in_pil_x_raw)
        except:
            hypo_niqe_raw = -404
            flag_niqe_error_raw = 1
        
        try:
            hypo_niqe_out = calc_niqe_with_pil(out_pil_x)
        except:
            hypo_niqe_out = -404
            flag_niqe_error_out = 1
        
        
        dict_after_sr_stage[path_y] = ((in_pil_x_raw, in_pil_x_deg, out_pil_x, option_degrad_1st)
                                      ,(hypo_psnr, hypo_ssim, hypo_niqe_raw, hypo_niqe_out)
                                      )
        
        if count_dataloader % 20 == 0:
            tmp_name_file = path_y[0].split("/")[-1]
            print("\nSR (", count_dataloader, "/", len_dataloader, ")", tmp_name_file)
            print(hypo_psnr, hypo_ssim, hypo_niqe_raw, hypo_niqe_out)
        
    del model_sr
    
    
    
    
    
    
    
    
    
    
    
    
    
    #[model SS]------------------------------------------------------------------------------------------------
    ###################################################
    #    현재 지원되는 모델 리스트 (단일)
    #    1. DeeplabV3Plus (의미없음)
    #       
    #
    model_ss_name = kargs['model_ss_name']
    ###################################################
    
    #정규화 여부
    is_norm_in_transform_to_tensor_ss = kargs['is_norm_in_transform_to_tensor_ss']
    
    if is_norm_in_transform_to_tensor_ss:
        #평균
        HP_TS_NORM_MEAN = kargs['HP_TS_NORM_MEAN_SS']
        #표준편차
        HP_TS_NORM_STD = kargs['HP_TS_NORM_STD_SS']
        #입력 이미지 텐서 변환 후 정규화 시행
        transform_to_ts_img = transforms.Compose([#PIL 이미지 or npArray -> pytorch 텐서
                                                  transforms.ToTensor()
                                                  #평균, 표준편차를 활용해 정규화
                                                 ,transforms.Normalize(mean = HP_TS_NORM_MEAN, std = HP_TS_NORM_STD),
                                                 ])
        
        # 역정규화 변환
        transform_ts_inv_norm = transforms.Compose([# PIL 이미지 or npArray -> pytorch 텐서
                                                    transforms.ToTensor()
                                                    
                                                   ,transforms.Normalize(mean = [ 0., 0., 0. ]
                                                                        ,std = [ 1/HP_TS_NORM_STD[0], 1/HP_TS_NORM_STD[1], 1/HP_TS_NORM_STD[2] ])
                                                     
                                                   ,transforms.Normalize(mean = [ -HP_TS_NORM_MEAN[0], -HP_TS_NORM_MEAN[1], -HP_TS_NORM_MEAN[2] ]
                                                                        ,std = [ 1., 1., 1. ])
                                                                        
                                                   ,
                                                   ])
        
    else:
        #정규화 없이 이미지를 텐서형으로 변환
        transform_to_ts_img = transforms.Compose([#PIL 이미지 or npArray -> pytorch 텐서
                                                  transforms.ToTensor()
                                                 ])
        
    
    model_ss = kargs['model_ss']
    model_ss.to(device)
    
    model_ss.load_state_dict(torch.load(kargs['path_msd_ss']))
    model_ss.eval()
    
    
    #log 기록용 dict 변수 생성
    
    dict_log_total = {}
    #key(1/4)
    tmp_str = "file_name,PSNR,SSIM,NIQE(raw),NIQE(out),mIoU(raw),mIoU(deg),mIoU(out)"
    #key(2/4)
    tmp_str += ",raw_0(Sky),raw_1(Building),raw_2(Column_pole),raw_3(Road),raw_4(Sidewalk),raw_5(Tree)"
    tmp_str += ",raw_6(SignSymbol),raw_7(Fence),raw_8(Car),raw_9(Pedestrian),raw_10(Bicyclist)"
    #key(3/4)
    tmp_str += ",deg_0(Sky),deg_1(Building),deg_2(Column_pole),deg_3(Road),deg_4(Sidewalk),deg_5(Tree)"
    tmp_str += ",deg_6(SignSymbol),deg_7(Fence),deg_8(Car),deg_9(Pedestrian),deg_10(Bicyclist)"
    #key(4/4)
    tmp_str += ",out_0(Sky),out_1(Building),out_2(Column_pole),out_3(Road),out_4(Sidewalk),out_5(Tree)"
    tmp_str += ",out_6(SignSymbol),out_7(Fence),out_8(Car),out_9(Pedestrian),out_10(Bicyclist)"
    
    update_dict_v2("file_num", tmp_str
                  ,in_dict = dict_log_total
                  ,is_print = False
                  )
    
    
    
    #점수 누적용
    epoch_psnr_sum = 0
    epoch_ssim_sum = 0
    epoch_niqe_raw_sum = 0
    epoch_niqe_out_sum = 0
    
    epoch_miou_raw_sum = 0
    epoch_miou_deg_sum = 0
    epoch_miou_out_sum = 0
    
    #라벨별 iou 기록 list [누적값, 유효 데이터 수] 묶음 dict
    epoch_ious_raw_sum = {}
    epoch_ious_deg_sum = {}
    epoch_ious_out_sum = {}
    
    count_dataloader = 0
    len_dataloader = len(dict_after_sr_stage)
    for path_y in dict_after_sr_stage:
        count_dataloader += 1
        dict_key = path_y
        
        in_pil_x_raw = dict_after_sr_stage[dict_key][0][0]
        in_pil_x_deg = dict_after_sr_stage[dict_key][0][1]
        in_pil_x_out = dict_after_sr_stage[dict_key][0][2]
        
        option_degrad_1st = dict_after_sr_stage[dict_key][0][3]
        
        hypo_psnr     = dict_after_sr_stage[dict_key][1][0]
        hypo_ssim     = dict_after_sr_stage[dict_key][1][1]
        hypo_niqe_raw = dict_after_sr_stage[dict_key][1][2]
        hypo_niqe_out = dict_after_sr_stage[dict_key][1][3]
        
        epoch_psnr_sum     += hypo_psnr
        epoch_ssim_sum     += hypo_ssim
        epoch_niqe_raw_sum += hypo_niqe_raw
        epoch_niqe_out_sum += hypo_niqe_out
        
        #[tensor 생성]---
        #.requires_grad_(True) 생략
        #원본 이미지
        tensor_x_raw = tensor_reshape(transform_to_ts_img(pil_resize(in_pil = in_pil_x_raw
                                                                    ,option = "LANCZOS"
                                                                    ,out_w = HP_MODEL_SS_IMG_W
                                                                    ,out_h = HP_MODEL_SS_IMG_H
                                                                    )
                                                         )
                                     ,HP_CHANNEL_RGB
                                     )
        tensor_x_raw = tensor_x_raw.to(device)
        
        #degraded 이미지
        tensor_x_deg = tensor_reshape(transform_to_ts_img(pil_resize(in_pil = in_pil_x_deg
                                                                    ,option = "LANCZOS"
                                                                    ,out_w = HP_MODEL_SS_IMG_W
                                                                    ,out_h = HP_MODEL_SS_IMG_H
                                                                    )
                                                         )
                                     ,HP_CHANNEL_RGB
                                     )
        tensor_x_deg = tensor_x_deg.to(device)
        
        #복원된 이미지
        tensor_x_out = tensor_reshape(transform_to_ts_img(pil_resize(in_pil = in_pil_x_out
                                                                    ,option = "LANCZOS"
                                                                    ,out_w = HP_MODEL_SS_IMG_W
                                                                    ,out_h = HP_MODEL_SS_IMG_H
                                                                    )
                                                         )
                                     ,HP_CHANNEL_RGB
                                     )
        tensor_x_out = tensor_x_out.to(device)
        
        with torch.no_grad():
            tensor_hypo_label_raw = torch.argmax(F.softmax(model_ss(tensor_x_raw)
                                                          ,dim = 1
                                                          )
                                                ,dim = 1
                                                )
            
            tensor_hypo_label_deg = torch.argmax(F.softmax(model_ss(tensor_x_deg)
                                                          ,dim = 1
                                                          )
                                                ,dim = 1
                                                )
            
            tensor_hypo_label_out = torch.argmax(F.softmax(model_ss(tensor_x_out)
                                                          ,dim = 1
                                                          )
                                                ,dim = 1
                                                )
        
        #라벨 이미지(pil)로 변환 (원본 크기)
        
        pil_hypo_resized_raw = pil_resize(in_pil = Image.fromarray(tensor_hypo_label_raw.detach().cpu().numpy()[0].astype('uint8'))
                                         ,option = "NEAREST"
                                         ,out_w = HP_ORIGIN_IMG_W
                                         ,out_h = HP_ORIGIN_IMG_H
                                         )
        
        pil_hypo_resized_deg = pil_resize(in_pil = Image.fromarray(tensor_hypo_label_deg.detach().cpu().numpy()[0].astype('uint8'))
                                         ,option = "NEAREST"
                                         ,out_w = HP_ORIGIN_IMG_W
                                         ,out_h = HP_ORIGIN_IMG_H
                                         )
        
        pil_hypo_resized_out = pil_resize(in_pil = Image.fromarray(tensor_hypo_label_out.detach().cpu().numpy()[0].astype('uint8'))
                                         ,option = "NEAREST"
                                         ,out_w = HP_ORIGIN_IMG_W
                                         ,out_h = HP_ORIGIN_IMG_H
                                         )
        
        #plt_pils_0-2 (원본 라벨)
        in_pil_y_raw = Image.open(path_y[0])
        
        miou_raw, dict_ious_raw = calc_miou_gray(pil_gray_answer  = in_pil_y_raw
                                                ,pil_gray_predict = pil_hypo_resized_raw
                                                ,int_total_labels = HP_LABEL_TOTAL
                                                ,int_void_label   = HP_LABEL_VOID
                                                )
        
        epoch_miou_raw_sum += miou_raw
        str_ious_raw = ""
        for i_key in dict_ious_raw:
            #첫 데이터의 경우
            if count_dataloader == 1:
                #iou 기록 dict 초기화
                epoch_ious_raw_sum[i_key] = [0, 0]
            
            str_ious_raw += "," + dict_ious_raw[i_key]
            #현재 라벨에 대해 유효한 iou 값을 지닌 경우
            if dict_ious_raw[i_key] != "NaN":
                #누적기록 갱신
                prev_iou_sum = epoch_ious_raw_sum[i_key][0]
                prev_iou_count = epoch_ious_raw_sum[i_key][1]
                epoch_ious_raw_sum[i_key] = [prev_iou_sum + float(dict_ious_raw[i_key]), prev_iou_count + 1]
        
        miou_deg, dict_ious_deg = calc_miou_gray(pil_gray_answer  = in_pil_y_raw
                                                ,pil_gray_predict = pil_hypo_resized_deg
                                                ,int_total_labels = HP_LABEL_TOTAL
                                                ,int_void_label   = HP_LABEL_VOID
                                                )
        
        epoch_miou_deg_sum += miou_deg
        str_ious_deg = ""
        for i_key in dict_ious_deg:
            #첫 데이터의 경우
            if count_dataloader == 1:
                #iou 기록 dict 초기화
                epoch_ious_deg_sum[i_key] = [0, 0]
            
            str_ious_deg += "," + dict_ious_deg[i_key]
            #현재 라벨에 대해 유효한 iou 값을 지닌 경우
            if dict_ious_deg[i_key] != "NaN":
                #누적기록 갱신
                prev_iou_sum = epoch_ious_deg_sum[i_key][0]
                prev_iou_count = epoch_ious_deg_sum[i_key][1]
                epoch_ious_deg_sum[i_key] = [prev_iou_sum + float(dict_ious_deg[i_key]), prev_iou_count + 1]
        
        
        miou_out, dict_ious_out = calc_miou_gray(pil_gray_answer  = in_pil_y_raw
                                                ,pil_gray_predict = pil_hypo_resized_out
                                                ,int_total_labels = HP_LABEL_TOTAL
                                                ,int_void_label   = HP_LABEL_VOID
                                                )
        
        epoch_miou_out_sum += miou_out
        str_ious_out = ""
        for i_key in dict_ious_out:
            #첫 데이터의 경우
            if count_dataloader == 1:
                #iou 기록 dict 초기화
                epoch_ious_out_sum[i_key] = [0, 0]
            
            str_ious_out += "," + dict_ious_out[i_key]
            #현재 라벨에 대해 유효한 iou 값을 지닌 경우
            if dict_ious_out[i_key] != "NaN":
                #누적기록 갱신
                prev_iou_sum = epoch_ious_out_sum[i_key][0]
                prev_iou_count = epoch_ious_out_sum[i_key][1]
                epoch_ious_out_sum[i_key] = [prev_iou_sum + float(dict_ious_out[i_key]), prev_iou_count + 1]
        
        
        tmp_name_file = path_y[0].split("/")[-1]
        
        
        #<<< plt 이미지 생성
        #pil 이미지 -> str "(w000,h000)"으로 변환
        def _pil_2_info(in_pil):
            in_w, in_h = in_pil.size
            return " (w" + str(in_w) + ", h" + str(in_h) + ")"
        
        fig = plt.figure(figsize = (27, 14))
        
        plt_raws = 2 #가로 줄 수
        plt_cols = 4 #세로 줄 수
        
        tmp_plt_title = tmp_name_file + option_degrad_1st
        tmp_plt_title += "\nPSNR: " + str(hypo_psnr) + "    SSIM: " + str(hypo_ssim)
        tmp_plt_title += "    NIQE(raw): " + str(hypo_niqe_raw) + "    NIQE(out): " + str(hypo_niqe_out)
        tmp_plt_title += "\nmIoU(raw): " + str(miou_raw) + "    mIoU(deg): " + str(miou_deg) + "    mIoU(out): " + str(miou_out)
        
        fig.suptitle(tmp_plt_title)
        
        #Image(raw) (1/2)
        ax1 = fig.add_subplot(plt_raws, plt_cols, 1)
        ax1.imshow(np.array(in_pil_x_raw))
        ax1.set_title("Answer-Image" + _pil_2_info(in_pil_x_raw))
        #Image(raw) (2/2)
        ax2 = fig.add_subplot(plt_raws, plt_cols, 2)
        ax2.imshow(np.array(in_pil_x_raw))
        ax2.set_title("Original" + _pil_2_info(in_pil_x_raw))
        #Image(deg)
        ax3 = fig.add_subplot(plt_raws, plt_cols, 3)
        ax3.imshow(np.array(in_pil_x_deg))
        ax3.set_title("Degraded" + _pil_2_info(in_pil_x_deg))
        #Image(out)
        ax4 = fig.add_subplot(plt_raws, plt_cols, 4)
        ax4.imshow(np.array(in_pil_x_out))
        ax4.set_title("Restored" + _pil_2_info(in_pil_x_out))
        
        #Label(answer)
        ax5 = fig.add_subplot(plt_raws, plt_cols, 5)
        ax5.imshow(np.array(label_2_RGB(in_pil_y_raw, HP_COLOR_MAP)))
        ax5.set_title("Answer-Label" + _pil_2_info(in_pil_y_raw))
        
        #Label(raw)
        ax6 = fig.add_subplot(plt_raws, plt_cols, 6)
        ax6.imshow(np.array(label_2_RGB(pil_hypo_resized_raw, HP_COLOR_MAP)))
        ax6.set_title("Hypo-Original" + _pil_2_info(pil_hypo_resized_raw))
        #ax6.xlabel("mIoU: " + str(round((miou_raw * 100), 3)) + " %") #-->subplot은 개별 xlabel 사용 어려움
        #Label(deg)
        ax7 = fig.add_subplot(plt_raws, plt_cols, 7)
        ax7.imshow(np.array(label_2_RGB(pil_hypo_resized_deg, HP_COLOR_MAP)))
        ax7.set_title("Hypo-Degraded" + _pil_2_info(pil_hypo_resized_deg))
        #ax7.xlabel("mIoU: " + str(round((miou_deg * 100), 3)) + " %")
        #Label(out)
        ax8 = fig.add_subplot(plt_raws, plt_cols, 8)
        ax8.imshow(np.array(label_2_RGB(pil_hypo_resized_out, HP_COLOR_MAP)))
        ax8.set_title("Hypo-Restored" + _pil_2_info(pil_hypo_resized_out))
        #ax8.xlabel("mIoU: " + str(round((miou_out * 100), 3)) + " %")
        
        
        try:
            if PATH_OUT_IMAGE[-1] != "/":
                tmp_path = PATH_OUT_IMAGE + "/total/"
            else:
                tmp_path = PATH_OUT_IMAGE + "total/"
            
            if not os.path.exists(tmp_path):
                os.makedirs(tmp_path)
            try:
                plt.savefig(tmp_path + tmp_name_file, dpi = 100)
            except:
                print("(exc) plt-total save fail:", tmp_name_file)
        except OSError:
            print("(exc) makedirs", tmp_path)
        
        plt.close(fig)
        #>>> plt 이미지 생성
        
        
        
        #if count_dataloader % 20 == 0:
        if True:
            print("\nSS (", count_dataloader, "/", len_dataloader, ")", tmp_name_file)
            print("PSNR:", hypo_psnr, "SSIM:", hypo_ssim, "NIQE(raw):", hypo_niqe_raw, "NIQE(out):", hypo_niqe_out)
            print("mIoU(raw):", miou_raw, "mIoU(deg):", miou_deg, "mIoU(out):", miou_out)
        
        
        tmp_str = tmp_name_file + "," + str(hypo_psnr) + "," + str(hypo_ssim) + "," + str(hypo_niqe_raw) + "," + str(hypo_niqe_out)
        tmp_str += "," + str(miou_raw) + "," + str(miou_deg) + "," + str(miou_out)
        tmp_str += str_ious_raw + str_ious_deg + str_ious_out 
        
        update_dict_v2("", tmp_str
                      ,in_dict = dict_log_total
                      ,is_print = False
                      )
        
    del model_ss
    
    tmp_count = count_dataloader
    
    #file_name,PSNR,SSIM
    tmp_str = "Mean_Value," + str(epoch_psnr_sum / tmp_count) + "," + str(epoch_ssim_sum / tmp_count)
    
    #,NIQE(raw)
    if flag_niqe_error_raw == 0:
        tmp_str += "," + str(epoch_niqe_raw_sum / tmp_count) 
    else:
        tmp_str += ",-404"
    #,NIQE(out)
    if flag_niqe_error_out == 0:
        tmp_str += "," + str(epoch_niqe_out_sum / tmp_count) 
    else:
        tmp_str += ",-404"
    
    #,mIoU(raw),mIoU(deg),mIoU(out)
    tmp_str += "," + str(epoch_miou_raw_sum / tmp_count) + "," + str(epoch_miou_deg_sum / tmp_count) + "," + str(epoch_miou_out_sum / tmp_count)
    
    #(raw) 라벨별 iou 평균 계산
    for i_key in epoch_ious_raw_sum:
        item_sum = epoch_ious_raw_sum[i_key][0]
        item_count = epoch_ious_raw_sum[i_key][1]
        if item_count != 0:
            tmp_str += "," + str(item_sum / item_count)
        else:
            tmp_str += ",0"
    
    #(deg) 라벨별 iou 평균 계산
    for i_key in epoch_ious_deg_sum:
        item_sum = epoch_ious_deg_sum[i_key][0]
        item_count = epoch_ious_deg_sum[i_key][1]
        if item_count != 0:
            tmp_str += "," + str(item_sum / item_count)
        else:
            tmp_str += ",0"
    
    #(out) 라벨별 iou 평균 계산
    for i_key in epoch_ious_out_sum:
        item_sum = epoch_ious_out_sum[i_key][0]
        item_count = epoch_ious_out_sum[i_key][1]
        if item_count != 0:
            tmp_str += "," + str(item_sum / item_count)
        else:
            tmp_str += ",0"
    
    update_dict_v2("end", tmp_str
                  ,in_dict = dict_log_total
                  ,is_print = True
                  )
    
    #csv 생성
    try:
        #@@@ 현재 저장 안됨 -> 수정필요
        dict_2_txt_v2(in_file_path = PATH_OUT_LOG
                     ,in_file_name = "log_init.csv"
                     ,in_dict = dict_log_init
                     )
    except:
        print("(exc) log_init.csv save FAIL")
        
    dict_2_txt_v2(in_file_path = PATH_OUT_LOG
                 ,in_file_name = "log_total_test.csv"
                 ,in_dict = dict_log_total
                 )
    
    
#=== End of tester_sr_ss

print("End of tester_sr_ss.py")
