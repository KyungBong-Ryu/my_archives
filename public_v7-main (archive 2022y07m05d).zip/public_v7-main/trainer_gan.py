#will be merged with trainers.py
#[memo] --------------
#https://pytorch.org/tutorials/recipes/recipes/amp_recipe.html
#AMP(Automatic Mixed Precision) 사용됨
#2 Fold 데이터 분할 (Train 45% Val 5% Test 50%): CamVid_12_2Fold_v4

#[기본 라이브러리]----------------------
import os
import numpy as np
import random
import sys

import torch
import torch.nn.functional as F
import torch.optim as optim

import torchvision
import torchvision.transforms as transforms
from torchvision.transforms.functional import to_pil_image

import argparse
import matplotlib.pyplot as plt
from PIL import Image
import cv2

import time

#[py 파일]--------------------------
from data_load_n_save import *
from data_tool import *
from calc_func import *

#https://github.com/KyungBong-Ryu/Codes_implementation/blob/main/BasicSR_NIQE.py
from BasicSR_NIQE import calc_niqe_with_pil



#*********************************************************************************************** 여기부터 새로운 내용


def trainer_gan(**kargs):
    '''#========================================#
    trainer_gan(#<patch를 통해 학습 & RGB 이미지를 생성하는 모델>#
                #초기화 기록 dict 이어받기
               dict_log_init = 
                #랜덤 시드 고정
               ,HP_SEED = HP_SEED
              
                #학습 관련 기본 정보(epoch 수, batch 크기(train은 생성할 patch 수), 학습 시 dataset 루프 횟수)
               ,HP_EPOCH = HP_EPOCH
               ,HP_BATCH_TRAIN_GAN = HP_BATCH_TRAIN_GAN
               ,HP_DATASET_LOOP_GAN = HP_DATASET_LOOP_GAN
               ,HP_BATCH_VAL = HP_BATCH_VAL
               ,HP_BATCH_TEST = HP_BATCH_TEST
              
                #데이터 입출력 경로, 폴더명
               ,PATH_BASE_IN = PATH_BASE_IN
               ,NAME_FOLDER_TRAIN = NAME_FOLDER_TRAIN
               ,NAME_FOLDER_VAL = NAME_FOLDER_VAL
               ,NAME_FOLDER_TEST = NAME_FOLDER_TEST
               ,NAME_FOLDER_IMAGES = NAME_FOLDER_IMAGES
               ,NAME_FOLDER_LABELS = NAME_FOLDER_LABELS
               ,PATH_OUT_IMAGE = PATH_OUT_IMAGE
               ,PATH_OUT_MODEL = PATH_OUT_MODEL
               ,PATH_OUT_LOG = PATH_OUT_LOG
              
                #데이터(이미지) 입력 크기 (원본 이미지, patch 이미지, D 입력 이미지), 이미지 채널 수
               ,HP_ORIGIN_IMG_W = HP_ORIGIN_IMG_W
               ,HP_ORIGIN_IMG_H = HP_ORIGIN_IMG_H
               ,HP_MODEL_G_IMG_W = HP_MODEL_G_IMG_W
               ,HP_MODEL_G_IMG_H = HP_MODEL_G_IMG_H
               ,HP_MODEL_D_IMG_W = HP_MODEL_D_IMG_W
               ,HP_MODEL_D_IMG_H = HP_MODEL_D_IMG_H
               
               ,HP_CHANNEL_RGB = HP_CHANNEL_RGB
              
                #[G] model_name, model, optimizer, scheduler, loss (모델의 statedict 불러오기는 workspace 밖에서 시행될 예정)
                #모델 이름 -> 모델에 따라 예측결과 형태가 다르기에 모델입출력물을 조정하는 역할
                #지원 리스트 = ESRGAN (ESRGAN GAN stage, loss: torch.nn.L1Loss(), )
               ,model_g_name = 
               ,model_g = 
               ,optimizer_g = 
               ,scheduler_g = 
                #여러 loss를 사용하는 경우, list 형으로 입력
               ,criterion_g = 
                #(귀속) (list) loss별 가중치
               ,criterion_g_weight = 
                #스케쥴러 업데이트 간격 ("epoch" 또는 "batch")
               ,HP_SCHEDULER_UPDATE_INTERVAL_G = HP_SCHEDULER_UPDATE_INTERVAL_G
               
                #[D] model_name, model, optimizer, scheduler, loss
                #D 유형 (loss 계산과정에 영향을 줌) 
                #("general": Real 혹은 Fake 단일 입력 사용하는 고전방식계열, "relativistic": Real과 Fake를 서로 비교하는 방식계열)
                #지원 리스트: "relativistic"
               ,model_d_name = 
               ,model_d = 
               ,optimizer_d =
               ,scheduler_d = 
               ,criterion_d =
                #스케쥴러 업데이트 간격 ("epoch" 또는 "batch")
               ,HP_SCHEDULER_UPDATE_INTERVAL_D = HP_SCHEDULER_UPDATE_INTERVAL_D
              
                #DataAugm- 관련 (colorJitter 포함)
               ,HP_AUGM_RANGE_CROP_INIT = HP_AUGM_RANGE_CROP_INIT
               ,HP_AUGM_ROTATION_MAX = HP_AUGM_ROTATION_MAX
               ,HP_AUGM_PROB_FLIP = HP_AUGM_PROB_FLIP
               ,HP_AUGM_PROB_CROP = HP_AUGM_PROB_CROP
               ,HP_AUGM_PROB_ROTATE = HP_AUGM_PROB_ROTATE
               ,HP_CJ_BRIGHTNESS = HP_CJ_BRIGHTNESS
               ,HP_CJ_CONTRAST = HP_CJ_CONTRAST
               ,HP_CJ_SATURATION = HP_CJ_SATURATION
               ,HP_CJ_HUE = HP_CJ_HUE
              
                #이미지 -> 텐서 시 norm 관련 (정규화 시행여부, 평균, 표준편차)
               ,is_norm_in_transform_to_tensor = 
               ,HP_TS_NORM_MEAN = HP_TS_NORM_MEAN
               ,HP_TS_NORM_STD = HP_TS_NORM_STD
              
                #Degradation 관련
               ,HP_DG_CSV_PATH = HP_DG_CSV_PATH
               ,HP_DG_SCALE_FACTOR = HP_DG_SCALE_FACTOR
               ,HP_DG_RESIZE_OPTION = HP_DG_RESIZE_OPTION
               ,HP_DG_RANGE_NOISE_SIGMA = HP_DG_RANGE_NOISE_SIGMA
               ,HP_DG_NOISE_GRAY_PROB = HP_DG_NOISE_GRAY_PROB
               
                #patch 생성관련
               ,HP_GAN_RANGE_CROP_INIT_COOR = HP_GAN_RANGE_CROP_INIT_COOR
               ,HP_GAN_STRIDES = HP_GAN_STRIDES
               )
    
    '''#========================================#
    
    #[최우선 초기화요소 시행]------------------------
    #log dict 이어받기
    dict_log_init = kargs['dict_log_init']
    
    # 사용 decive 설정
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    #랜덤 시드(seed) 적용
    HP_SEED = kargs['HP_SEED']
    random.seed(HP_SEED)
    np.random.seed(HP_SEED)
    # pytorch 랜덤시드 고정 (CPU)
    torch.manual_seed(HP_SEED)
    
    update_dict_v2("", ""
                  ,"", "랜덤 시드값 (random numpy pytorch)"
                  ,"", "HP_SEED: " + str(HP_SEED)
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    if device == 'cuda':
        #pytorch 랜덤시드 고정 (GPU & multi-GPU)
        torch.cuda.manual_seed(HP_SEED)
        torch.cuda.manual_seed_all(HP_SEED)
    
    #epoch 수
    HP_EPOCH = kargs['HP_EPOCH']
    #batch 크기 & (train) 데이터셋 루프 횟수
    HP_BATCH_TRAIN_GAN = kargs['HP_BATCH_TRAIN_GAN']
    HP_DATASET_LOOP_GAN = kargs['HP_DATASET_LOOP_GAN']
    HP_BATCH_VAL = kargs['HP_BATCH_VAL']
    HP_BATCH_TEST = kargs['HP_BATCH_TEST']
    
    update_dict_v2("", ""
                  ,"", "최대 epoch 설정: " + str(HP_EPOCH)
                  ,"", "batch 크기"
                  ,"", "HP_BATCH_TRAIN_GAN: " + str(HP_BATCH_TRAIN_GAN)
                  ,"", "학습 시 데이터셋 반복횟수"
                  ,"", "HP_DATASET_LOOP_GAN: " + str(HP_DATASET_LOOP_GAN)
                  ,"", "그래디언트 축적(Gradient Accumulation) 사용 안함"
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    #[입출력 Data 관련]-----------------------------
    #경로: 입력
    PATH_BASE_IN = kargs['PATH_BASE_IN']
    NAME_FOLDER_TRAIN = kargs['NAME_FOLDER_TRAIN']
    NAME_FOLDER_VAL = kargs['NAME_FOLDER_VAL']
    NAME_FOLDER_TEST = kargs['NAME_FOLDER_TEST']
    NAME_FOLDER_IMAGES = kargs['NAME_FOLDER_IMAGES']
    NAME_FOLDER_LABELS = kargs['NAME_FOLDER_LABELS']
    
    #경로: 출력
    PATH_OUT_IMAGE = kargs['PATH_OUT_IMAGE']
    PATH_OUT_MODEL = kargs['PATH_OUT_MODEL']
    PATH_OUT_LOG = kargs['PATH_OUT_LOG']
    
    
    #원본 이미지 크기
    HP_ORIGIN_IMG_W = kargs['HP_ORIGIN_IMG_W']
    HP_ORIGIN_IMG_H = kargs['HP_ORIGIN_IMG_H']
    #모델 입력 크기(이미지 patch 크기) - G & D (train & val)
    HP_MODEL_G_IMG_W = kargs['HP_MODEL_G_IMG_W']
    HP_MODEL_G_IMG_H = kargs['HP_MODEL_G_IMG_H']
    HP_MODEL_D_IMG_W = kargs['HP_MODEL_D_IMG_W']
    HP_MODEL_D_IMG_H = kargs['HP_MODEL_D_IMG_H']
    #이미지 채널 수
    HP_CHANNEL_RGB = kargs['HP_CHANNEL_RGB']
    
    #patch 생성 시 각 축의 시작 좌표 범위
    HP_GAN_RANGE_CROP_INIT_COOR = kargs['HP_GAN_RANGE_CROP_INIT_COOR']
    #patch 생성 시 각 방향 stride 값
    HP_GAN_STRIDES = kargs['HP_GAN_STRIDES']
    
    update_dict_v2("", ""
                  ,"", "원본 Dataset 이미지 크기"
                  ,"", "HP_ORIGIN_IMG_(W H): (" + str(HP_ORIGIN_IMG_W) + " " + str(HP_ORIGIN_IMG_H) + ")"
                  ,"", "모델 입출력 이미지 크기 (patch 크기에 해당)"
                  ,"", "HP_MODEL_G_IMG_(W H): (" + str(HP_MODEL_G_IMG_W) + " " + str(HP_MODEL_G_IMG_H) + ")"
                  ,"", "HP_MODEL_D_IMG_(W H): (" + str(HP_MODEL_D_IMG_W) + " " + str(HP_MODEL_D_IMG_H) + ")"
                  ,"", "Patch crop 시작좌표 범위: ( " + str(HP_GAN_RANGE_CROP_INIT_COOR[0]) + " ~ " + str(HP_GAN_RANGE_CROP_INIT_COOR[-1]) + " )"
                  ,"", "Patch 생성 stride 값 (W H) = ( " + str(HP_GAN_STRIDES[0]) + " " + str(HP_GAN_STRIDES[-1]) + " )"
                  ,"", "이미지 채널 수: " + str(HP_CHANNEL_RGB)
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    
    
    
    #[G] model, 모델 추가정보, optimizer, scheduler, loss--------------------
    #<<< 
    #    현재 지원되는 모델 리스트
    #    1. 
    #       
    #
    model_g_name = kargs['model_g_name']
    
    model_g = kargs['model_g']
    
    #모델 출력 결과가 scale_factor 만큼 커지는가? -> model_g_name으로 대체
    #is_size_recovered_by_model = kargs['is_size_recovered_by_model']
    
    update_dict_v2("", ""
                  ,"", "[G]"
                  ,"", "모델 종류: " + str(model_g_name)
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    optimizer_g = kargs['optimizer_g']
    scheduler_g = kargs['scheduler_g']
    HP_SCHEDULER_UPDATE_INTERVAL_G = kargs['HP_SCHEDULER_UPDATE_INTERVAL_G']
    #loss
    #여러 loss를 사용하는 경우, list 형으로 입력
    criterion_g = kargs['criterion_g']
    #list형 loss 입력시, 각 loss별 가중치 list도 채취
    if type(criterion_g) == type([0,1,2]):
        #가중치가 입력된 경우
        flag_loss_g_list = 1
        print("\nloss for G received in list type\n")
        try:
            criterion_g_weight = kargs['criterion_g_weight']
        except:
            #가중치가 입력되지 않은 경우
            flag_loss_g_list = 0
            print("but no weights for loss_g received")
    #>>>
    
    #[D] model, 모델 추가정보, optimizer, scheduler, loss--------------------
    #<<< 
    #    현재 지원되는 모델 리스트
    #    1. 
    #       
    #
    model_d_name = kargs['model_d_name']
    
    model_d = kargs['model_d']
    
    #모델 출력 결과가 scale_factor 만큼 커지는가? -> model_g_name으로 대체
    #is_size_recovered_by_model = kargs['is_size_recovered_by_model']
    
    update_dict_v2("", ""
                  ,"", "[D]"
                  ,"", "모델 종류: " + str(model_d_name)
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    optimizer_d = kargs['optimizer_d']
    scheduler_d = kargs['scheduler_d']
    HP_SCHEDULER_UPDATE_INTERVAL_D = kargs['HP_SCHEDULER_UPDATE_INTERVAL_D']
    #loss
    criterion_d = kargs['criterion_d']
    #>>>
    
    
    
    #[Automatic Mixed Precision 선언] ---
    amp_scaler = torch.cuda.amp.GradScaler(enabled = True)
    update_dict_v2("", ""
                  ,"", "Automatic Mixed Precision 사용됨"
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    #[data augmentation 관련]--------------------
    
    HP_AUGM_RANGE_CROP_INIT = kargs['HP_AUGM_RANGE_CROP_INIT']
    HP_AUGM_ROTATION_MAX = kargs['HP_AUGM_ROTATION_MAX']
    HP_AUGM_PROB_FLIP = kargs['HP_AUGM_PROB_FLIP']
    HP_AUGM_PROB_CROP = kargs['HP_AUGM_PROB_CROP']
    HP_AUGM_PROB_ROTATE  = kargs['HP_AUGM_PROB_ROTATE']
    #colorJitter 관련
    #https://pytorch.org/vision/master/generated/torchvision.transforms.ColorJitter.html#torchvision.transforms.ColorJitter
    HP_CJ_BRIGHTNESS = kargs['HP_CJ_BRIGHTNESS']
    HP_CJ_CONTRAST   = kargs['HP_CJ_CONTRAST']
    HP_CJ_SATURATION = kargs['HP_CJ_SATURATION']
    HP_CJ_HUE        = kargs['HP_CJ_HUE']
    
    transform_cj = transforms.ColorJitter(brightness = HP_CJ_BRIGHTNESS
                                         ,contrast   = HP_CJ_CONTRAST
                                         ,saturation = HP_CJ_SATURATION
                                         ,hue        = HP_CJ_HUE
                                         )
    
    update_dict_v2("", ""
                  ,"", "ColorJitter 설정"
                  ,"", "brightness: ( " + " ".join([str(t_element) for t_element in HP_CJ_BRIGHTNESS]) +" )"
                  ,"", "contrast:   ( " + " ".join([str(t_element) for t_element in HP_CJ_CONTRAST])   +" )"
                  ,"", "saturation: ( " + " ".join([str(t_element) for t_element in HP_CJ_SATURATION]) +" )"
                  ,"", "hue:        ( " + " ".join([str(t_element) for t_element in HP_CJ_HUE])        +" )"
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    #[이미지 변수 -> 텐서 변수 변환]-------------------
    #정규화 여부
    is_norm_in_transform_to_tensor = kargs['is_norm_in_transform_to_tensor']
    
    if is_norm_in_transform_to_tensor:
        #평균
        HP_TS_NORM_MEAN = kargs['HP_TS_NORM_MEAN']
        #표준편차
        HP_TS_NORM_STD = kargs['HP_TS_NORM_STD']
        #입력 이미지 텐서 변환 후 정규화 시행
        transform_to_ts_img = transforms.Compose([#PIL 이미지 or npArray -> pytorch 텐서
                                                  transforms.ToTensor()
                                                  #평균, 표준편차를 활용해 정규화
                                                 ,transforms.Normalize(mean = HP_TS_NORM_MEAN, std = HP_TS_NORM_STD),
                                                 ])
        
        #역정규화 변환
        transform_ts_inv_norm = transforms.Compose([#PIL 이미지 or npArray -> pytorch 텐서
                                                    transforms.ToTensor()
                                                    
                                                   ,transforms.Normalize(mean = [ 0., 0., 0. ]
                                                                        ,std = [ 1/HP_TS_NORM_STD[0], 1/HP_TS_NORM_STD[1], 1/HP_TS_NORM_STD[2] ])
                                                     
                                                   ,transforms.Normalize(mean = [ -HP_TS_NORM_MEAN[0], -HP_TS_NORM_MEAN[1], -HP_TS_NORM_MEAN[2] ]
                                                                        ,std = [ 1., 1., 1. ])
                                                                        
                                                   ,
                                                   ])
        
        update_dict_v2("", ""
                      ,"", "입력 이미지(in_x) 정규화 시행됨"
                      ,"", "mean=[ " + str(HP_TS_NORM_MEAN[0]) + " " + str(HP_TS_NORM_MEAN[1]) + " "+ str(HP_TS_NORM_MEAN[2]) + " ]"
                      ,"", "std=[ " + str(HP_TS_NORM_STD[0]) + " " + str(HP_TS_NORM_STD[1]) + " "+ str(HP_TS_NORM_STD[2]) + " ]"
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
    else:
        #정규화 없이 이미지를 텐서형으로 변환
        transform_to_ts_img = transforms.Compose([#PIL 이미지 or npArray -> pytorch 텐서
                                                  #https://pytorch.org/vision/stable/generated/torchvision.transforms.ToTensor.html#torchvision.transforms.ToTensor
                                                  #일반적인 경우 (PIL mode: L, LA, P, I, F, RGB, YCbCr, RGBA, CMYK, 1 또는 numpy.ndarray), 
                                                  #(H x W x C) in the range [0, 255] 입력 데이터를
                                                  #(C x H x W) in the range [0.0, 1.0] 출력 데이터로 변환함 (scaled)
                                                  transforms.ToTensor()
                                                 ])
        
        update_dict_v2("", ""
                      ,"", "입력 이미지(in_x) 정규화 시행 안함"
                      ,in_dict = dict_log_init
                      ,in_print_head = "dict_log_init"
                      )
    
    #[Degradation 관련]-------------------------------
    #고정옵션 dict
    HP_DG_CSV_PATH = kargs['HP_DG_CSV_PATH']
    dict_dg_csv = csv_2_dict(path_csv = HP_DG_CSV_PATH)
    
    #scale_factor 고정값
    HP_DG_SCALE_FACTOR = kargs['HP_DG_SCALE_FACTOR']
    #resize (downscale) 옵션
    HP_DG_RESIZE_OPTION = kargs['HP_DG_RESIZE_OPTION']
    
    #Gaussian 노이즈 시그마 범위
    HP_DG_RANGE_NOISE_SIGMA = kargs['HP_DG_RANGE_NOISE_SIGMA']
    #Gray 노이즈 확률 (%)
    HP_DG_NOISE_GRAY_PROB = kargs['HP_DG_NOISE_GRAY_PROB']
    
    update_dict_v2("", ""
                  ,"", "Degradation 관련"
                  ,"", "DG 지정값 파일 경로: " + HP_DG_CSV_PATH
                  ,"", "Scale Factor 고정값 = x" + str(HP_DG_SCALE_FACTOR)
                  ,"", "Resize 옵션 = " + HP_DG_RESIZE_OPTION
                  ,"", "Gaussian 노이즈 시그마 범위 = [ " + str(HP_DG_RANGE_NOISE_SIGMA[0]) + " " + str(HP_DG_RANGE_NOISE_SIGMA[-1]) + " ]"
                  ,"", "노이즈 종류 (Color or Gray 중 Gray 노이즈 확률 = " + str(HP_DG_NOISE_GRAY_PROB)
                  ,in_dict = dict_log_init
                  ,in_print_head = "dict_log_init"
                  )
    
    dict_2_txt_v2(in_file_path = PATH_OUT_LOG
                 ,in_file_name = "log_init.csv"
                 ,in_dict = dict_log_init
                 )
    
    
    #[data & model load]--------------------------
    #data_x : image / data_y = label
    dataloader_train = custom_dataloader(in_path_dataset = PATH_BASE_IN
                                        ,in_category = NAME_FOLDER_TRAIN
                                        ,in_name_folder_image = NAME_FOLDER_IMAGES
                                        ,in_name_folder_label = NAME_FOLDER_LABELS
                                        ,in_dataset_loop = HP_DATASET_LOOP_GAN
                                        #편의상 데이터묶음당 path 개수를 1로 설정
                                        #생성할 patch 수를 batch 크기로 지정
                                        ,batch_size = 1
                                        ,shuffle = True
                                        )

    dataloader_val =   custom_dataloader(in_path_dataset = PATH_BASE_IN
                                        ,in_category = NAME_FOLDER_VAL
                                        ,in_name_folder_image = NAME_FOLDER_IMAGES
                                        ,in_name_folder_label = NAME_FOLDER_LABELS
                                        ,batch_size = HP_BATCH_VAL
                                        ,shuffle = False
                                        )

    dataloader_test =  custom_dataloader(in_path_dataset = PATH_BASE_IN
                                        ,in_category = NAME_FOLDER_TEST
                                        ,in_name_folder_image = NAME_FOLDER_IMAGES
                                        ,in_name_folder_label = NAME_FOLDER_LABELS
                                        ,batch_size = HP_BATCH_TEST
                                        ,shuffle = False
                                        )
    
    
    #[Train & Val & Test]-----------------------------
    print("\nno pause before init trainer_gan\n")
    #time.sleep(10)
    
    #1 epoch 마다 시행할 mode list
    list_mode = ["train", "val", "test"]

    #학습 전체 기록
    dict_log_total_train = {}
    dict_log_total_val = {}
    dict_log_total_test = {}

    #total log dict의 dict
    dict_dict_log_total = {list_mode[0]: dict_log_total_train
                          ,list_mode[1]: dict_log_total_val
                          ,list_mode[2]: dict_log_total_test
                          }

    for i_key in list_mode:
        update_dict_v2("epoch", "loss_(" + i_key + "),psnr_(" + i_key + "),ssim_(" + i_key + "),niqe_(" + i_key + ")"
                      ,in_dict_dict = dict_dict_log_total
                      ,in_dict_key = i_key
                      ,in_print_head = "dict_log_total_" + i_key
                      )

    #data_augm 결과물 저장시 확인용
    dict_augm_check = {}

    #(dict - PIL) 모델에 입력된 이미지 / 라벨 (data_augm 결과물 혹은 원본) 저장용 (input x, input_y)
    dict_pil_x = {}
    dict_pil_y = {}

    for i_epoch in range(HP_EPOCH):
        #train -> val -> test -> train ... 순환
        #epoch 단위 기록
        dict_log_epoch_train = {}
        dict_log_epoch_val = {}
        dict_log_epoch_test = {}
        
        #epoch log dict의 dict
        dict_dict_log_epoch = {list_mode[0]: dict_log_epoch_train
                              ,list_mode[1]: dict_log_epoch_val
                              ,list_mode[2]: dict_log_epoch_test
                              }
        
        
        for i_mode in list_mode:
            print("--- init", i_mode, "---")
            #[공용 변수 초기화] ---
            #오류 기록용 dict
            dict_log_error = {}
            update_dict_v2("", "오류 기록용 dict"
                          ,in_dict = dict_log_error
                          ,in_print_head = "dict_log_error"
                          )
            #오류 발생여부 flag
            flag_error = 0
            
            #<<< #i_mode in list_mode
            #GPU 캐시 메모리 비우기
            torch.cuda.empty_cache()
            
            #이번 epoch 첫 batch 여부 플래그
            flag_init_epoch = 0
            
            #현재 batch 번호 (이미지 묶음 단위)
            i_batch_d = 0
            i_batch_g = 0
            
            #모델 입력 횟수 (patch 묶음 단위)
            #count_model_sr_inputs = 0
            
            #이번 epoch loss 총 합
            #epoch_loss_sum = 0
            #이번 epoch psnr 총 합
            #epoch_psnr_sum = 0
            #이번 epoch psnr 총 합
            #epoch_ssim_sum = 0
            #이번 epoch niqe 총 합
            #epoch_niqe_sum = 0
            
            #epoch 단위 loss, psnr, ssim, niqe
            epoch_loss = score_box("epoch_loss")
            epoch_psnr = score_box("epoch_psnr")
            epoch_ssim = score_box("epoch_ssim")
            epoch_niqe = score_box("epoch_niqe")
            
            #epoch log dict 들의 머리글(표 최상단) 설정
            for i_key in list_mode:
                update_dict_v2(i_key + "_"+ str(i_epoch + 1), "batch_num,loss_batch,psnr_batch,ssim_batch,niqe_batch"
                              ,in_dict_dict = dict_dict_log_epoch
                              ,in_dict_key = i_key
                              ,in_print_head = "dict_log_epoch_" + i_key
                              )
            
            #<<<
            #[모드별 변수 초기화] ---
            if i_mode == "train":
                #현재 모드 batch size 재설정 (생성할 patch 개수를 의미)
                current_batch_size = HP_BATCH_TRAIN_GAN
                #dataloader 설정
                dataloader_input = dataloader_train
                #모델 모드 설정 (train / eval)
            elif i_mode == "val":
                #현재 모드 batch size 재설정 (pil_2_patch_v4의 is_val 옵션 사용 -> 생성할 patch 수와 무관)
                current_batch_size = HP_BATCH_VAL
                dataloader_input = dataloader_val
            elif i_mode == "test":
                #현재 모드 batch size 재설정 (patch 생성 없이 원본 이미지 입력 시행)
                current_batch_size = HP_BATCH_TEST
                dataloader_input = dataloader_test
            #>>>
            
            print("current_batch_size", current_batch_size)
            
            try:
                del dict_pil_x
                del dict_pil_y
            except:
                print("(exc) 일부 변수 삭제에 실패하였습니다: dict_pil_x 또는 dict_pil_y")
            
            #(dict - PIL) 모델에 입력된 이미지 / 라벨 초기화
            dict_pil_x = {}
            dict_pil_y = {}
            
            
            #[train & eval model_d] -----------------------------------------------------------------------------------------------------
            count_dataloader = 0
            model_g.eval()
            if i_mode == "train":
                model_d.train()
            else:
                model_d.eval()
            #x: 입력(LR), y: 정답(HR)
            for path_x, path_y in dataloader_input:
                break#debugging
                count_dataloader += 1
                #이제 콘솔 출력 epoch 값과 실제 epoch 값이 동일함
                print("\nmodel_d in", i_mode, (i_epoch + 1), count_dataloader, "/", len(dataloader_input))
                
                #path_x 길이 = BATCH 누적 개수 or 1 (grad_acc 사용 안하거나 val, test mode인 경우)
                
                #batch에 포함된 이미지들의 patch 묶음 (x = LR, y = HR) (train, val) 또는 그냥 이미지 (test)
                list_patch_pil_x = []
                list_patch_pil_y = []
                
                #degraded 옵션 기록 관련 (초기화)
                option_degrad_total = ""
                list_option_degrad_total = []
                
                #생성된 예측 이미지 저장용 list (초기화) (val, test 용)
                #list_tmp_pil_contrast = [] -> 사용 안함
                
                for i_image in range(len(path_x)):
                #AAA [list_patch_pil_x (LR) & list_patch_pil_y (LR) 생성] -------------------------------
                    #[데이터 불러오기] --------------------------------
                    #i_image = 0 ~ (batch 크기 - 1)
                    in_pil_x_raw = Image.open(path_x[i_image])
                    
                    if i_mode == "train":
                        #Data Augm- 시행 (우선 x & y 동일 이미지 저장 -> 이후에 degrad 시행)
                        in_pil_x_augm, str_used_option = pil_augm_v3(in_pil_x = in_pil_x_raw
                                                                    ,in_option_resize_x = Image.LANCZOS
                                                                    ,in_option_rotate_x = Image.BICUBIC
                                                                    ,in_crop_wh_min = HP_AUGM_RANGE_CROP_INIT[0]
                                                                    ,in_crop_wh_max = HP_AUGM_RANGE_CROP_INIT[-1]
                                                                    ,in_rotate_degree_max = HP_AUGM_ROTATION_MAX
                                                                    ,in_percent_flip = HP_AUGM_PROB_FLIP
                                                                    ,in_percent_crop = HP_AUGM_PROB_CROP
                                                                    ,in_percent_rotate = HP_AUGM_PROB_ROTATE
                                                                    ,is_return_options = True
                                                                    )
                        
                        in_pil_x_input = transform_cj(in_pil_x_augm)
                        in_pil_y_input = in_pil_x_input
                        
                    else: #val , test
                        #Data Augm- 생략 (우선 x & y 동일 이미지 저장 -> 이후에 degrad 시행)
                        in_pil_x_input = in_pil_x_raw
                        in_pil_y_input = in_pil_x_input
                    
                    #Degrad- 시행 (Tr, Val, Ts 공통) (결과물 -> x: LR, y: HR)
                    
                    #degrad fix값 불러오기 (val or test에만 사용)
                    list_dg_csv = dict_dg_csv[path_x[0].split("/")[-1]]
                    
                    if i_mode == "train":
                        is_fixed_noise_mode = False
                    else:
                        is_fixed_noise_mode = True
                    
                    #1st degrad- (HR(y) -> LR(x))
                    in_pil_x_input, option_degrad_1st = degradation_total_v7(in_pil = in_pil_y_input
                                                                            ,is_return_options = True
                                                                            #--블러
                                                                            ,in_option_blur = "Gaussian"
                                                                            #--다운 스케일
                                                                            ,in_scale_factor = HP_DG_SCALE_FACTOR
                                                                            ,in_option_resize = HP_DG_RESIZE_OPTION
                                                                            #--노이즈 (Gaussian 고정)
                                                                            ,in_option_noise = "Gaussian"
                                                                            #노이즈 시그마값 범위 (tuple)
                                                                            ,in_range_noise_sigma = HP_DG_RANGE_NOISE_SIGMA
                                                                            #Gray 노이즈 (v 채널 노이즈) 확룔 (int)
                                                                            ,in_percent_gray_noise = HP_DG_NOISE_GRAY_PROB
                                                                            #노이즈 고정값 옵션
                                                                            ,is_fixed_noise = is_fixed_noise_mode
                                                                            ,in_fixed_noise_channel = list_dg_csv[0]
                                                                            ,in_fixed_noise_sigma   = list_dg_csv[1]
                                                                            )
                    
                    option_degrad_total = "(Degradation) " + option_degrad_1st 
                    #print("option_degrad_total:", option_degrad_total)
                    list_option_degrad_total.append(option_degrad_total)
                    
                    #<<< 모델 종류에 따라 in_pil_x_input 보정 시행 (HP_DG_RESIZE_OPTION 재활용)
                    if model_g_name == "MPRNet":
                        #원본 크기로 upsample
                        in_pil_x_input = pil_resize(in_pil = in_pil_x_input
                                                   ,out_w = HP_ORIGIN_IMG_W
                                                   ,out_h = HP_ORIGIN_IMG_H
                                                   ,option = HP_DG_RESIZE_OPTION
                                                   )
                    elif model_g_name == "RRDBNet":
                        #줄어든 크기 그대로 입력
                        pass
                    
                    #>>> 모델 종류에 따라 in_pil_x_input 보정 시행 (HP_DG_RESIZE_OPTION 재활용)
                    
                    
                    #[이하 (LR)in_pil_x_input & (HR)in_pil_y_input 사용] -----
                    
                    #augm & degrad 결과 저장 (dict <- pil)
                    dict_pil_x[i_image] = in_pil_x_input
                    dict_pil_y[i_image] = in_pil_y_input
                    
                    #[Patch 생성여부에 따라 나뉨]------
                    if i_mode == "test": #patch 생성이 필요 없는 경우 (test)
                        list_patch_pil_x.append(in_pil_x_input)
                        list_patch_pil_y.append(in_pil_y_input)
                    
                    else: #patch 생성이 필요한 경우 (train or val)
                    #<<< Patch 생성 -> list로 병합
                        #   in_pil_x_input(LR) & in_pil_y_input(HR) 로 patch 묶음 dict 생성
                        if i_mode == "train":
                            crop_init_coor_w = random.uniform(HP_GAN_RANGE_CROP_INIT_COOR[0], HP_GAN_RANGE_CROP_INIT_COOR[-1])
                            crop_init_coor_h = random.uniform(HP_GAN_RANGE_CROP_INIT_COOR[0], HP_GAN_RANGE_CROP_INIT_COOR[-1])
                            tmp_is_val = False
                            
                        else: #val
                            crop_init_coor_w = 0
                            crop_init_coor_h = 0
                            tmp_is_val = True
                        
                        #생성할 patch 수 지정 (train)
                        if model_g_name == "MPRNet":
                            #LR patch와 HR patch의 크기가 동일한 경우
                            tmp_scale_factor = 1
                        elif model_g_name == "RRDBNet":
                            #모델로 생성된 이미지가 입력보다 더 커지는 경우
                            tmp_scale_factor = HP_DG_SCALE_FACTOR
                        
                        dict_patch_hr, dict_patch_lr = pil_2_patch_v5(in_pil_hr = in_pil_y_input
                                                                     ,in_pil_lr = in_pil_x_input
                                                                     ,in_scale_factor = tmp_scale_factor
                                                                     #val 모드의 경우, center crop 1장만 생성
                                                                     ,batch_size = current_batch_size
                                                                     ,strides = HP_GAN_STRIDES
                                                                     ,patch_size = (HP_MODEL_G_IMG_W, HP_MODEL_G_IMG_W)
                                                                     ,crop_init_coor = (crop_init_coor_w, crop_init_coor_h)
                                                                     ,is_val = tmp_is_val
                                                                     )
                        
                        #print("이미지당 생성된 patch 수:", len(dict_patch_hr), ",", len(dict_patch_hr))
                        
                        for i_patch in range(len(dict_patch_hr)):
                            #dict 셔플된 그대로 불러오기
                            #for문에서 key값 받아오면 shuffle 의미 없어짐
                            list_patch_pil_x.append(dict_patch_lr[i_patch])
                            list_patch_pil_y.append(dict_patch_hr[i_patch])
                    #>>> Patch 생성 -> list로 병합
                    
                    
                #VVV [list_patch_pil_x (LR) & list_patch_pil_y (HR) 생성] -----------------------
                #>>> for i_image in range(len(path_x)): 끝
                
                if current_batch_size != len(list_patch_pil_x) or current_batch_size != len(list_patch_pil_y):
                    print("최종 생성된 patch 묶음 길이 (LR, HR): (", len(list_patch_pil_x), ",", len(list_patch_pil_y), ")")
                    print("patch 생성 개수가 batch 크기 미만입니다. stride 등의 HyperParameter를 수정하세요")
                    sys.exit(9)
                
                
                #LR이미지 x
                tensor_x = list_pils_2_tensor_v1(#(list - pil) list로 묶인 PIL 이미지 묶음을 pytorch tensor로 변환해줌
                                                 list_pils = list_patch_pil_x
                                                 #(int) pil 이미지 채널 수 (Color = 3, Gray = 1)
                                                ,pil_channels = HP_CHANNEL_RGB
                                                 #(transforms) pil to tensor 함수
                                                ,transforms_to_tensor = transform_to_ts_img
                                                 #(bool) requires grad 여부
                                                ,is_requires_grad = False
                                                )
                tensor_x = tensor_x.to(device)
                
                #HR이미지 y -> 원본 크기
                tensor_y = list_pils_2_tensor_v1(#(list - pil) list로 묶인 PIL 이미지 묶음을 pytorch tensor로 변환해줌
                                                 list_pils = list_patch_pil_y
                                                 #(int) pil 이미지 채널 수 (Color = 3, Gray = 1)
                                                ,pil_channels = HP_CHANNEL_RGB
                                                 #(transforms) pil to tensor 함수
                                                ,transforms_to_tensor = transform_to_ts_img
                                                 #(bool) requires grad 여부
                                                ,is_requires_grad = False
                                                )
                tensor_y = tensor_y.to(device)
                
                #HR이미지 y ->  D 입력크기에 맞게 조정
                tensor_y_resized = list_pils_2_tensor_v1(#(list - pil) list로 묶인 PIL 이미지 묶음을 pytorch tensor로 변환해줌
                                                         list_pils = list_patch_pil_y
                                                         #(int) pil 이미지 채널 수 (Color = 3, Gray = 1)
                                                        ,pil_channels = HP_CHANNEL_RGB
                                                         #(bool) pil 이미지 크기 변환 시행여부
                                                        ,is_resized = True
                                                         #(tuple) pil 변환결과 크기 (w, h)
                                                        ,resized_size = (HP_MODEL_D_IMG_W, HP_MODEL_D_IMG_H)
                                                         #(str) interpolation 방식 ("NEAREST", "BILINEAR", "BICUBIC", "LANCZOS")
                                                        ,resized_method = "LANCZOS"
                                                         #(transforms) pil to tensor 함수
                                                        ,transforms_to_tensor = transform_to_ts_img
                                                         #(bool) requires grad 여부
                                                        ,is_requires_grad = False
                                                        )
                tensor_y_resized = tensor_y_resized.to(device)
                
                #SR 이미지 텐서 생성 -> D 입력크기에 맞게 조정
                with torch.no_grad():
                    tensor_g_hypo = model_g(tensor_x)
                list_pils_g_hypo = tensor_2_list_pils_v1(#텐서 -> pil 이미지 리스트
                                                         #(tensor) 변환할 텐서, 모델에서 다중 결과물이 생성되는 경우, 단일 출력물 묶음만 지정해서 입력 
                                                         #(예: MPRNet -> in_tensor = tensor_sr_hypo[0])
                                                         in_tensor = tensor_g_hypo
                                                        
                                                         #(bool) pil 이미지 크기 변환 시행여부 (default: False)
                                                        ,is_resized = True
                                                         #(귀속) (tuple) pil 변환결과 크기 (w, h)
                                                        ,resized_size = (HP_MODEL_D_IMG_W, HP_MODEL_D_IMG_H)
                                                         #(귀속) (str) interpolation 방식 ("NEAREST", "BILINEAR", "BICUBIC", "LANCZOS")
                                                        ,resized_method = "LANCZOS"
                                                        )
                try:
                    del tensor_g_hypo
                except:
                    print("(exc) del tensor_g_hypo")
                
                tensor_g_hypo_resized =  list_pils_2_tensor_v1(#(list - pil) list로 묶인 PIL 이미지 묶음을 pytorch tensor로 변환해줌
                                                               list_pils = list_pils_g_hypo
                                                               #(int) pil 이미지 채널 수 (Color = 3, Gray = 1)
                                                              ,pil_channels = HP_CHANNEL_RGB
                                                              
                                                               #(bool) pil 이미지 크기 변환 시행여부
                                                              ,is_resized = True
                                                               #(tuple) pil 변환결과 크기 (w, h)
                                                              ,resized_size = (HP_MODEL_D_IMG_W, HP_MODEL_D_IMG_H)
                                                               #(str) interpolation 방식 ("NEAREST", "BILINEAR", "BICUBIC", "LANCZOS")
                                                              ,resized_method = "LANCZOS"
                                                              
                                                               #(transforms) pil to tensor 함수
                                                              ,transforms_to_tensor = transform_to_ts_img
                                                               #(bool) requires grad 여부
                                                              ,is_requires_grad = False
                                                              )
                tensor_g_hypo_resized = tensor_g_hypo_resized.to(device)
                
                #model_d 정답 텐서 (real, fake)
                tensor_d_answer_real = torch.full([current_batch_size, 1], 1.0, dtype=torch.float, device=torch.device(device))
                tensor_d_answer_fake = torch.full([current_batch_size, 1], 0.0, dtype=torch.float, device=torch.device(device))
                
                
                if i_mode == "train":
                    #<<< model_d update
                    #model_d 에측 시행
                    with torch.cuda.amp.autocast(enabled=True):
                        if model_d_name == "relativistic":
                            #model_d(HR)
                            tensor_d_hypo_hr = model_d(tensor_y_resized.requires_grad_(True))
                            #model_d(SR)
                            tensor_d_hypo_sr = model_d(tensor_g_hypo_resized.requires_grad_(True))
                            
                            #loss_d = (loss_d_hr + loss_d_sr ) * 0.5
                            loss_d = (criterion_d(tensor_d_hypo_hr - torch.mean(tensor_d_hypo_sr), tensor_d_answer_real) * 0.5
                                     +criterion_d(tensor_d_hypo_sr - torch.mean(tensor_d_hypo_hr), tensor_d_answer_fake) * 0.5
                                     )
                    
                    try:
                        #loss overflow, underflow 오류 방지
                        amp_scaler.scale(loss_d).backward()
                    except:
                        flag_error = 1
                        update_dict_v2("", "in " + str(i_epoch) + " " + str(i_batch_d)
                                      ,"", "loss_d.backward 실패():" + str(loss_d.item())
                                      ,in_dict = dict_log_error
                                      ,in_print_head = "dict_log_error"
                                      )
                    
                    #가중치 갱신 (batch 마다)
                    amp_scaler.step(optimizer_d)
                    amp_scaler.update()
                    #기울기 초기화
                    optimizer_d.zero_grad()
                    #print("optimizer_d.zero_grad()")
                    if HP_SCHEDULER_UPDATE_INTERVAL_G == "batch":
                        #스케쥴러 갱신
                        scheduler_d.step()
                        print("scheduler_d.step()")
                    
                    #>>> model_d update
                else: #val & test
                    #<<< model_d eval
                    with torch.no_grad():
                        if model_d_name == "relativistic":
                            #model_d(HR)
                            tensor_d_hypo_hr = model_d(tensor_y_resized)
                            #model_d(SR)
                            tensor_d_hypo_sr = model_d(tensor_g_hypo_resized)
                            
                            #loss_d = (loss_d_hr + loss_d_sr ) * 0.5
                            loss_d = (criterion_d(tensor_d_hypo_hr - torch.mean(tensor_d_hypo_sr), tensor_d_answer_real) * 0.5
                                     +criterion_d(tensor_d_hypo_sr - torch.mean(tensor_d_hypo_hr), tensor_d_answer_fake) * 0.5
                                     )
                        
                        
                    #>>> model_d eval
                
                #결과 정리
                if model_d_name == "relativistic":
                    #model_d 학습과정에서 d의 예측값 nparray
                    np_d_hypo_hr = tensor_d_hypo_hr.clone().detach().cpu().numpy()
                    np_d_hypo_sr = tensor_d_hypo_sr.clone().detach().cpu().numpy()
                    print("in model_d train & eval")
                    print("np_d_hypo_hr", np_d_hypo_hr)
                    print("np_d_hypo_sr", np_d_hypo_sr)
                
                
                try:
                    del tensor_x
                    del tensor_y
                    del tensor_y_resized
                    del tensor_g_hypo_resized
                    del loss_d
                    del tensor_d_hypo_hr
                    del tensor_d_hypo_sr
                except:
                    print("(exc) model_d stage tensor del FAIL")
                
                
                if i_mode == "train":
                    print("model_d state dict & check point 저장 - 기능추가필요")
                
                i_batch_d += 1
                #End of for path_x, path_y in dataloader_input:
            
            
            #[train & eval model_g] -----------------------------------------------------------------------------------------------------
            count_dataloader = 0
            model_d.eval()
            if i_mode == "train":
                model_g.train()
            else:
                model_g.eval()
            #x: 입력(LR), y: 정답(HR)
            for path_x, path_y in dataloader_input:
                count_dataloader += 1
                #이제 콘솔 출력 epoch 값과 실제 epoch 값이 동일함
                print("\nmodel_g in", i_mode, (i_epoch + 1), count_dataloader, "/", len(dataloader_input))
                
                #path_x 길이 = BATCH 누적 개수 or 1 (grad_acc 사용 안하거나 val, test mode인 경우)
                
                #batch에 포함된 이미지들의 patch 묶음 (x = LR, y = HR) (train, val) 또는 그냥 이미지 (test)
                list_patch_pil_x = []
                list_patch_pil_y = []
                
                #degraded 옵션 기록 관련 (초기화)
                option_degrad_total = ""
                list_option_degrad_total = []
                
                #생성된 예측 이미지 저장용 list (초기화) (val, test 용)
                #list_tmp_pil_contrast = [] -> 사용 안함
                
                for i_image in range(len(path_x)):
                #AAA [list_patch_pil_x (LR) & list_patch_pil_y (LR) 생성] -------------------------------
                    #[데이터 불러오기] --------------------------------
                    #i_image = 0 ~ (batch 크기 - 1)
                    in_pil_x_raw = Image.open(path_x[i_image])
                    
                    if i_mode == "train":
                        #Data Augm- 시행 (우선 x & y 동일 이미지 저장 -> 이후에 degrad 시행)
                        in_pil_x_augm, str_used_option = pil_augm_v3(in_pil_x = in_pil_x_raw
                                                                    ,in_option_resize_x = Image.LANCZOS
                                                                    ,in_option_rotate_x = Image.BICUBIC
                                                                    ,in_crop_wh_min = HP_AUGM_RANGE_CROP_INIT[0]
                                                                    ,in_crop_wh_max = HP_AUGM_RANGE_CROP_INIT[-1]
                                                                    ,in_rotate_degree_max = HP_AUGM_ROTATION_MAX
                                                                    ,in_percent_flip = HP_AUGM_PROB_FLIP
                                                                    ,in_percent_crop = HP_AUGM_PROB_CROP
                                                                    ,in_percent_rotate = HP_AUGM_PROB_ROTATE
                                                                    ,is_return_options = True
                                                                    )
                        
                        in_pil_x_input = transform_cj(in_pil_x_augm)
                        in_pil_y_input = in_pil_x_input
                        
                    else: #val , test
                        #Data Augm- 생략 (우선 x & y 동일 이미지 저장 -> 이후에 degrad 시행)
                        in_pil_x_input = in_pil_x_raw
                        in_pil_y_input = in_pil_x_input
                    
                    #Degrad- 시행 (Tr, Val, Ts 공통) (결과물 -> x: LR, y: HR)
                    
                    #degrad fix값 불러오기 (val or test에만 사용)
                    list_dg_csv = dict_dg_csv[path_x[0].split("/")[-1]]
                    
                    if i_mode == "train":
                        is_fixed_noise_mode = False
                    else:
                        is_fixed_noise_mode = True
                    
                    #1st degrad- (HR(y) -> LR(x))
                    in_pil_x_input, option_degrad_1st = degradation_total_v7(in_pil = in_pil_y_input
                                                                            ,is_return_options = True
                                                                            #--블러
                                                                            ,in_option_blur = "Gaussian"
                                                                            #--다운 스케일
                                                                            ,in_scale_factor = HP_DG_SCALE_FACTOR
                                                                            ,in_option_resize = HP_DG_RESIZE_OPTION
                                                                            #--노이즈 (Gaussian 고정)
                                                                            ,in_option_noise = "Gaussian"
                                                                            #노이즈 시그마값 범위 (tuple)
                                                                            ,in_range_noise_sigma = HP_DG_RANGE_NOISE_SIGMA
                                                                            #Gray 노이즈 (v 채널 노이즈) 확룔 (int)
                                                                            ,in_percent_gray_noise = HP_DG_NOISE_GRAY_PROB
                                                                            #노이즈 고정값 옵션
                                                                            ,is_fixed_noise = is_fixed_noise_mode
                                                                            ,in_fixed_noise_channel = list_dg_csv[0]
                                                                            ,in_fixed_noise_sigma   = list_dg_csv[1]
                                                                            )
                    
                    option_degrad_total = "(Degradation) " + option_degrad_1st 
                    #print("option_degrad_total:", option_degrad_total)
                    list_option_degrad_total.append(option_degrad_total)
                    
                    #<<< 모델 종류에 따라 in_pil_x_input 보정 시행 (HP_DG_RESIZE_OPTION 재활용)
                    if model_g_name == "MPRNet":
                        #원본 크기로 upsample
                        in_pil_x_input = pil_resize(in_pil = in_pil_x_input
                                                   ,out_w = HP_ORIGIN_IMG_W
                                                   ,out_h = HP_ORIGIN_IMG_H
                                                   ,option = HP_DG_RESIZE_OPTION
                                                   )
                    elif model_g_name == "RRDBNet":
                        #그대로 입력
                        pass
                    
                    #>>> 모델 종류에 따라 in_pil_x_input 보정 시행 (HP_DG_RESIZE_OPTION 재활용)
                    
                    
                    #[이하 (LR)in_pil_x_input & (HR)in_pil_y_input 사용] -----
                    
                    #augm & degrad 결과 저장 (dict <- pil)
                    dict_pil_x[i_image] = in_pil_x_input
                    dict_pil_y[i_image] = in_pil_y_input
                    
                    #[Patch 생성여부에 따라 나뉨]------
                    if i_mode == "test": #patch 생성이 필요 없는 경우 (test)
                        list_patch_pil_x.append(in_pil_x_input)
                        list_patch_pil_y.append(in_pil_y_input)
                    
                    else: #patch 생성이 필요한 경우 (train or val)
                    #<<< Patch 생성 -> list로 병합
                        #   in_pil_x_input(LR) & in_pil_y_input(HR) 로 patch 묶음 dict 생성
                        if i_mode == "train":
                            crop_init_coor_w = random.uniform(HP_GAN_RANGE_CROP_INIT_COOR[0], HP_GAN_RANGE_CROP_INIT_COOR[-1])
                            crop_init_coor_h = random.uniform(HP_GAN_RANGE_CROP_INIT_COOR[0], HP_GAN_RANGE_CROP_INIT_COOR[-1])
                            tmp_is_val = False
                            
                        else: #val
                            crop_init_coor_w = 0
                            crop_init_coor_h = 0
                            tmp_is_val = True
                        
                        #생성할 patch 수 지정 (train)
                        if model_g_name == "MPRNet":
                            #LR patch와 HR patch의 크기가 동일한 경우
                            tmp_scale_factor = 1
                        elif model_g_name == "RRDBNet":
                            #모델로 생성된 이미지가 입력보다 더 커지는 경우
                            tmp_scale_factor = HP_DG_SCALE_FACTOR
                        
                        dict_patch_hr, dict_patch_lr = pil_2_patch_v5(in_pil_hr = in_pil_y_input
                                                                     ,in_pil_lr = in_pil_x_input
                                                                     ,in_scale_factor = tmp_scale_factor
                                                                     #val 모드의 경우, center crop 1장만 생성
                                                                     ,batch_size = current_batch_size
                                                                     ,strides = HP_GAN_STRIDES
                                                                     ,patch_size = (HP_MODEL_G_IMG_W, HP_MODEL_G_IMG_W)
                                                                     ,crop_init_coor = (crop_init_coor_w, crop_init_coor_h)
                                                                     ,is_val = tmp_is_val
                                                                     )
                        
                        #print("이미지당 생성된 patch 수:", len(dict_patch_hr), ",", len(dict_patch_hr))
                        
                        for i_patch in range(len(dict_patch_hr)):
                            #dict 셔플된 그대로 불러오기
                            #for문에서 key값 받아오면 shuffle 의미 없어짐
                            list_patch_pil_x.append(dict_patch_lr[i_patch])
                            list_patch_pil_y.append(dict_patch_hr[i_patch])
                    #>>> Patch 생성 -> list로 병합
                    
                    
                #VVV [list_patch_pil_x (LR) & list_patch_pil_y (HR) 생성] -----------------------
                #>>> for i_image in range(len(path_x)): 끝
                
                if current_batch_size != len(list_patch_pil_x) or current_batch_size != len(list_patch_pil_y):
                    print("최종 생성된 patch 묶음 길이 (LR, HR): (", len(list_patch_pil_x), ",", len(list_patch_pil_y), ")")
                    print("patch 생성 개수가 batch 크기 미만입니다. stride 등의 HyperParameter를 수정하세요")
                    sys.exit(9)
                
                
                #LR이미지 x
                tensor_x = list_pils_2_tensor_v1(#(list - pil) list로 묶인 PIL 이미지 묶음을 pytorch tensor로 변환해줌
                                                list_pils = list_patch_pil_x
                                                 #(int) pil 이미지 채널 수 (Color = 3, Gray = 1)
                                                ,pil_channels = HP_CHANNEL_RGB
                                                 #(transforms) pil to tensor 함수
                                                ,transforms_to_tensor = transform_to_ts_img
                                                 #(bool) requires grad 여부
                                                ,is_requires_grad = False
                                                )
                tensor_x = tensor_x.to(device)
                
                #HR이미지 y -> 원본 & D 입력크기에 맞게 조정
                tensor_y = list_pils_2_tensor_v1(#(list - pil) list로 묶인 PIL 이미지 묶음을 pytorch tensor로 변환해줌
                                                 list_pils = list_patch_pil_y
                                                 #(int) pil 이미지 채널 수 (Color = 3, Gray = 1)
                                                ,pil_channels = HP_CHANNEL_RGB
                                                 #(transforms) pil to tensor 함수
                                                ,transforms_to_tensor = transform_to_ts_img
                                                 #(bool) requires grad 여부
                                                ,is_requires_grad = False
                                                )
                tensor_y = tensor_y.to(device)
                
                tensor_y_resized = list_pils_2_tensor_v1(#(list - pil) list로 묶인 PIL 이미지 묶음을 pytorch tensor로 변환해줌
                                                         list_pils = list_patch_pil_y
                                                         #(int) pil 이미지 채널 수 (Color = 3, Gray = 1)
                                                        ,pil_channels = HP_CHANNEL_RGB
                                                         #(bool) pil 이미지 크기 변환 시행여부
                                                        ,is_resized = True
                                                         #(tuple) pil 변환결과 크기 (w, h)
                                                        ,resized_size = (HP_MODEL_D_IMG_W, HP_MODEL_D_IMG_H)
                                                         #(str) interpolation 방식 ("NEAREST", "BILINEAR", "BICUBIC", "LANCZOS")
                                                        ,resized_method = "LANCZOS"
                                                         #(transforms) pil to tensor 함수
                                                        ,transforms_to_tensor = transform_to_ts_img
                                                         #(bool) requires grad 여부
                                                        ,is_requires_grad = False
                                                        )
                tensor_y_resized = tensor_y_resized.to(device)
                
                if i_mode == "train":
                    #<<< model_g 갱신
                    
                    #SR 이미지 -> D 입력크기에 맞게 조정
                    with torch.cuda.amp.autocast(enabled=True):
                        tensor_g_hypo = model_g(tensor_x.requires_grad_(True))
                    list_pils_g_hypo = tensor_2_list_pils_v1(#텐서 -> pil 이미지 리스트
                                                             #(tensor) 변환할 텐서, 모델에서 다중 결과물이 생성되는 경우, 단일 출력물 묶음만 지정해서 입력 
                                                             #(예: MPRNet -> in_tensor = tensor_sr_hypo[0])
                                                             in_tensor = tensor_g_hypo
                                                            
                                                             #(bool) pil 이미지 크기 변환 시행여부 (default: False)
                                                            ,is_resized = True
                                                             #(귀속) (tuple) pil 변환결과 크기 (w, h)
                                                            ,resized_size = (HP_MODEL_D_IMG_W, HP_MODEL_D_IMG_H)
                                                             #(귀속) (str) interpolation 방식 ("NEAREST", "BILINEAR", "BICUBIC", "LANCZOS")
                                                            ,resized_method = "LANCZOS"
                                                            )
                    
                    tensor_g_hypo_resized =  list_pils_2_tensor_v1(#(list - pil) list로 묶인 PIL 이미지 묶음을 pytorch tensor로 변환해줌
                                                                   list_pils = list_pils_g_hypo
                                                                   #(int) pil 이미지 채널 수 (Color = 3, Gray = 1)
                                                                  ,pil_channels = HP_CHANNEL_RGB
                                                                  
                                                                   #(bool) pil 이미지 크기 변환 시행여부
                                                                  ,is_resized = True
                                                                   #(tuple) pil 변환결과 크기 (w, h)
                                                                  ,resized_size = (HP_MODEL_D_IMG_W, HP_MODEL_D_IMG_H)
                                                                   #(str) interpolation 방식 ("NEAREST", "BILINEAR", "BICUBIC", "LANCZOS")
                                                                  ,resized_method = "LANCZOS"
                                                                  
                                                                   #(transforms) pil to tensor 함수
                                                                  ,transforms_to_tensor = transform_to_ts_img
                                                                   #(bool) requires grad 여부
                                                                  ,is_requires_grad = False
                                                                  )
                    tensor_g_hypo_resized = tensor_g_hypo_resized.to(device)
                    
                    #model_d 에측 시행
                    with torch.no_grad():
                        if model_d_name == "relativistic":
                            #model_d 정답 텐서 (real, fake)
                            tensor_d_answer_real = torch.full([current_batch_size, 1], 1.0, dtype=torch.float, device=torch.device(device))
                            tensor_d_answer_fake = torch.full([current_batch_size, 1], 0.0, dtype=torch.float, device=torch.device(device))
                            #model_d(HR)
                            tensor_d_hypo_hr = model_d(tensor_y_resized.clone().detach())
                            #model_d(SR)
                            tensor_d_hypo_sr = model_d(tensor_g_hypo_resized.clone().detach())
                            
                            #loss_d = (loss_d_hr + loss_d_sr ) * 0.5
                            loss_d = (criterion_d(tensor_d_hypo_hr - torch.mean(tensor_d_hypo_sr), tensor_d_answer_real) * 0.5
                                     +criterion_d(tensor_d_hypo_sr - torch.mean(tensor_d_hypo_hr), tensor_d_answer_fake) * 0.5
                                     )
                    
                    with torch.cuda.amp.autocast(enabled=True):
                        if model_g_name == "RRDBNet":
                            if flag_loss_g_list == 1:
                                loss_g = (criterion_g[0](tensor_g_hypo, tensor_y) * criterion_g_weight[0]
                                         +criterion_g[1](tensor_g_hypo, tensor_y, True) * criterion_g_weight[1]
                                         +loss_d * criterion_g_weight[2]
                                         )
                            else:
                                loss_g = (criterion_g[0](tensor_g_hypo, tensor_y)
                                         +criterion_g[1](tensor_g_hypo, tensor_y, True)
                                         +loss_d
                                         )
                    
                    try:
                        #loss overflow, underflow 오류 방지
                        amp_scaler.scale(loss_g).backward()
                    except:
                        flag_error = 1
                        update_dict_v2("", "in " + str(i_epoch) + " " + str(i_batch_g)
                                      ,"", "loss_g.backward 실패():" + str(loss_g.item())
                                      ,in_dict = dict_log_error
                                      ,in_print_head = "dict_log_error"
                                      )
                    
                    #가중치 갱신 (batch 마다)
                    amp_scaler.step(optimizer_g)
                    amp_scaler.update()
                    #기울기 초기화
                    optimizer_g.zero_grad()
                    #print("optimizer_d.zero_grad()")
                    if HP_SCHEDULER_UPDATE_INTERVAL_G == "batch":
                        #스케쥴러 갱신
                        scheduler_g.step()
                        print("scheduler_g.step()")
                    
                    
                    #>>> model_g 갱신 
                
                else: #val & test
                    #<<< model_d eval
                    with torch.no_grad():
                        tensor_g_hypo = model_g(tensor_x)
                        
                        list_pils_g_hypo = tensor_2_list_pils_v1(#텐서 -> pil 이미지 리스트
                                                                 #(tensor) 변환할 텐서, 모델에서 다중 결과물이 생성되는 경우, 단일 출력물 묶음만 지정해서 입력 
                                                                 #(예: MPRNet -> in_tensor = tensor_sr_hypo[0])
                                                                 in_tensor = tensor_g_hypo
                                                                
                                                                 #(bool) pil 이미지 크기 변환 시행여부 (default: False)
                                                                ,is_resized = True
                                                                 #(귀속) (tuple) pil 변환결과 크기 (w, h)
                                                                ,resized_size = (HP_MODEL_D_IMG_W, HP_MODEL_D_IMG_H)
                                                                 #(귀속) (str) interpolation 방식 ("NEAREST", "BILINEAR", "BICUBIC", "LANCZOS")
                                                                ,resized_method = "LANCZOS"
                                                                )
                        
                        tensor_g_hypo_resized =  list_pils_2_tensor_v1(#(list - pil) list로 묶인 PIL 이미지 묶음을 pytorch tensor로 변환해줌
                                                                       list_pils = list_pils_g_hypo
                                                                       #(int) pil 이미지 채널 수 (Color = 3, Gray = 1)
                                                                      ,pil_channels = HP_CHANNEL_RGB
                                                                      
                                                                       #(bool) pil 이미지 크기 변환 시행여부
                                                                      ,is_resized = True
                                                                       #(tuple) pil 변환결과 크기 (w, h)
                                                                      ,resized_size = (HP_MODEL_D_IMG_W, HP_MODEL_D_IMG_H)
                                                                       #(str) interpolation 방식 ("NEAREST", "BILINEAR", "BICUBIC", "LANCZOS")
                                                                      ,resized_method = "LANCZOS"
                                                                      
                                                                       #(transforms) pil to tensor 함수
                                                                      ,transforms_to_tensor = transform_to_ts_img
                                                                       #(bool) requires grad 여부
                                                                      ,is_requires_grad = False
                                                                      )
                        tensor_g_hypo_resized = tensor_g_hypo_resized.to(device)
                        
                        if model_d_name == "relativistic":
                            #model_d 정답 텐서 (real, fake)
                            tensor_d_answer_real = torch.full([current_batch_size, 1], 1.0, dtype=torch.float, device=torch.device(device))
                            tensor_d_answer_fake = torch.full([current_batch_size, 1], 0.0, dtype=torch.float, device=torch.device(device))
                            #model_d(HR)
                            tensor_d_hypo_hr = model_d(tensor_y_resized.clone().detach())
                            #model_d(SR)
                            tensor_d_hypo_sr = model_d(tensor_g_hypo_resized.clone().detach())
                            
                            #loss_d = (loss_d_hr + loss_d_sr ) * 0.5
                            loss_d = (criterion_d(tensor_d_hypo_hr - torch.mean(tensor_d_hypo_sr), tensor_d_answer_real) * 0.5
                                     +criterion_d(tensor_d_hypo_sr - torch.mean(tensor_d_hypo_hr), tensor_d_answer_fake) * 0.5
                                     )
                            
                            
                        if model_g_name == "RRDBNet":
                            if flag_loss_g_list == 1:
                                loss_g = (criterion_g[0](tensor_g_hypo, tensor_y) * criterion_g_weight[0]
                                         +criterion_g[1](tensor_g_hypo, tensor_y, False) * criterion_g_weight[1]
                                         +loss_d * criterion_g_weight[2]
                                         )
                            else:
                                loss_g = (criterion_g[0](tensor_g_hypo, tensor_y)
                                         +criterion_g[1](tensor_g_hypo, tensor_y, False)
                                         +loss_d
                                         )

                    
                    #>>> model_d eval
                
                #결과 정리
                if model_d_name == "relativistic":
                    #model_d 학습과정에서 d의 예측값 nparray
                    np_d_hypo_hr = tensor_d_hypo_hr.clone().detach().cpu().numpy()
                    np_d_hypo_sr = tensor_d_hypo_sr.clone().detach().cpu().numpy()
                    print("in model_g train & eval")
                    print("np_d_hypo_hr", np_d_hypo_hr)
                    print("np_d_hypo_sr", np_d_hypo_sr)
                
                
                try:
                    del tensor_x
                    del tensor_y
                    del tensor_y_resized
                    del tensor_g_hypo
                    del tensor_g_hypo_resized
                    del loss_d
                    del tensor_d_hypo_hr
                    del tensor_d_hypo_sr
                except:
                    print("(exc) model_d stage tensor del FAIL")
                
                
                i_batch_g += 1
                #End of for path_x, path_y in dataloader_input:
