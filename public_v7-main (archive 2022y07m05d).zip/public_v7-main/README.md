# public_v7
pytorch image related trainer collection

Aim -> Easy to read codes & Handy functions

Tested dataset: CamVid (12 labels, w480xh360) 
> from https://github.com/alexgkendall/SegNet-Tutorial 
>
> used in https://github.com/lxtGH/SFSegNets/blob/master/DATASETs.md

from 2022y 05m 11d ~

* Semantic Segmentation Net training 
  
  -> Done (for DeepLab v3 Plus)

* Image Restoration Net training
  
  -> Done (for MPRNet)

* Super Resolution Net training
  
  -> Done (for RRDBNet in ESRGAN)

* Super Resolution GAN training
  
  -> working on...


# Codes for data producing
RUN producer_... .py files in order below
1. producer_degrade_csv.py

    -> degradation options will be generated in csv format

2. producer_degrade_image.py (not ready yet)

    -> input images will be degraded with options in csv file (generated previous step)

# Codes for train
RUN workspace_... .py to init train!
-> check haper_para.py file for dataset folder architecture

-> Prepare model from other Repo: https://github.com/KyungBong-Ryu/Codes_implementation

+ calc_func.py

+ data_load_n_save.py

+ data_tool.py

+ hyper_para.py

+ trainer_ooo.py

+ workspace_ooo.py

