#workspace_test_sr_ss.py

from tester_sr_ss import *
from hyper_para import *
from model_deeplab_v3_plus import *
from model_mprnet import *
from model_esrgan import Generator as RRDBNet


#[init]----------------------------
#Prevent overwriting results
if os.path.isdir(PATH_BASE_OUT):
    print("실험결과 덮어쓰기 방지기능 작동됨 (Prevent overwriting results function activated)")
    sys.exit("Prevent overwriting results function activated")


dict_log_init = {}

# set computation device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

update_dict_v2("", "---< init >---"
              ,"", "RUN date: " + HP_INIT_DATE_TIME
              ,"", "--- Dataset Parameter info ---"
              ,"", "Dataset from... " + PATH_BASE_IN
              ,"", ""
              ,"", "--- Hyper Parameter info ---"
              ,"", "Device:" + str(device)
              ,in_dict = dict_log_init
              ,in_print_head = "dict_log_init"
              )



dataset_name = "camvid"

if dataset_name == "camvid": #dataset = camvid
    print("dataset: camvid 12 v4")
    
    HP_ORIGIN_IMG_W, HP_ORIGIN_IMG_H = 480, 360 #CamVid 12 v4 size
    
    #라벨 수
    HP_LABEL_TOTAL = 12
    #void 라벨값
    HP_LABEL_VOID = 11
    #모델 출력 이미지 (void 라벨 제외)
    HP_CHANNEL_HYPO = HP_LABEL_TOTAL - 1 
    
    #라벨 당 컬러 지정 (CamVid 12)
    #label_color_map -> HP_COLOR_MAP
    HP_COLOR_MAP = {0:  [128, 128, 128]  # 00 Sky
                   ,1:  [128,   0,   0]  # 01 Building
                   ,2:  [192, 192, 128]  # 02 Column_pole
                   ,3:  [128,  64, 128]  # 03 Road
                   ,4:  [  0,   0, 192]  # 04 Sidewalk
                   ,5:  [128, 128,   0]  # 05 Tree
                   ,6:  [192, 128, 128]  # 06 SignSymbol
                   ,7:  [ 64,  64, 128]  # 07 Fence
                   ,8:  [ 64,   0, 128]  # 08 Car
                   ,9:  [ 64,  64,   0]  # 09 Pedestrian
                   ,10: [  0, 128, 192]  # 10 Bicyclist
                   ,11: [  0,   0,   0]  # 11 Void
                   }
    
    
#[model SR]------------------------------------------------------------------------------------------------



#(SR) 모델 이름
#model_sr_name = "MPRNet"
model_sr_name = "RRDBNet"


if model_sr_name == "MPRNet":
    #(SR) state_dict 경로
    # path_msd_sr = "/content/drive/MyDrive/Colab_Notebooks/model_state_dict/msd_sr/com_1/20220530_mpr_camvid_a_164_msd.pt"
    path_msd_sr = "/content/drive/MyDrive/Colab_Notebooks/model_state_dict/msd_sr/com_1/20220607_mpr_camvid_a_270_msd.pt"
    #(SR) 모델 선언
    model_sr = MPRNet()
    #(SR) 정규화 시행여부
    is_norm_in_transform_to_tensor_sr = False
    #(SR) 모델 이름 정보
    tmp_str_model_info = "(github) MPRNet (denoise)"
    #(SR) 모델 학습시 pretrained 여부 (대부분 False)
    tmp_is_pre_trained = "False"
    
elif model_sr_name == "RRDBNet":
    # path_msd_sr = "/content/drive/MyDrive/Colab_Notebooks/model_state_dict/msd_sr/com_0/20220530_rrdb_camvid_a_114_msd.pt"
    path_msd_sr = "/content/drive/MyDrive/Colab_Notebooks/model_state_dict/msd_sr/com_0/20220530_rrdb_camvid_a_215_msd.pt"
    
    model_sr = RRDBNet()
    is_norm_in_transform_to_tensor_sr = False
    tmp_str_model_info = "(github) RRDBNet (Net stage) "
    tmp_is_pre_trained = "False"
    
update_dict_v2("", ""
              ,"", "(SR) model info: " + model_sr_name
              ,"", "path: " + path_msd_sr
              ,"", tmp_str_model_info
              ,"", "pretrained = " + tmp_is_pre_trained
              ,in_dict = dict_log_init
              ,in_print_head = "dict_log_init"
              )




#[model SS]------------------------------------------------------------------------------------------------


#(SS) 정규화 시행여부
is_norm_in_transform_to_tensor_ss = True

#(SS) 모델 이름 
model_ss_name = "DeeplabV3Plus"
#(SS) 모델 입력을 위해 (513,513) 과 같은 특정 형태로 Resize 작업을 시행하는가?
is_input_resized = True
#(SS) Degraded 이미지로 Train을 시행했는가?
is_trained_with_degraded_images = False

if model_ss_name == "DeeplabV3Plus":
    #모델 입력을 위해 이미지 크기 resize 시행 여부
    if is_input_resized: #Resized 이미지로 Train됨 (513x513)
        tmp_str_resized = "images resized for model input"
        #모델 입력 크기
        HP_MODEL_SS_IMG_W, HP_MODEL_SS_IMG_H = 513, 513
        #모델 train 과정에 degraded 이미지 사용 여부
        if not is_trained_with_degraded_images: #HR(원본) 이미지로 Train됨
            tmp_str_train_with_degraded = "model does not trained with degraded images"
            #(SS) state_dict 경로
            path_msd_ss = "/content/drive/MyDrive/Colab_Notebooks/model_state_dict/msd_ss/com_0/20220501_d3p_camvid_a_228_msd.pt"
        else: #Degraded 이미지로 Train됨
            tmp_str_train_with_degraded = "model trained with degraded images"
            #현재 학습중...
            path_msd_ss = "/content/drive/MyDrive/Colab_Notebooks/model_state_dict/msd_ss/com_2/20220530_d3p_camvid_a_153_msd.pt"
        
    else: #원본크기 이미지로 학습 (CamVid: 480x360)
        tmp_str_resized = "images are not resized for model input"
        HP_MODEL_SS_IMG_W, HP_MODEL_SS_IMG_H = HP_ORIGIN_IMG_W, HP_ORIGIN_IMG_H
        #모델 train 과정에 degraded 이미지 사용 여부
        if not is_trained_with_degraded_images: #HR(원본) 이미지로 Train됨
            tmp_str_train_with_degraded = "model does not trained with degraded images"
            #(SS) state_dict 경로
            path_msd_ss = "준비중"
        else: #Degraded 이미지로 Train됨
            tmp_str_train_with_degraded = "model trained with degraded images"
            #현재 학습중...
            path_msd_ss = "준비중"
    
    
    #(SS) 모델 선언
    model_ss =  DeepLab_v3_plus(num_classes = HP_CHANNEL_HYPO, pretrained = False)
    #(SS) 모델 이름 정보
    tmp_str_model_info = "(github) Deeplab v3 plus"
    #(SS) 모델 학습시 pretrained 여부 (대부분 False)
    tmp_is_pre_trained = "False"
    
update_dict_v2("", ""
              ,"", "(SS) model info: " + model_ss_name
              ,"", "path: " + path_msd_ss
              ,"", tmp_str_model_info
              ,"", "pretrained = " + tmp_is_pre_trained
              ,"", tmp_str_resized
              ,"", tmp_str_train_with_degraded
              ,in_dict = dict_log_init
              ,in_print_head = "dict_log_init"
              )


#[INIT test]------------------------------------------------------------------------------------------------
#msd file path check
if not os.path.isfile(path_msd_sr):
    print("SR MSD Load FAIL:", path_msd_sr)
    sys.exit(9)
if not os.path.isfile(path_msd_ss):
    print("SS MSD Load FAIL:", path_msd_ss)
    sys.exit(9)



tester_sr_ss(#<patch를 통해 학습 & RGB 이미지를 생성하는 모델>#
            
            #model.to(device) 포함됨 -> workspace에서 시행 안해도 됨
            
            #초기화 기록 dict 이어받기
            dict_log_init = dict_log_init
            #랜덤 시드 고정
            ,HP_SEED = HP_SEED
            
            
            #데이터 입출력 경로, 폴더명
            ,PATH_BASE_IN = PATH_BASE_IN
            ,NAME_FOLDER_TEST = NAME_FOLDER_TEST
            ,NAME_FOLDER_IMAGES = NAME_FOLDER_IMAGES
            ,NAME_FOLDER_LABELS = NAME_FOLDER_LABELS
            
             #(선택) degraded image 불러올 경로
            ,PATH_BASE_IN_SUB = PATH_BASE_IN_SUB
            
            ,PATH_OUT_IMAGE = PATH_OUT_IMAGE
            ,PATH_OUT_LOG = PATH_OUT_LOG
            
            #데이터(이미지) 입출력 크기 (원본 이미지, 모델 입력 이미지), 이미지 채널 수(이미지, 라벨, 모델출력물)
            ,HP_ORIGIN_IMG_W = HP_ORIGIN_IMG_W
            ,HP_ORIGIN_IMG_H = HP_ORIGIN_IMG_H
            ,HP_MODEL_SS_IMG_W = HP_MODEL_SS_IMG_W
            ,HP_MODEL_SS_IMG_H = HP_MODEL_SS_IMG_H
            ,HP_CHANNEL_RGB = HP_CHANNEL_RGB
            ,HP_CHANNEL_GRAY = HP_CHANNEL_GRAY
            ,HP_CHANNEL_HYPO = HP_CHANNEL_HYPO
            
            #라벨 정보(원본 데이터 라벨 수(void 포함), void 라벨 번호, 컬러매핑)
            ,HP_LABEL_TOTAL = HP_LABEL_TOTAL
            ,HP_LABEL_VOID = HP_LABEL_VOID
            ,HP_COLOR_MAP = HP_COLOR_MAP
            
            
            #모델 이름 -> 모델에 따라 예측결과 형태가 다르기에 모델입출력물을 조정하는 역할
            #지원 리스트 SR = "MPRNet", (의미없음) "RRDBNet"
            #지원 리스트 SS = (의미없음) "DeeplabV3Plus"
            ,model_sr_name = model_sr_name
            ,model_ss_name = model_ss_name
            
            #model, model_state_dict 경로
            #<모델 SR>
            ,model_sr = model_sr
            ,path_msd_sr = path_msd_sr
            #<모델 SS>
            ,model_ss = model_ss
            ,path_msd_ss = path_msd_ss
            
            
            #이미지 -> 텐서 시 norm 관련 (정규화 시행여부, 평균, 표준편차)
            #<모델 SR>
            ,is_norm_in_transform_to_tensor_sr = is_norm_in_transform_to_tensor_sr
            ,HP_TS_NORM_MEAN_SR = HP_TS_NORM_MEAN_SR
            ,HP_TS_NORM_STD_SR = HP_TS_NORM_STD_SR
            #<모델 SS>
            ,is_norm_in_transform_to_tensor_ss = is_norm_in_transform_to_tensor_ss
            ,HP_TS_NORM_MEAN_SS = HP_TS_NORM_MEAN_SS
            ,HP_TS_NORM_STD_SS = HP_TS_NORM_STD_SS
            
            
            #Degradation 기타 설정값
            ,HP_DG_CSV_NAME = HP_DG_CSV_NAME
            ,HP_DG_SCALE_FACTOR = HP_DG_SCALE_FACTOR
            ,HP_DG_RESIZE_OPTION = HP_DG_RESIZE_OPTION
            
            )


print("workspace_test_sr_ss.py")
